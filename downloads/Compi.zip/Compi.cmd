@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0Compi.exe" (
  start "Compi" "%~dp0Compi.exe"
) else (
  start "Compi" "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0Compi.ps1"
)
