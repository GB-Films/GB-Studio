using System;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

public sealed class CompiVideoInfo
{
    public string Path;
    public Image Thumbnail;
    public TimeSpan? Duration;
}

public static class CompiVideo
{
    [ComImport, Guid("BCC18B79-BA16-442F-80C4-8A59C30C463B"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IShellItemImageFactory
    {
        [PreserveSig]
        int GetImage(Size size, int flags, out IntPtr bitmap);
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
    private static extern void SHCreateItemFromParsingName(string path, IntPtr bindContext, ref Guid id, out IShellItemImageFactory item);

    [DllImport("gdi32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool DeleteObject(IntPtr handle);

    public static void LoadAsync(Control owner, string path, string ffmpeg, string ffprobe, Action<CompiVideoInfo> completed)
    {
        ThreadPool.QueueUserWorkItem(delegate {
            CompiVideoInfo result = new CompiVideoInfo();
            result.Path = path;
            result.Thumbnail = FrameFromFfmpeg(path, ffmpeg) ?? ShellThumbnail(path);
            result.Duration = ProbeDuration(path, ffprobe);
            try {
                if (owner.IsDisposed || !owner.IsHandleCreated) { if (result.Thumbnail != null) result.Thumbnail.Dispose(); return; }
                owner.BeginInvoke(completed, new object[] { result });
            } catch {
                if (result.Thumbnail != null) result.Thumbnail.Dispose();
            }
        });
    }

    private static Image FrameFromFfmpeg(string path, string ffmpeg)
    {
        if (String.IsNullOrEmpty(ffmpeg) || !File.Exists(ffmpeg)) return null;
        string output = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "compi-preview-" + Guid.NewGuid().ToString("N") + ".png");
        try {
            using (Process process = new Process()) {
                process.StartInfo.FileName = ffmpeg;
                process.StartInfo.Arguments = "-hide_banner -loglevel error -ss 1 -i \"" + path + "\" -frames:v 1 -vf scale=320:-2 -y \"" + output + "\"";
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.CreateNoWindow = true;
                process.Start();
                if (!process.WaitForExit(10000)) { process.Kill(); process.WaitForExit(); return null; }
                if (process.ExitCode != 0 || !File.Exists(output)) return null;
            }
            using (Image image = Image.FromFile(output)) return new Bitmap(image);
        } catch { return null; }
        finally { try { if (File.Exists(output)) File.Delete(output); } catch { } }
    }

    private static Image ShellThumbnail(string path)
    {
        IShellItemImageFactory item = null;
        IntPtr handle = IntPtr.Zero;
        try {
            Guid id = new Guid("BCC18B79-BA16-442F-80C4-8A59C30C463B");
            SHCreateItemFromParsingName(path, IntPtr.Zero, ref id, out item);
            if (item.GetImage(new Size(320, 180), 8, out handle) != 0 || handle == IntPtr.Zero) return null;
            using (Bitmap image = Image.FromHbitmap(handle)) return new Bitmap(image);
        } catch { return null; }
        finally {
            if (handle != IntPtr.Zero) DeleteObject(handle);
            if (item != null) Marshal.ReleaseComObject(item);
        }
    }

    private static TimeSpan? ProbeDuration(string path, string ffprobe)
    {
        if (String.IsNullOrEmpty(ffprobe) || !File.Exists(ffprobe)) return null;
        try {
            using (Process process = new Process()) {
                process.StartInfo.FileName = ffprobe;
                process.StartInfo.Arguments = "-v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 \"" + path + "\"";
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.RedirectStandardOutput = true;
                process.Start();
                if (!process.WaitForExit(6000)) { process.Kill(); process.WaitForExit(); return null; }
                string text = process.StandardOutput.ReadToEnd().Trim();
                double seconds;
                if (process.ExitCode == 0 && Double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out seconds) && seconds >= 0)
                    return TimeSpan.FromSeconds(seconds);
            }
        } catch { }
        return null;
    }
}
