# Compi

Aplicación de escritorio para Windows. Permite elegir o arrastrar un video, pulsar **Reexportar** y guardar el resultado en la misma carpeta que el original.

## Uso

1. Abrí `Compi.exe` o `Compi.cmd` con doble clic. El acceso anterior `Reexportar.cmd` también funciona.
2. Elegí o arrastrá el video.
3. Seleccioná **Máximo 10 MB** o **Personalizado** e ingresá el tamaño máximo de salida en MB. Se aceptan decimales con coma o punto (por ejemplo, `7,5`).
4. Pulsá **Reexportar**.

El archivo original nunca se sobrescribe. El resultado se llama `nombre_reexportado.mp4` (o `nombre_reexportado_2.mp4` si ya existe). Si el original ya cumple el límite elegido, se crea una copia idéntica con la extensión original. Un MB equivale a 1.000.000 de bytes.

## Requisitos

- Windows 10 u 11. Usa Windows PowerShell, que ya viene con el sistema.
- Internet en el primer uso si FFmpeg no está instalado. La aplicación descarga una compilación de FFmpeg [enlazada desde el sitio oficial](https://ffmpeg.org/download.html), verifica su SHA-256 y la guarda en `%LOCALAPPDATA%\ReexportarVideo\bin`.

Los videos que necesitan compresión se entregan en MP4 con video H.264 y audio AAC. La aplicación hace hasta cuatro intentos y solo entrega un archivo comprimido cuando cumple el tamaño seleccionado. Un video demasiado largo para el límite elegido puede no ser viable si se conserva el audio; en ese caso muestra el error y deja intacto el original.

El código de FFmpeg tiene su propia licencia. La aplicación no lo incluye en el repositorio; lo descarga del distribuidor de compilaciones de Windows enlazado por FFmpeg.

La interfaz de Compi usa el logotipo blanco de GB Films incluido en `assets/LogotipoGBF_blanco_v01.png`.

El ícono de Compi es blanco y negro y está integrado en `Compi.exe` para que Windows lo muestre en la barra de tareas. Los archivos fuente y los comandos para reconstruir el ejecutable están en `tools/`.
