# Compi

Aplicación de escritorio para Windows. Permite reexportar videos con un tamaño máximo y fotos con la resolución y el recorte elegidos. El resultado se guarda en la misma carpeta que el original.

La versión aparece en la ventana y en el título de Compi. El número se guarda en `VERSION`. Para cada actualización, cambiá primero `VERSION`.

Antes de publicar el instalador para descarga pública en Windows, consultá [PUBLICACION.md](PUBLICACION.md): la versión actual no está firmada y puede ser bloqueada por el Control Inteligente de Aplicaciones.

## Instalación

La versión actual es **1.3.2**. [Descargá el instalador actualizado](https://github.com/GB-Films/COMPI/raw/refs/heads/master/Compi-Setup.exe); también está en la raíz del repositorio como `Compi-Setup.exe`.

Para instalar Compi, ejecutá `Compi-Setup.exe` o `Compi-Setup-vNÚMERO.exe`. El instalador copia la aplicación en tu perfil de Windows, crea el acceso en Inicio y agrega **Reexportar con Compi** al menú de clic derecho de los videos compatibles. También agrega **Abrir foto con Compi** para imágenes. No hace falta abrir Compi una primera vez ni tener permisos de administrador. Se puede desinstalar desde **Configuración > Aplicaciones**; la desinstalación quita esas opciones del menú.

El instalador detecta la versión anterior y ofrece **Reemplazar Compi** en la misma carpeta. No crea otra instalación ni modifica tus videos o fotos. Si la app instalada o sus exportaciones siguen abiertas, pide cerrarlas antes de continuar; nunca las termina por la fuerza.

En Windows 11, la entrega sin firma conserva los comandos dentro de **Mostrar más opciones**. La extensión nativa para el menú principal está en `tools/CompiExplorerCommand.cpp` y su manifiesto en `tools/ExplorerPackage.appxmanifest`. Para distribuirla se requiere un paquete de identidad firmado con un certificado confiable: no alcanza con aceptar términos. No se activa el modo desarrollador, no se agrega ningún certificado al equipo y no se cambia el menú global de Windows. Si el registro del paquete falla, el instalador lo aclara y conserva el menú clásico. El instalador actual es para Windows compatible con aplicaciones x64. Para crear una entrega se usa `tools/Build-Installer.ps1` con NSIS; genera `Compi-Setup-vNÚMERO.exe` en `dist/`.

Con un certificado de firma en el almacén personal, `tools/Build-Installer.ps1 -ExplorerCertificateThumbprint HUELLA` compila, firma y verifica la extensión y el paquete, y los incorpora al instalador. El instalador registra el paquete para el usuario actual y la desinstalación lo retira. Puede ser necesario cerrar sesión y volver a entrar para que el Explorador actualice el menú. `tools/Build-ExplorerIntegration.ps1 -OutputDirectory RUTA` sin certificado sirve únicamente para compilar y revisar el paquete; no lo registra.

El ZIP creado por `tools/Package-App.ps1` sigue siendo la versión portátil. En ese caso, abrir `Compi.exe` no instala el menú: ejecutá una vez `Instalar menu de Compi.cmd` desde la carpeta descomprimida. Si movés esa carpeta, repetí el registro. Para quitar los accesos, ejecutá `Quitar menu de Compi.cmd`.

## Video

1. Abrí Compi desde Inicio o con `Compi.exe`. En la versión portátil también funcionan `Compi.cmd` y el acceso anterior `Reexportar.cmd`. La solapa **Video** aparece por defecto. El ejecutable inicia Compi sin pedir que habilites o cambies la política de scripts de Windows.
2. Elegí o arrastrá el video.
   **Abrir con > Compi** o **Abrir con Compi** desde el menú clásico ya abre la aplicación con ese video seleccionado. No inicia la exportación hasta que pulses Reexportar. También reconoce las fotos abiertas de esa forma y selecciona la solapa Foto. No cambia el reproductor predeterminado.
   Al seleccionarlo, Compi muestra su nombre, peso, duración (cuando se puede leer) y una miniatura. **Reemplazar video** permite elegir otro archivo sin reiniciar la aplicación.
3. En el segundo paso, el tamaño deseado empieza en **10 MB**. Cambiá ese número si necesitás otro tamaño. Se aceptan decimales con coma o punto (por ejemplo, `7,5`). El resultado no supera ese límite.
4. Pulsá **Reexportar**.

El archivo original nunca se sobrescribe. El resultado se llama `nombre_reexportado.mp4` (o `nombre_reexportado_2.mp4` si ya existe). Si el original ya cumple el límite elegido, se crea una copia idéntica con la extensión original. Al terminar, **Abrir carpeta** abre el Explorador con el archivo seleccionado. Un MB equivale a 1.000.000 de bytes.

**Reexportar con Compi** empieza directamente en segundo plano, sin abrir la ventana principal. Usa el límite predeterminado de **10 MB** y guarda el resultado junto al original. Mientras trabaja aparece, en esa misma carpeta, una señal temporal llamada `nombre_reexportado — EXPORTANDO ... .compi-exportando`. El nombre actualiza el porcentaje cada 5 puntos; no es un video terminado. Doble clic en esa señal muestra el avance. Al terminar, cancelar o fallar, la señal se retira.

Un panel negro de Compi muestra el nombre del video, una barra de avance y el mensaje **Tu video se está exportando. Te avisaremos cuando esté listo.** Permite cancelar, y al terminar ofrece **Ver archivo**. Si exportás varios videos, los avisos se apilan; si la pantalla se llena, los siguientes esperan un espacio. Cerrar el panel oculta el aviso y la exportación continúa. Podés volver a verlo desde el ícono de la bandeja o la señal temporal. Si necesitás otro tamaño, abrí la aplicación y usá el control manual. **Abrir foto con Compi** abre la solapa Foto con esa imagen cargada.

## Foto

1. Entrá en la solapa **Foto** y arrastrá una imagen o pulsá **Elegir foto**. Verás su miniatura, nombre, peso y resolución. **Reemplazar foto** permite elegir otra.
2. Escribí el ancho o el alto deseado en píxeles, o arrastrá horizontalmente el número para ajustarlo (con Shift, más despacio). **Mantener proporción** ajusta la otra medida. Si lo desactivás y definís otra relación, al volver a activarlo conserva tus medidas y usa esa nueva relación.
3. Pulsá **Reencuadrar y reexportar foto**. En la ventana de reencuadre, usá la rueda para hacer zoom, arrastrá con el botón central para mover la foto o arrastrá con el izquierdo para ajustar el recorte. Las flechas del teclado también lo mueven.
4. Confirmá con **Reexportar foto**.

Acepta JPG, JPEG, PNG, BMP, GIF y TIFF. Las fotos JPG/JPEG salen como JPG de alta calidad; las demás salen como PNG. El resultado tiene las dimensiones exactas indicadas y se guarda junto al original como `nombre_ANCHOxALTO.jpg` o `.png`; si ya existe, Compi agrega `_copia`, luego `_copia_02` y así sucesivamente. Nunca sobrescribe archivos. El tamaño estimado se calcula según el archivo original y la nueva resolución; el peso real varía según el formato y el contenido. Al terminar, **Abrir carpeta** abre el Explorador con la foto seleccionada. El límite es de 12.000 píxeles por lado y 80 megapíxeles. Compi comprueba estos límites antes de cargar la foto para previsualizarla y antes de exportar.

## Requisitos

- Windows 10 u 11. Usa Windows PowerShell, que ya viene con el sistema.
- Internet en el primer uso de la compresión de video si FFmpeg no está instalado. La aplicación descarga una compilación de FFmpeg [enlazada desde el sitio oficial](https://ffmpeg.org/download.html), verifica su SHA-256 y la guarda en `%LOCALAPPDATA%\ReexportarVideo\bin`. Las fotos no requieren FFmpeg ni Internet.

Los videos que necesitan compresión se entregan en MP4 con video H.264 y audio AAC. La aplicación hace hasta cuatro intentos y solo entrega un archivo comprimido cuando cumple el tamaño seleccionado. Un video demasiado largo para el límite elegido puede no ser viable si se conserva el audio; en ese caso muestra el error y deja intacto el original.

El código de FFmpeg tiene su propia licencia. La aplicación no lo incluye en el repositorio; lo descarga del distribuidor de compilaciones de Windows enlazado por FFmpeg.

El ícono de Compi es una flecha hacia abajo entre una barra ancha y una corta: representa la reducción de tamaño. Está integrado en `Compi.exe` para que Windows lo muestre en la barra de tareas. Los archivos fuente y los comandos para reconstruir el ejecutable están en `tools/`.

El botón **?** junto al encabezado abre un recuadro con el crédito **Desarrollado por Gran Berta**.
