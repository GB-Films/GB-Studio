# Compi

Aplicación de escritorio para Windows. Permite reexportar videos con un tamaño máximo y fotos con la resolución y el recorte elegidos. El resultado se guarda en la misma carpeta que el original.

La versión aparece en la ventana y en el título de Compi. El número se guarda en `VERSION`; al preparar una entrega con `tools/Package-App.ps1`, el ZIP se llama `Compi vNÚMERO.zip` y el ejecutable recibe esa misma versión. Para cada actualización, cambiá primero `VERSION`.

Antes de publicar el ZIP para descarga pública en Windows, consultá [PUBLICACION.md](PUBLICACION.md): la versión actual no está firmada y puede ser bloqueada por el Control Inteligente de Aplicaciones.

## Video

1. Abrí `Compi.exe` o `Compi.cmd` con doble clic. La solapa **Video** aparece por defecto. El acceso anterior `Reexportar.cmd` también funciona.
2. Elegí o arrastrá el video.
   Al seleccionarlo, Compi muestra su nombre, peso, duración (cuando se puede leer) y una miniatura. **Reemplazar video** permite elegir otro archivo sin reiniciar la aplicación.
3. En el segundo paso, el tamaño deseado empieza en **10 MB**. Cambiá ese número si necesitás otro tamaño. Se aceptan decimales con coma o punto (por ejemplo, `7,5`). El resultado no supera ese límite.
4. Pulsá **Reexportar**.

El archivo original nunca se sobrescribe. El resultado se llama `nombre_reexportado.mp4` (o `nombre_reexportado_2.mp4` si ya existe). Si el original ya cumple el límite elegido, se crea una copia idéntica con la extensión original. Al terminar, **Abrir carpeta** abre el Explorador con el archivo seleccionado. Un MB equivale a 1.000.000 de bytes.

## Foto

1. Entrá en la solapa **Foto** y arrastrá una imagen o pulsá **Elegir foto**. Verás su miniatura, nombre, peso y resolución. **Reemplazar foto** permite elegir otra.
2. Escribí el ancho o el alto deseado en píxeles, o arrastrá horizontalmente el número para ajustarlo (con Shift, más despacio). **Mantener proporción** ajusta la otra medida. Si lo desactivás y definís otra relación, al volver a activarlo conserva tus medidas y usa esa nueva relación.
3. Pulsá **Reencuadrar y reexportar foto**. En la ventana de reencuadre, usá la rueda para hacer zoom, arrastrá con el botón central para mover la foto o arrastrá con el izquierdo para ajustar el recorte. Las flechas del teclado también lo mueven.
4. Confirmá con **Reexportar foto**.

Acepta JPG, JPEG, PNG, BMP, GIF y TIFF. Las fotos JPG/JPEG salen como JPG de alta calidad; las demás salen como PNG. El resultado tiene las dimensiones exactas indicadas y se guarda junto al original como `nombre_ANCHOxALTO.jpg` o `.png`; si ya existe, Compi agrega `_copia`, luego `_copia_02` y así sucesivamente. Nunca sobrescribe archivos. El tamaño estimado se calcula según el archivo original y la nueva resolución; el peso real varía según el formato y el contenido. Al terminar, **Abrir carpeta** abre el Explorador con la foto seleccionada. El límite es de 12.000 píxeles por lado y 80 megapíxeles. Compi comprueba estos límites antes de cargar la foto para previsualizarla y antes de exportar.

## Requisitos

- Windows 10 u 11. Usa Windows PowerShell, que ya viene con el sistema.
- Internet en el primer uso de la compresión de video si FFmpeg no está instalado. La aplicación descarga una compilación de FFmpeg [enlazada desde el sitio oficial](https://ffmpeg.org/download.html), verifica su SHA-256 y la guarda en `%LOCALAPPDATA%\ReexportarVideo\bin`. Las fotos no requieren FFmpeg ni Internet.

Los videos que necesitan compresión se entregan en MP4 con video H.264 y audio AAC. La aplicación hace hasta cuatro intentos y solo entrega un archivo comprimido cuando cumple el tamaño seleccionado. Un video demasiado largo para el límite elegido puede no ser viable si se conserva el audio; en ese caso muestra el error y deja intacto el original.

El código de FFmpeg tiene su propia licencia. La aplicación no lo incluye en el repositorio; lo descarga del distribuidor de compilaciones de Windows enlazado por FFmpeg.

El ícono de Compi es una flecha hacia abajo entre una barra ancha y una corta: representa la reducción de tamaño. Está integrado en `Compi.exe` para que Windows lo muestre en la barra de tareas. Los archivos fuente y los comandos para reconstruir el ejecutable están en `tools/`.
