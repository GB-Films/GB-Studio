@echo off
setlocal
if not exist "%~dp0Compi.exe" (
  echo No se encontro Compi.exe en esta carpeta.
  pause
  exit /b 1
)
"%~dp0Compi.exe" --remove-context-menu
