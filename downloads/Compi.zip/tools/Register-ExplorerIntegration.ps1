﻿param([switch]$Remove)
$ErrorActionPreference = 'Stop'
$packageName = 'GBFilms.Compi.ContextMenu'
$appDirectory = $PSScriptRoot
$packagePath = Join-Path $appDirectory 'Compi.ContextMenu.msix'
$statusPath = Join-Path $appDirectory 'ExplorerIntegration.status'
if ($Remove) {
    Get-AppxPackage -Name $packageName | Remove-AppxPackage -ErrorAction Stop
    exit 0
}
try {
    if (-not (Test-Path -LiteralPath $packagePath -PathType Leaf)) {
        [IO.File]::WriteAllText($statusPath, 'unavailable: falta el paquete firmado para el menú principal de Windows 11.')
        exit 0
    }
    if ([Environment]::OSVersion.Version.Build -lt 22000) {
        [IO.File]::WriteAllText($statusPath, 'unavailable: esta integración requiere Windows 11.')
        exit 0
    }
    $signature = Get-AuthenticodeSignature -LiteralPath $packagePath
    if ($signature.Status -ne 'Valid') { throw 'Windows no confía en la firma del paquete de Compi.' }
    Add-AppxPackage -Path $packagePath -ExternalLocation $appDirectory -ForceUpdateFromAnyVersion -ErrorAction Stop
    $registered = Get-AppxPackage -Name $packageName
    if (-not $registered) { throw 'Windows no confirmó el registro de Compi.' }
    [IO.File]::WriteAllText($statusPath, 'enabled: ' + $registered.PackageFullName)
} catch {
    [IO.File]::WriteAllText($statusPath, 'failed: ' + $_.Exception.Message)
    # The classic menu still works. Never weaken Windows security to register a package.
    Write-Warning $_.Exception.Message
    exit 1
}
