!ifndef APP_VERSION
  !error "APP_VERSION is required. Build with tools/Build-Installer.ps1."
!endif
!ifndef REPO_ROOT
  !error "REPO_ROOT is required. Build with tools/Build-Installer.ps1."
!endif
!ifndef OUTPUT_FILE
  !error "OUTPUT_FILE is required. Build with tools/Build-Installer.ps1."
!endif

Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "x64.nsh"

!define UNINSTALL_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\GBFilms.Compi"
!define MUI_ICON "${REPO_ROOT}\assets\Compi.ico"
!define MUI_UNICON "${REPO_ROOT}\assets\Compi.ico"
!define MUI_ABORTWARNING

Name "Compi ${APP_VERSION}"
OutFile "${OUTPUT_FILE}"
InstallDir "$LOCALAPPDATA\Programs\Compi"
InstallDirRegKey HKCU "${UNINSTALL_KEY}" "InstallLocation"
RequestExecutionLevel user
SetCompressor /SOLID lzma
BrandingText "Compi"
VIProductVersion "${APP_VERSION}.0"
VIAddVersionKey "ProductName" "Compi"
VIAddVersionKey "FileDescription" "Instalador de Compi"
VIAddVersionKey "FileVersion" "${APP_VERSION}"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Spanish"

!macro RegisterVideo EXT
  WriteRegStr HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.ReexportVideo" "" "Reexportar con Compi"
  WriteRegStr HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.ReexportVideo" "Icon" "$INSTDIR\Compi.exe"
  WriteRegStr HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.ReexportVideo\command" "" '$\"$INSTDIR\Compi.exe$\" --quick-video $\"%1$\"'
  WriteRegStr HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.OpenVideo" "" "Abrir con Compi"
  WriteRegStr HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.OpenVideo" "Icon" "$INSTDIR\Compi.exe"
  WriteRegStr HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.OpenVideo\command" "" '$\"$INSTDIR\Compi.exe$\" --video $\"%1$\"'
  WriteRegStr HKCU "Software\Classes\Applications\Compi.exe\SupportedTypes" "${EXT}" ""
  WriteRegBin HKCU "Software\Classes\${EXT}\OpenWithProgids" "Compi.Media" ""
!macroend

!macro RegisterPhoto EXT
  WriteRegStr HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.OpenPhoto" "" "Abrir foto con Compi"
  WriteRegStr HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.OpenPhoto" "Icon" "$INSTDIR\Compi.exe"
  WriteRegStr HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.OpenPhoto\command" "" '$\"$INSTDIR\Compi.exe$\" --photo $\"%1$\"'
  WriteRegStr HKCU "Software\Classes\Applications\Compi.exe\SupportedTypes" "${EXT}" ""
  WriteRegBin HKCU "Software\Classes\${EXT}\OpenWithProgids" "Compi.Media" ""
!macroend

!macro RemoveVideo EXT
  DeleteRegKey HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.ReexportVideo"
  DeleteRegKey HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.OpenVideo"
  DeleteRegValue HKCU "Software\Classes\${EXT}\OpenWithProgids" "Compi.Media"
!macroend

!macro RemovePhoto EXT
  DeleteRegKey HKCU "Software\Classes\SystemFileAssociations\${EXT}\shell\Compi.OpenPhoto"
  DeleteRegValue HKCU "Software\Classes\${EXT}\OpenWithProgids" "Compi.Media"
!macroend

Function .onInit
  SetRegView 64
  ReadRegStr $0 HKCU "${UNINSTALL_KEY}" "InstallLocation"
  ${If} $0 != ""
    StrCpy $INSTDIR $0
  ${EndIf}
  ${IfNot} ${RunningX64}
    MessageBox MB_OK|MB_ICONSTOP "Compi necesita una versión de Windows compatible con aplicaciones de 64 bits."
    Abort
  ${EndIf}
FunctionEnd

Section "Compi" SecCompi
  SetShellVarContext current
  SetRegView 64
  SetOutPath "$INSTDIR"
  SetOverwrite on
  ClearErrors
  File "${REPO_ROOT}\Compi.exe"
  File "${REPO_ROOT}\Compi.ps1"
  File "${REPO_ROOT}\PhotoTools.cs"
  File "${REPO_ROOT}\VideoTools.cs"
  File "${REPO_ROOT}\Worker.ps1"
  File "${REPO_ROOT}\VERSION"
  File "${REPO_ROOT}\README.md"
  File "${REPO_ROOT}\tools\Register-ExplorerIntegration.ps1"
  !ifdef EXPLORER_PACKAGE_DIR
    File "${EXPLORER_PACKAGE_DIR}\CompiExplorerCommand.dll"
    File "${EXPLORER_PACKAGE_DIR}\Compi.ContextMenu.msix"
  !endif
  SetOutPath "$INSTDIR\assets"
  File "${REPO_ROOT}\assets\Compi.ico"
  File "${REPO_ROOT}\assets\Compi-icon.png"
  ${If} ${Errors}
    SetErrorLevel 1
    Abort "No se pudieron reemplazar los archivos de Compi. Cerrá la app y sus exportaciones."
  ${EndIf}

  CreateDirectory "$SMPROGRAMS\Compi"
  CreateShortCut "$SMPROGRAMS\Compi\Compi.lnk" "$INSTDIR\Compi.exe"
  WriteUninstaller "$INSTDIR\Uninstall.exe"

  WriteRegStr HKCU "${UNINSTALL_KEY}" "DisplayName" "Compi"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "DisplayVersion" "${APP_VERSION}"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "Publisher" "GB-Films"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "DisplayIcon" "$INSTDIR\Compi.exe"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
  WriteRegStr HKCU "${UNINSTALL_KEY}" "QuietUninstallString" '$\"$INSTDIR\Uninstall.exe$\" /S'
  WriteRegDWORD HKCU "${UNINSTALL_KEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINSTALL_KEY}" "NoRepair" 1
  WriteRegStr HKCU "Software\Classes\Applications\Compi.exe" "FriendlyAppName" "Compi"
  WriteRegStr HKCU "Software\Classes\Applications\Compi.exe\shell\open\command" "" '$\"$INSTDIR\Compi.exe$\" $\"%1$\"'
  WriteRegStr HKCU "Software\Classes\Compi.Media" "" "Video o foto de Compi"
  WriteRegStr HKCU "Software\Classes\Compi.Media\DefaultIcon" "" '$\"$INSTDIR\Compi.exe$\",0'
  WriteRegStr HKCU "Software\Classes\Compi.Media\shell\open\command" "" '$\"$INSTDIR\Compi.exe$\" $\"%1$\"'
  WriteRegStr HKCU "Software\Classes\.compi-exportando" "" "Compi.ExportStatus"
  WriteRegStr HKCU "Software\Classes\Compi.ExportStatus" "" "Video reexportándose con Compi"
  WriteRegStr HKCU "Software\Classes\Compi.ExportStatus\DefaultIcon" "" '$\"$INSTDIR\Compi.exe$\",0'
  WriteRegStr HKCU "Software\Classes\Compi.ExportStatus\shell\open\command" "" '$\"$INSTDIR\Compi.exe$\" --export-status $\"%1$\"'

  !insertmacro RegisterVideo ".mp4"
  !insertmacro RegisterVideo ".mov"
  !insertmacro RegisterVideo ".mkv"
  !insertmacro RegisterVideo ".avi"
  !insertmacro RegisterVideo ".webm"
  !insertmacro RegisterVideo ".wmv"
  !insertmacro RegisterVideo ".m4v"
  !insertmacro RegisterVideo ".mpeg"
  !insertmacro RegisterVideo ".mpg"
  !insertmacro RegisterVideo ".3gp"
  !insertmacro RegisterVideo ".ts"
  !insertmacro RegisterPhoto ".jpg"
  !insertmacro RegisterPhoto ".jpeg"
  !insertmacro RegisterPhoto ".png"
  !insertmacro RegisterPhoto ".bmp"
  !insertmacro RegisterPhoto ".gif"
  !insertmacro RegisterPhoto ".tif"
  !insertmacro RegisterPhoto ".tiff"
  nsExec::ExecToStack '$\"$WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe$\" -NoProfile -ExecutionPolicy Bypass -File $\"$INSTDIR\Register-ExplorerIntegration.ps1$\"'
  Pop $0
  Pop $1
  System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, p 0, p 0)'
SectionEnd

Section "Uninstall"
  SetShellVarContext current
  SetRegView 64
  nsExec::ExecToStack '$\"$WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe$\" -NoProfile -ExecutionPolicy Bypass -File $\"$INSTDIR\Register-ExplorerIntegration.ps1$\" -Remove'
  Pop $0
  Pop $1
  !insertmacro RemoveVideo ".mp4"
  !insertmacro RemoveVideo ".mov"
  !insertmacro RemoveVideo ".mkv"
  !insertmacro RemoveVideo ".avi"
  !insertmacro RemoveVideo ".webm"
  !insertmacro RemoveVideo ".wmv"
  !insertmacro RemoveVideo ".m4v"
  !insertmacro RemoveVideo ".mpeg"
  !insertmacro RemoveVideo ".mpg"
  !insertmacro RemoveVideo ".3gp"
  !insertmacro RemoveVideo ".ts"
  !insertmacro RemovePhoto ".jpg"
  !insertmacro RemovePhoto ".jpeg"
  !insertmacro RemovePhoto ".png"
  !insertmacro RemovePhoto ".bmp"
  !insertmacro RemovePhoto ".gif"
  !insertmacro RemovePhoto ".tif"
  !insertmacro RemovePhoto ".tiff"
  DeleteRegKey HKCU "${UNINSTALL_KEY}"
  DeleteRegKey HKCU "Software\Classes\.compi-exportando"
  DeleteRegKey HKCU "Software\Classes\Compi.ExportStatus"
  DeleteRegKey HKCU "Software\Classes\Applications\Compi.exe"
  DeleteRegKey HKCU "Software\Classes\Compi.Media"
  System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, p 0, p 0)'

  Delete "$SMPROGRAMS\Compi\Compi.lnk"
  RMDir "$SMPROGRAMS\Compi"
  Delete "$INSTDIR\Compi.exe"
  Delete "$INSTDIR\Compi.ps1"
  Delete "$INSTDIR\PhotoTools.cs"
  Delete "$INSTDIR\VideoTools.cs"
  Delete "$INSTDIR\Worker.ps1"
  Delete "$INSTDIR\Register-ExplorerIntegration.ps1"
  Delete "$INSTDIR\ExplorerIntegration.status"
  Delete "$INSTDIR\CompiExplorerCommand.dll"
  Delete "$INSTDIR\Compi.ContextMenu.msix"
  Delete "$INSTDIR\VERSION"
  Delete "$INSTDIR\README.md"
  Delete "$INSTDIR\assets\Compi.ico"
  Delete "$INSTDIR\assets\Compi-icon.png"
  RMDir "$INSTDIR\assets"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
SectionEnd
