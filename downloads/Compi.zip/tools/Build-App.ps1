$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
& (Join-Path $PSScriptRoot 'Build-Icon.ps1')
$icon = Join-Path $repo 'assets\Compi.ico'
if (-not (Test-Path -LiteralPath $icon)) { throw 'No se pudo generar el icono.' }

$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) { throw 'No se encontró el compilador de .NET Framework.' }
$automation = Join-Path $env:WINDIR 'Microsoft.Net\assembly\GAC_MSIL\System.Management.Automation\v4.0_3.0.0.0__31bf3856ad364e35\System.Management.Automation.dll'
if (-not (Test-Path -LiteralPath $automation)) { throw 'No se encontró Windows PowerShell 5.1.' }
$source = Join-Path $PSScriptRoot 'CompiLauncher.cs'
$output = Join-Path $repo 'Compi.exe'
$version = (Get-Content -LiteralPath (Join-Path $repo 'VERSION') -Raw -Encoding UTF8).Trim()
if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'VERSION debe tener el formato 1.0.0.' }
$generatedSource = Join-Path ([IO.Path]::GetTempPath()) ('CompiLauncher-' + [guid]::NewGuid().ToString('N') + '.cs')
$code = [IO.File]::ReadAllText($source).Replace('__ASSEMBLY_VERSION__', ($version + '.0')).Replace('__DISPLAY_VERSION__', $version)
[IO.File]::WriteAllText($generatedSource, $code, [Text.UTF8Encoding]::new($false))

try {
    & $compiler /nologo /target:winexe /platform:x64 "/out:$output" "/win32icon:$icon" "/reference:$automation" /reference:System.Windows.Forms.dll $generatedSource
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo compilar Compi.exe.' }
} finally {
    Remove-Item -LiteralPath $generatedSource -Force -ErrorAction SilentlyContinue
}
