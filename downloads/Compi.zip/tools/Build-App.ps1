$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
& (Join-Path $PSScriptRoot 'Build-Icon.ps1')
$icon = Join-Path $repo 'assets\Compi.ico'
if (-not (Test-Path -LiteralPath $icon)) { throw 'No se pudo generar el icono.' }

$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) { throw 'No se encontró el compilador de .NET Framework.' }
$automation = [System.Management.Automation.PSObject].Assembly.Location
$source = Join-Path $PSScriptRoot 'CompiLauncher.cs'
$output = Join-Path $repo 'Compi.exe'

& $compiler /nologo /target:winexe /platform:x64 "/out:$output" "/win32icon:$icon" "/reference:$automation" /reference:System.Windows.Forms.dll $source
if ($LASTEXITCODE -ne 0) { throw 'No se pudo compilar Compi.exe.' }
