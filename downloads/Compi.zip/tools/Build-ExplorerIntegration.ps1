param(
    [Parameter(Mandatory=$true)][string]$OutputDirectory,
    [string]$CertificateThumbprint,
    [string]$Publisher = 'CN=GB-Films',
    [string]$VcVarsPath = 'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat',
    [string]$SdkBin = 'C:\Program Files (x86)\Windows Kits\10\bin\10.0.22621.0\x64'
)
$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
if (-not (Test-Path -LiteralPath $VcVarsPath)) { throw 'Falta el compilador C++ x64. Indicá -VcVarsPath.' }
$version = (Get-Content -LiteralPath (Join-Path $repo 'VERSION') -Raw -Encoding UTF8).Trim() + '.0'
$source = Join-Path $PSScriptRoot 'CompiExplorerCommand.cpp'
$dll = Join-Path $OutputDirectory 'CompiExplorerCommand.dll'
$object = Join-Path $OutputDirectory 'CompiExplorerCommand.obj'
$library = Join-Path $OutputDirectory 'CompiExplorerCommand.lib'
$exports = Join-Path $PSScriptRoot 'CompiExplorerCommand.def'
$nativeBuild = '"' + $VcVarsPath + '" >nul && cl.exe /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /LD /DUNICODE /D_UNICODE "' + $source + '" /Fo"' + $object + '" /link /DEF:"' + $exports + '" /OUT:"' + $dll + '" /IMPLIB:"' + $library + '" shell32.lib shlwapi.lib ole32.lib uuid.lib'
$nativeStart = [Diagnostics.ProcessStartInfo]::new($env:ComSpec, '/d /s /c "' + $nativeBuild + '"')
$nativeStart.UseShellExecute = $false
$nativeStart.CreateNoWindow = $true
$nativeStart.RedirectStandardOutput = $true
$nativeStart.RedirectStandardError = $true
$nativeProcess = [Diagnostics.Process]::Start($nativeStart)
$nativeOutput = $nativeProcess.StandardOutput.ReadToEndAsync()
$nativeError = $nativeProcess.StandardError.ReadToEndAsync()
$nativeProcess.WaitForExit()
Write-Host $nativeOutput.Result
Write-Host $nativeError.Result
if ($nativeProcess.ExitCode -ne 0) { throw 'No se pudo compilar la extensión nativa.' }

$certificate = $null
if ($CertificateThumbprint) {
    $certificate = Get-Item -LiteralPath ('Cert:\CurrentUser\My\' + $CertificateThumbprint) -ErrorAction Stop
    if (-not $certificate.HasPrivateKey) { throw 'El certificado de firma no tiene clave privada.' }
    $Publisher = $certificate.Subject
}
$layout = Join-Path $OutputDirectory 'layout'
New-Item -ItemType Directory -Path (Join-Path $layout 'assets') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $repo 'assets\Compi-icon.png') -Destination (Join-Path $layout 'assets\Compi-icon.png') -Force
$manifest = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'ExplorerPackage.appxmanifest'))
$manifest = $manifest.Replace('__VERSION__', $version).Replace('__PUBLISHER__', [Security.SecurityElement]::Escape($Publisher))
[IO.File]::WriteAllText((Join-Path $layout 'AppxManifest.xml'), $manifest, [Text.UTF8Encoding]::new($false))
$package = Join-Path $OutputDirectory 'Compi.ContextMenu.msix'
& (Join-Path $SdkBin 'makeappx.exe') pack /d $layout /p $package /nv /o
if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear el paquete de identidad de Compi.' }
if ($certificate) {
    foreach ($file in @($dll, (Join-Path $repo 'Compi.exe'), $package)) {
        & (Join-Path $SdkBin 'signtool.exe') sign /sha1 $CertificateThumbprint /fd SHA256 /tr 'http://timestamp.digicert.com' /td SHA256 $file
        if ($LASTEXITCODE -ne 0) { throw "No se pudo firmar $file." }
        & (Join-Path $SdkBin 'signtool.exe') verify /pa $file
        if ($LASTEXITCODE -ne 0) { throw "Windows no confía en la firma de $file. No se incorporará al instalador." }
    }
} else {
    Write-Warning 'Paquete sin firma: solo sirve para revisar el código y empaquetado. No se registra ni cambia la seguridad de Windows.'
}
Write-Output $package
