using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Threading;
using System.Windows.Forms;

[DataContract]
internal sealed class QuickExportJob
{
    [DataMember(Name = "input")] public string Input;
    [DataMember(Name = "directory")] public string Directory;
    [DataMember(Name = "mode")] public string Mode;
}

[DataContract]
internal sealed class QuickExportStatus
{
    [DataMember(Name = "state")] public string State { get; set; }
    [DataMember(Name = "message")] public string Message { get; set; }
    [DataMember(Name = "progress")] public int Progress { get; set; }
    [DataMember(Name = "output")] public string Output { get; set; }
}

internal sealed class QuickExport : ApplicationContext
{
    private static readonly string[] VideoExtensions = { ".mp4", ".mov", ".mkv", ".avi", ".webm", ".wmv", ".m4v", ".mpeg", ".mpg", ".3gp", ".ts" };
    private readonly string source;
    private readonly string jobDirectory;
    private readonly string statusPath;
    private readonly string cancelPath;
    private readonly NotifyIcon tray;
    private readonly Icon icon;
    private readonly ContextMenuStrip menu;
    private readonly ToolStripMenuItem cancelItem;
    private readonly ToolStripMenuItem openItem;
    private readonly ToolStripMenuItem detailsItem;
    private readonly System.Windows.Forms.Timer timer;
    private readonly ExportNotice notice;
    private readonly EventWaitHandle showNotice;
    private string markerPath;
    private string markerStem;
    private int markerProgress = -1;
    private Process worker;
    private string outputPath;
    private string errorMessage;
    private bool finished;
    private DateTime finishedAt;
    private int missingStatusTicks;

    internal QuickExport(string inputPath)
    {
        if (String.IsNullOrWhiteSpace(inputPath) || !File.Exists(inputPath))
            throw new FileNotFoundException("No se encontró el video seleccionado.", inputPath);
        source = Path.GetFullPath(inputPath);
        string extension = Path.GetExtension(source);
        if (Array.Find(VideoExtensions, item => String.Equals(item, extension, StringComparison.OrdinalIgnoreCase)) == null)
            throw new InvalidOperationException("Este formato de video no es compatible con Compi.");

        jobDirectory = Path.Combine(Path.GetTempPath(), "compi-quick-" + Guid.NewGuid().ToString("N"));
        statusPath = Path.Combine(jobDirectory, "status.json");
        cancelPath = Path.Combine(jobDirectory, "cancel");
        Directory.CreateDirectory(jobDirectory);
        showNotice = new EventWaitHandle(false, EventResetMode.AutoReset, ShowEventName(jobDirectory));
        notice = new ExportNotice(source);
        notice.CancelRequested += delegate { RequestCancel(); };
        notice.OpenRequested += delegate { OpenOutput(); };

        icon = Icon.ExtractAssociatedIcon(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Compi.exe"));
        menu = new ContextMenuStrip();
        ToolStripMenuItem stateItem = new ToolStripMenuItem("Reexportando a 10 MB...") { Enabled = false };
        cancelItem = new ToolStripMenuItem("Cancelar reexportación");
        openItem = new ToolStripMenuItem("Mostrar archivo") { Visible = false };
        detailsItem = new ToolStripMenuItem("Ver error") { Visible = false };
        cancelItem.Click += delegate { RequestCancel(); };
        openItem.Click += delegate { OpenOutput(); };
        detailsItem.Click += delegate { ShowError(); };
        menu.Items.Add(stateItem);
        menu.Items.Add(new ToolStripSeparator());
        ToolStripMenuItem showItem = new ToolStripMenuItem("Mostrar avance");
        showItem.Click += delegate { notice.ShowNotice(true); };
        menu.Items.Add(showItem);
        menu.Items.Add(cancelItem);
        menu.Items.Add(openItem);
        menu.Items.Add(detailsItem);
        tray = new NotifyIcon { Icon = icon, Text = "Compi · Reexportando video", ContextMenuStrip = menu, Visible = true };
        tray.DoubleClick += delegate { notice.ShowNotice(true); };
        timer = new System.Windows.Forms.Timer { Interval = 500 };
        timer.Tick += OnTick;

        try
        {
            string jobPath = Path.Combine(jobDirectory, "job.json");
            using (FileStream stream = new FileStream(jobPath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                new DataContractJsonSerializer(typeof(QuickExportJob)).WriteObject(stream,
                    new QuickExportJob { Input = source, Directory = jobDirectory, Mode = "10mb" });
            CreateMarker();
            string script = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Worker.ps1");
            if (!File.Exists(script)) throw new FileNotFoundException("Falta Worker.ps1 junto a Compi.", script);
            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), @"System32\WindowsPowerShell\v1.0\powershell.exe");
            start.Arguments = "-NoProfile -ExecutionPolicy Bypass -NonInteractive -WindowStyle Hidden -File \"" + script + "\" -JobFile \"" + jobPath + "\"";
            start.UseShellExecute = false;
            start.CreateNoWindow = true;
            worker = Process.Start(start);
            if (worker == null) throw new InvalidOperationException("No se pudo iniciar la reexportación.");
            notice.ShowNotice(false);
            timer.Start();
        }
        catch
        {
            tray.Visible = false;
            tray.Dispose();
            menu.Dispose();
            timer.Dispose();
            icon.Dispose();
            notice.Dispose();
            showNotice.Dispose();
            RemoveMarker();
            CleanupJob();
            throw;
        }
    }

    private void OnTick(object sender, EventArgs e)
    {
        if (showNotice.WaitOne(0)) notice.ShowNotice(true);
        notice.ShowNotice(false);
        if (finished)
        {
            RemoveMarker();
            if ((DateTime.UtcNow - finishedAt).TotalSeconds >= 25) ExitThread();
            return;
        }
        if (File.Exists(statusPath))
        {
            try
            {
                string json = File.ReadAllText(statusPath);
                using (MemoryStream stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(json)))
                {
                    QuickExportStatus status = (QuickExportStatus)new DataContractJsonSerializer(typeof(QuickExportStatus)).ReadObject(stream);
                    if (status.State == "done") { Complete(status.Output); return; }
                    if (status.State == "error") { Fail(status.Message); return; }
                    if (status.State == "cancelled") { Cancelled(); return; }
                    int progress = Math.Max(0, Math.Min(100, status.Progress));
                    tray.Text = "Compi · Reexportando video (" + progress + "%)";
                    notice.UpdateProgress(progress, status.Message);
                    UpdateMarker(progress);
                }
            }
            catch (IOException) { }
            catch (SerializationException) { }
        }
        if (worker != null && worker.HasExited && ++missingStatusTicks >= 4)
            Fail("El proceso terminó sin informar el resultado.");
    }

    private void Complete(string path)
    {
        if (String.IsNullOrWhiteSpace(path) || !File.Exists(path))
        {
            Fail("La reexportación terminó, pero no se encontró el archivo de salida.");
            return;
        }
        outputPath = path;
        finished = true;
        finishedAt = DateTime.UtcNow;
        cancelItem.Visible = false;
        openItem.Visible = true;
        menu.Items[0].Text = "Video listo";
        tray.Text = "Compi · Video listo";
        RemoveMarker();
        notice.Complete(path);
    }

    private void Fail(string message)
    {
        errorMessage = String.IsNullOrWhiteSpace(message) ? "No se pudo reexportar el video." : message;
        finished = true;
        finishedAt = DateTime.UtcNow;
        cancelItem.Visible = false;
        detailsItem.Visible = true;
        menu.Items[0].Text = "Ocurrió un error";
        tray.Text = "Compi · No se pudo reexportar";
        RemoveMarker();
        notice.Failed(errorMessage, false);
    }

    private void Cancelled()
    {
        finished = true;
        finishedAt = DateTime.UtcNow;
        cancelItem.Visible = false;
        menu.Items[0].Text = "Reexportación cancelada";
        tray.Text = "Compi · Reexportación cancelada";
        RemoveMarker();
        notice.Failed("Reexportación cancelada", true);
    }

    private void RequestCancel()
    {
        if (finished) return;
        try { File.WriteAllText(cancelPath, String.Empty); cancelItem.Enabled = false; menu.Items[0].Text = "Cancelando..."; notice.Cancelling(); }
        catch (Exception error) { MessageBox.Show(error.Message, "Compi", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void OpenOutput()
    {
        if (String.IsNullOrEmpty(outputPath) || !File.Exists(outputPath)) return;
        try { Process.Start("explorer.exe", "/select,\"" + outputPath + "\""); }
        catch (Exception error) { MessageBox.Show(error.Message, "Compi", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void ShowError()
    {
        if (!String.IsNullOrEmpty(errorMessage)) MessageBox.Show(errorMessage, "Compi", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    private static string ShowEventName(string directory)
    {
        return "Local\\Compi.Export.Show." + Path.GetFileName(directory);
    }

    internal static void ShowStatus(string marker)
    {
        QuickExportJob job;
        if (!File.Exists(marker))
        {
            string name = Path.GetFileName(marker);
            int suffixStart = name.LastIndexOf("(Compi ", StringComparison.Ordinal);
            if (suffixStart >= 0)
            {
                string suffix = name.Substring(suffixStart);
                foreach (string candidate in Directory.EnumerateFiles(Path.GetDirectoryName(Path.GetFullPath(marker)), "*.compi-exportando"))
                    if (candidate.EndsWith(suffix, StringComparison.OrdinalIgnoreCase)) { marker = candidate; break; }
            }
        }
        using (FileStream stream = new FileStream(marker, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            job = (QuickExportJob)new DataContractJsonSerializer(typeof(QuickExportJob)).ReadObject(stream);
        string tempRoot = Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        string directory = Path.GetFullPath(job.Directory);
        if (!directory.StartsWith(tempRoot + "compi-quick-", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Este archivo no corresponde a una reexportación de Compi.");
        try { using (EventWaitHandle handle = EventWaitHandle.OpenExisting(ShowEventName(directory))) handle.Set(); }
        catch (WaitHandleCannotBeOpenedException) { MessageBox.Show("Esta reexportación ya terminó. Revisá la carpeta del video original.", "Compi", MessageBoxButtons.OK, MessageBoxIcon.Information); }
    }

    private void CreateMarker()
    {
        string id = Path.GetFileName(jobDirectory).Substring("compi-quick-".Length, 8);
        string parent = Path.GetDirectoryName(source);
        string baseName = Path.GetFileNameWithoutExtension(source);
        int available = Math.Min(120, 240 - parent.Length - 1 - ("_reexportado — EXPORTANDO 100% (Compi " + id + ").compi-exportando").Length);
        if (available < 1) throw new InvalidOperationException("La ruta de esta carpeta es demasiado larga para crear la señal de avance.");
        if (baseName.Length > available) baseName = baseName.Substring(0, available);
        markerStem = Path.Combine(parent, baseName + "_reexportado — EXPORTANDO");
        markerPath = markerStem + " (Compi " + id + ").compi-exportando";
        using (FileStream stream = new FileStream(markerPath, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
            new DataContractJsonSerializer(typeof(QuickExportJob)).WriteObject(stream,
                new QuickExportJob { Input = source, Directory = jobDirectory, Mode = "10mb" });
    }

    private void UpdateMarker(int progress)
    {
        int value = (progress / 5) * 5;
        if (value == markerProgress || String.IsNullOrEmpty(markerPath)) return;
        string id = Path.GetFileName(jobDirectory).Substring("compi-quick-".Length, 8);
        string next = markerStem + " " + value + "% (Compi " + id + ").compi-exportando";
        try { File.Move(markerPath, next); markerPath = next; markerProgress = value; }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private void RemoveMarker()
    {
        try { if (!String.IsNullOrEmpty(markerPath) && File.Exists(markerPath)) File.Delete(markerPath); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private void CleanupJob()
    {
        try
        {
            if (worker != null && !worker.HasExited) return;
            string tempRoot = Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string fullJob = Path.GetFullPath(jobDirectory).TrimEnd(Path.DirectorySeparatorChar);
            if (fullJob.StartsWith(tempRoot + "compi-quick-", StringComparison.OrdinalIgnoreCase) && Directory.Exists(fullJob))
                Directory.Delete(fullJob, true);
        }
        catch { }
    }

    protected override void ExitThreadCore()
    {
        timer.Stop();
        tray.Visible = false;
        tray.Dispose();
        menu.Dispose();
        timer.Dispose();
        icon.Dispose();
        notice.Dispose();
        showNotice.Dispose();
        RemoveMarker();
        if (worker != null) { CleanupJob(); worker.Dispose(); }
        base.ExitThreadCore();
    }
}
