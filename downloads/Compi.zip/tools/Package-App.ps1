param([string]$OutputDirectory)

$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
if (-not $OutputDirectory) { $OutputDirectory = Join-Path $repo 'dist' }
$version = (Get-Content -LiteralPath (Join-Path $repo 'VERSION') -Raw -Encoding UTF8).Trim()
if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'VERSION debe tener el formato 1.0.0.' }

& (Join-Path $PSScriptRoot 'Build-App.ps1')
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$zipPath = Join-Path $OutputDirectory ('Compi v' + $version + '.zip')
$contents = @('Compi.exe', 'Compi.cmd', 'Instalar menu de Compi.cmd', 'Quitar menu de Compi.cmd', 'Compi.ps1', 'VERSION', 'PhotoTools.cs', 'VideoTools.cs', 'Worker.ps1', 'Reexportar.cmd', 'README.md', 'PUBLICACION.md', 'assets', 'tools', 'tests') |
    ForEach-Object { Join-Path $repo $_ }
Compress-Archive -LiteralPath $contents -DestinationPath $zipPath -Force
Write-Output $zipPath
