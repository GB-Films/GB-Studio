using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

// A non-activating notice: exports continue without taking focus from Explorer.
internal sealed class ExportNotice : Form
{
    private static readonly Color Black = Color.FromArgb(8, 9, 10);
    private static readonly Color White = Color.FromArgb(248, 248, 246);
    private static readonly Color Muted = Color.FromArgb(164, 166, 169);
    private static readonly Color Pink = Color.FromArgb(227, 8, 126);
    private readonly Label heading;
    private readonly PictureBox brandIcon;
    private readonly Label fileName;
    private readonly Label message;
    private readonly Label stage;
    private readonly Label percentage;
    private readonly Panel track;
    private readonly Button action;
    private readonly System.Windows.Forms.Timer animation;
    private Mutex slot;
    private bool dismissed;
    private bool terminal;
    private int progress;
    private int pulse;
    internal event EventHandler CancelRequested;
    internal event EventHandler OpenRequested;

    protected override bool ShowWithoutActivation { get { return true; } }
    protected override CreateParams CreateParams
    {
        get { CreateParams parameters = base.CreateParams; parameters.ExStyle |= 0x08000000 | 0x00000080; return parameters; }
    }

    internal ExportNotice(string source)
    {
        Text = "COMPI · Reexportación";
        ClientSize = new Size(438, 224);
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false;
        TopMost = true;
        AutoScaleMode = AutoScaleMode.Dpi;
        BackColor = Black;
        ForeColor = White;
        Font = new Font("Segoe UI", 9);
        Paint += delegate(object sender, PaintEventArgs e) {
            using (Pen pen = new Pen(Color.FromArgb(69, 72, 76))) e.Graphics.DrawRectangle(pen, 0, 0, ClientSize.Width - 1, ClientSize.Height - 1);
        };
        Controls.Add(new Panel { Location = new Point(0, 0), Size = new Size(4, 224), BackColor = Pink });
        brandIcon = new PictureBox { Location = new Point(22, 18), Size = new Size(28, 28), SizeMode = PictureBoxSizeMode.Zoom };
        string iconPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "Compi-icon.png");
        if (System.IO.File.Exists(iconPath))
            using (Image image = Image.FromFile(iconPath)) brandIcon.Image = new Bitmap(image);
        else
            using (Icon icon = Icon.ExtractAssociatedIcon(System.Reflection.Assembly.GetExecutingAssembly().Location))
                brandIcon.Image = icon.ToBitmap();
        Controls.Add(brandIcon);
        Button close = new Button { Text = "×", Location = new Point(393, 12), Size = new Size(28, 28), FlatStyle = FlatStyle.Flat,
            BackColor = Black, ForeColor = Muted, Font = new Font("Segoe UI", 15), TabStop = false };
        close.FlatAppearance.BorderSize = 0;
        close.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 32, 35);
        close.Click += delegate { dismissed = true; HideNotice(); };
        Controls.Add(close);
        heading = Label("COMPI — REEXPORTANDO VIDEO", 60, 20, 331, 28, 16, White, true);
        fileName = Label(System.IO.Path.GetFileName(source), 23, 63, 390, 22, 9, Muted, false);
        message = Label("Tu video se está exportando. Te avisaremos cuando esté listo.", 23, 95, 390, 42, 10, White, false);
        stage = Label("Preparando la reexportación...", 23, 150, 320, 20, 9, Muted, false);
        percentage = Label("", 356, 150, 56, 20, 9, Pink, true);
        percentage.TextAlign = ContentAlignment.TopRight;
        Controls.Add(heading); Controls.Add(fileName); Controls.Add(message); Controls.Add(stage); Controls.Add(percentage);
        track = new Panel { Location = new Point(23, 175), Size = new Size(389, 4), BackColor = Color.FromArgb(69, 72, 76) };
        track.Paint += delegate(object sender, PaintEventArgs e) {
            int width = progress > 0 ? (int)Math.Round(track.Width * progress / 100.0) : 85;
            using (SolidBrush brush = new SolidBrush(Pink)) e.Graphics.FillRectangle(brush, progress > 0 ? 0 : pulse, 0, width, track.Height);
        };
        Controls.Add(track);
        action = new Button { Text = "CANCELAR", Location = new Point(288, 187), Size = new Size(124, 27), FlatStyle = FlatStyle.Flat,
            BackColor = Black, ForeColor = Muted, Font = new Font("Bahnschrift SemiBold Condensed", 10, FontStyle.Bold), Cursor = Cursors.Hand };
        action.FlatAppearance.BorderSize = 0;
        action.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 32, 35);
        action.Click += delegate { if (terminal) { if (OpenRequested != null) OpenRequested(this, EventArgs.Empty); } else if (CancelRequested != null) CancelRequested(this, EventArgs.Empty); };
        Controls.Add(action);
        animation = new System.Windows.Forms.Timer { Interval = 30 };
        animation.Tick += delegate {
            if (progress == 0) { pulse += 6; if (pulse > track.Width) pulse = -85; track.Invalidate(); }
        };
        animation.Start();
    }

    private static Label Label(string text, int x, int y, int width, int height, float size, Color color, bool condensed)
    {
        return new Label { Text = text, Location = new Point(x, y), Size = new Size(width, height), ForeColor = color,
            BackColor = Color.Transparent, AutoEllipsis = true,
            Font = new Font(condensed ? "Bahnschrift SemiBold Condensed" : "Segoe UI", size, condensed ? FontStyle.Bold : FontStyle.Regular) };
    }

    internal void ShowNotice(bool requested)
    {
        if (requested) dismissed = false;
        if (dismissed || Visible) return;
        Rectangle area = Screen.PrimaryScreen.WorkingArea;
        int capacity = Math.Max(1, (area.Height - 24) / (Height + 12));
        for (int index = 0; index < capacity; index++)
        {
            Mutex candidate = new Mutex(false, "Local\\Compi.ExportNotice.Slot." + index);
            bool acquired;
            try { acquired = candidate.WaitOne(0); } catch (AbandonedMutexException) { acquired = true; }
            if (!acquired) { candidate.Dispose(); continue; }
            slot = candidate;
            Location = new Point(area.Right - Width - 18, area.Bottom - Height - 18 - index * (Height + 12));
            Show();
            return;
        }
    }

    private void HideNotice()
    {
        Hide();
        if (slot != null) { slot.ReleaseMutex(); slot.Dispose(); slot = null; }
    }

    internal void UpdateProgress(int value, string status)
    {
        progress = Math.Max(0, Math.Min(100, value));
        percentage.Text = progress > 0 ? progress + "%" : "";
        stage.Text = String.IsNullOrWhiteSpace(status) ? "Reexportando video..." : status;
        track.Invalidate();
    }

    internal void Cancelling()
    {
        stage.Text = "Cancelando la reexportación...";
        action.Enabled = false;
    }

    internal void Complete(string output)
    {
        terminal = true;
        animation.Stop();
        heading.Text = "COMPI — TU VIDEO YA ESTÁ LISTO";
        fileName.Text = System.IO.Path.GetFileName(output);
        message.Text = "Lo guardamos junto al original. Ya podés usarlo.";
        stage.Text = "Reexportación completa";
        action.Text = "VER ARCHIVO";
        action.Enabled = true;
        action.ForeColor = Pink;
        UpdateProgress(100, "Reexportación completa");
        ShowNotice(true);
    }

    internal void Failed(string detail, bool cancelled)
    {
        terminal = true;
        animation.Stop();
        track.Visible = false;
        percentage.Visible = false;
        heading.Text = cancelled ? "COMPI — EXPORTACIÓN CANCELADA" : "COMPI — NO SE PUDO REEXPORTAR";
        message.Text = cancelled ? "El archivo original no se modificó." : "El original está intacto. Podés ver el detalle desde el ícono de Compi.";
        stage.Text = detail;
        action.Visible = false;
        ShowNotice(true);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { animation.Stop(); animation.Dispose(); HideNotice(); if (brandIcon.Image != null) brandIcon.Image.Dispose(); }
        base.Dispose(disposing);
    }
}
