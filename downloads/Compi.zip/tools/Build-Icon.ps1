$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$assets = Join-Path (Split-Path $PSScriptRoot -Parent) 'assets'
$iconPath = Join-Path $assets 'Compi.ico'
$previewPath = Join-Path $assets 'Compi-icon.png'
$sizes = @(16, 24, 32, 48, 64, 128, 256)
$frames = New-Object System.Collections.Generic.List[object]

foreach ($size in $sizes) {
    $scale = $size / 256.0
    $bitmap = [Drawing.Bitmap]::new($size, $size, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.Clear([Drawing.Color]::Transparent)

    $box = [Drawing.RectangleF]::new([float](8 * $scale), [float](8 * $scale), [float](240 * $scale), [float](240 * $scale))
    $radius = [float](38 * $scale)
    $path = [Drawing.Drawing2D.GraphicsPath]::new()
    $path.AddArc($box.Left, $box.Top, $radius, $radius, 180, 90)
    $path.AddArc($box.Right - $radius, $box.Top, $radius, $radius, 270, 90)
    $path.AddArc($box.Right - $radius, $box.Bottom - $radius, $radius, $radius, 0, 90)
    $path.AddArc($box.Left, $box.Bottom - $radius, $radius, $radius, 90, 90)
    $path.CloseFigure()
    $background = [Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(8, 9, 10))
    $graphics.FillPath($background, $path)
    $border = [Drawing.Pen]::new([Drawing.Color]::FromArgb(180, 255, 255, 255), [float]([Math]::Max(1, 5 * $scale)))
    $graphics.DrawPath($border, $path)

    $stroke = [Drawing.Pen]::new([Drawing.Color]::White, [float]([Math]::Max(2, 21 * $scale)))
    $stroke.StartCap = [Drawing.Drawing2D.LineCap]::Round
    $stroke.EndCap = [Drawing.Drawing2D.LineCap]::Round
    $stroke.LineJoin = [Drawing.Drawing2D.LineJoin]::Round
    $graphics.DrawLine($stroke, [float](70 * $scale), [float](78 * $scale), [float](128 * $scale), [float](128 * $scale))
    $graphics.DrawLine($stroke, [float](128 * $scale), [float](128 * $scale), [float](70 * $scale), [float](178 * $scale))
    $graphics.DrawLine($stroke, [float](141 * $scale), [float](181 * $scale), [float](190 * $scale), [float](181 * $scale))

    if ($size -eq 256) { $bitmap.Save($previewPath, [Drawing.Imaging.ImageFormat]::Png) }
    $stream = [IO.MemoryStream]::new()
    $bitmap.Save($stream, [Drawing.Imaging.ImageFormat]::Png)
    $frames.Add(@{ size = $size; bytes = $stream.ToArray() })

    $stream.Dispose()
    $stroke.Dispose()
    $border.Dispose()
    $background.Dispose()
    $path.Dispose()
    $graphics.Dispose()
    $bitmap.Dispose()
}

$file = [IO.File]::Open($iconPath, [IO.FileMode]::Create)
$writer = [IO.BinaryWriter]::new($file)
try {
    $writer.Write([int16]0)
    $writer.Write([int16]1)
    $writer.Write([int16]$frames.Count)
    $offset = 6 + 16 * $frames.Count
    foreach ($frame in $frames) {
        $dimension = if ($frame.size -eq 256) { 0 } else { $frame.size }
        $writer.Write([byte]$dimension)
        $writer.Write([byte]$dimension)
        $writer.Write([byte]0)
        $writer.Write([byte]0)
        $writer.Write([int16]1)
        $writer.Write([int16]32)
        $writer.Write([int32]$frame.bytes.Length)
        $writer.Write([int32]$offset)
        $offset += $frame.bytes.Length
    }
    foreach ($frame in $frames) { $writer.Write([byte[]]$frame.bytes) }
} finally {
    $writer.Dispose()
}
