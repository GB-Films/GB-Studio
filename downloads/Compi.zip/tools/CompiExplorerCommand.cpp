#include <windows.h>
#include <shobjidl.h>
#include <shlwapi.h>
#include <new>
#include <string>

// Native COM extension: Explorer only builds the menu here; Compi owns the export.
static HMODULE module;
static LONG moduleReferences = 0;
static const CLSID CommandId = {0x6b72dcc8, 0x0ec3, 0x4a17, {0xa8, 0x2e, 0x29, 0x1a, 0xb3, 0xf0, 0x96, 0x12}};

static std::wstring Executable()
{
    wchar_t path[32768];
    DWORD length = GetModuleFileNameW(module, path, ARRAYSIZE(path));
    if (!length || length >= ARRAYSIZE(path)) return {};
    std::wstring result(path, length);
    auto separator = result.find_last_of(L"\\/");
    return separator == std::wstring::npos ? std::wstring() : result.substr(0, separator + 1) + L"Compi.exe";
}

static HRESULT VideoPath(IShellItemArray* items, DWORD index, PWSTR* path)
{
    *path = nullptr;
    IShellItem* item = nullptr;
    HRESULT result = items->GetItemAt(index, &item);
    if (FAILED(result)) return result;
    SFGAOF attributes = 0;
    result = item->GetAttributes(SFGAO_FOLDER, &attributes);
    if (FAILED(result) || (attributes & SFGAO_FOLDER)) { item->Release(); return E_INVALIDARG; }
    result = item->GetDisplayName(SIGDN_FILESYSPATH, path);
    item->Release();
    if (FAILED(result)) return result;
    const wchar_t* extension = PathFindExtensionW(*path);
    const wchar_t* supported[] = {L".mp4", L".mov", L".mkv", L".avi", L".webm", L".wmv", L".m4v", L".mpeg", L".mpg", L".3gp", L".ts"};
    for (auto candidate : supported) if (_wcsicmp(extension, candidate) == 0) return S_OK;
    CoTaskMemFree(*path); *path = nullptr;
    return E_INVALIDARG;
}

class ExportCommand final : public IExplorerCommand
{
    LONG references = 1;
public:
    ExportCommand() { InterlockedIncrement(&moduleReferences); }
    ~ExportCommand() { InterlockedDecrement(&moduleReferences); }
    IFACEMETHODIMP QueryInterface(REFIID id, void** value) override
    {
        if (!value) return E_POINTER;
        *value = nullptr;
        if (id == IID_IUnknown || id == __uuidof(IExplorerCommand)) { *value = static_cast<IExplorerCommand*>(this); AddRef(); return S_OK; }
        return E_NOINTERFACE;
    }
    IFACEMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&references); }
    IFACEMETHODIMP_(ULONG) Release() override { ULONG count = InterlockedDecrement(&references); if (!count) delete this; return count; }
    IFACEMETHODIMP GetTitle(IShellItemArray*, PWSTR* title) override
    { return title ? SHStrDupW(L"Reexportar con Compi", title) : E_POINTER; }
    IFACEMETHODIMP GetIcon(IShellItemArray*, PWSTR* icon) override
    {
        if (!icon) return E_POINTER;
        *icon = nullptr;
        try { std::wstring path = Executable(); return path.empty() ? E_FAIL : SHStrDupW((L"\"" + path + L"\",0").c_str(), icon); }
        catch (...) { return E_OUTOFMEMORY; }
    }
    IFACEMETHODIMP GetToolTip(IShellItemArray*, PWSTR* tip) override
    { return tip ? SHStrDupW(L"Reexportar a 10 MB en segundo plano, sin modificar el original", tip) : E_POINTER; }
    IFACEMETHODIMP GetCanonicalName(GUID* name) override { if (!name) return E_POINTER; *name = CommandId; return S_OK; }
    IFACEMETHODIMP GetState(IShellItemArray* items, BOOL, EXPCMDSTATE* state) override
    {
        if (!state) return E_POINTER;
        *state = ECS_HIDDEN;
        DWORD count = 0;
        if (!items || FAILED(items->GetCount(&count)) || count == 0) return S_OK;
        for (DWORD i = 0; i < count; ++i)
        {
            PWSTR path = nullptr;
            HRESULT result = VideoPath(items, i, &path);
            CoTaskMemFree(path);
            if (FAILED(result)) return S_OK;
        }
        *state = ECS_ENABLED;
        return S_OK;
    }
    IFACEMETHODIMP Invoke(IShellItemArray* items, IBindCtx*) override
    {
        if (!items) return E_INVALIDARG;
        try
        {
            std::wstring executable = Executable();
            if (executable.empty()) return E_FAIL;
            DWORD count = 0;
            HRESULT result = items->GetCount(&count);
            if (FAILED(result) || count == 0) return E_INVALIDARG;
            HRESULT firstFailure = S_OK;
            for (DWORD i = 0; i < count; ++i)
            {
                PWSTR path = nullptr;
                result = VideoPath(items, i, &path);
                if (FAILED(result)) { if (SUCCEEDED(firstFailure)) firstFailure = result; continue; }
                std::wstring arguments = L"\"" + executable + L"\" --quick-video \"" + path + L"\"";
                CoTaskMemFree(path);
                STARTUPINFOW start = {}; start.cb = sizeof(start);
                PROCESS_INFORMATION process = {};
                if (!CreateProcessW(executable.c_str(), &arguments[0], nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &start, &process))
                { if (SUCCEEDED(firstFailure)) firstFailure = HRESULT_FROM_WIN32(GetLastError()); }
                else { CloseHandle(process.hThread); CloseHandle(process.hProcess); }
            }
            return firstFailure;
        }
        catch (...) { return E_OUTOFMEMORY; }
    }
    IFACEMETHODIMP GetFlags(EXPCMDFLAGS* flags) override { if (!flags) return E_POINTER; *flags = ECF_DEFAULT; return S_OK; }
    IFACEMETHODIMP EnumSubCommands(IEnumExplorerCommand** commands) override { if (!commands) return E_POINTER; *commands = nullptr; return E_NOTIMPL; }
};

class Factory final : public IClassFactory
{
    LONG references = 1;
public:
    Factory() { InterlockedIncrement(&moduleReferences); }
    ~Factory() { InterlockedDecrement(&moduleReferences); }
    IFACEMETHODIMP QueryInterface(REFIID id, void** value) override
    {
        if (!value) return E_POINTER;
        *value = nullptr;
        if (id == IID_IUnknown || id == IID_IClassFactory) { *value = static_cast<IClassFactory*>(this); AddRef(); return S_OK; }
        return E_NOINTERFACE;
    }
    IFACEMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&references); }
    IFACEMETHODIMP_(ULONG) Release() override { ULONG count = InterlockedDecrement(&references); if (!count) delete this; return count; }
    IFACEMETHODIMP CreateInstance(IUnknown* outer, REFIID id, void** value) override
    {
        if (!value) return E_POINTER;
        *value = nullptr;
        if (outer) return CLASS_E_NOAGGREGATION;
        ExportCommand* command = new(std::nothrow) ExportCommand();
        if (!command) return E_OUTOFMEMORY;
        HRESULT result = command->QueryInterface(id, value);
        command->Release(); return result;
    }
    IFACEMETHODIMP LockServer(BOOL lock) override { if (lock) InterlockedIncrement(&moduleReferences); else InterlockedDecrement(&moduleReferences); return S_OK; }
};

STDAPI DllGetClassObject(REFCLSID clsid, REFIID id, void** value)
{
    if (!value) return E_POINTER;
    *value = nullptr;
    if (clsid != CommandId) return CLASS_E_CLASSNOTAVAILABLE;
    Factory* factory = new(std::nothrow) Factory();
    if (!factory) return E_OUTOFMEMORY;
    HRESULT result = factory->QueryInterface(id, value); factory->Release(); return result;
}
STDAPI DllCanUnloadNow() { return moduleReferences == 0 ? S_OK : S_FALSE; }
BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID)
{ if (reason == DLL_PROCESS_ATTACH) module = instance; return TRUE; }
