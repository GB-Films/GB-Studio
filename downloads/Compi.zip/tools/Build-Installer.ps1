param(
    [string]$OutputDirectory,
    [string]$CompilerPath,
    [string]$ExplorerCertificateThumbprint
)

$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
$version = (Get-Content -LiteralPath (Join-Path $repo 'VERSION') -Raw -Encoding UTF8).Trim()
if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'VERSION debe tener el formato 1.0.0.' }

if (-not $OutputDirectory) { $OutputDirectory = Join-Path $repo 'dist' }
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)

if (-not $CompilerPath) {
    $found = Get-Command makensis.exe -ErrorAction SilentlyContinue
    if ($found) { $CompilerPath = $found.Source }
}
if (-not $CompilerPath) {
    foreach ($candidate in @(
        (Join-Path $env:LOCALAPPDATA 'Programs\NSIS\makensis.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'NSIS\makensis.exe'),
        (Join-Path $env:ProgramFiles 'NSIS\makensis.exe')
    )) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { $CompilerPath = $candidate; break }
    }
}
if (-not $CompilerPath -or -not (Test-Path -LiteralPath $CompilerPath -PathType Leaf)) {
    throw 'No se encontró makensis.exe. Instalá NSIS o pasá -CompilerPath.'
}

& (Join-Path $PSScriptRoot 'Build-App.ps1')
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$installerScript = Join-Path $PSScriptRoot 'Compi-Installer.nsi'
$installer = Join-Path $OutputDirectory "Compi-Setup-v$version.exe"
$workDir = Join-Path (Split-Path $repo -Parent) 'work'
New-Item -ItemType Directory -Path $workDir -Force | Out-Null
$buildId = [guid]::NewGuid().ToString('N')
$coreInstaller = Join-Path $workDir "Compi-Setup-Core-$buildId.exe"
$generatedSource = Join-Path $workDir "CompiInstallerUI-$buildId.cs"
$uiSource = Join-Path $PSScriptRoot 'CompiInstallerUI.cs'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler -PathType Leaf)) { throw 'No se encontró el compilador de .NET Framework.' }

try {
    $nsisOptions = @('/INPUTCHARSET', 'UTF8', "/DAPP_VERSION=$version", "/DREPO_ROOT=$repo", "/DOUTPUT_FILE=$coreInstaller")
    if ($ExplorerCertificateThumbprint) {
        $explorerDirectory = Join-Path $workDir "explorer-package-$buildId"
        & (Join-Path $PSScriptRoot 'Build-ExplorerIntegration.ps1') -OutputDirectory $explorerDirectory -CertificateThumbprint $ExplorerCertificateThumbprint
        $nsisOptions += "/DEXPLORER_PACKAGE_DIR=$explorerDirectory"
    }
    & $CompilerPath @nsisOptions $installerScript
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $coreInstaller -PathType Leaf)) {
        throw 'No se pudo compilar el instalador interno de Compi.'
    }

    $code = [IO.File]::ReadAllText($uiSource).Replace('__ASSEMBLY_VERSION__', ($version + '.0')).Replace('__DISPLAY_VERSION__', $version)
    [IO.File]::WriteAllText($generatedSource, $code, [Text.UTF8Encoding]::new($false))
    $icon = Join-Path $repo 'assets\Compi.ico'
    $logo = Join-Path $repo 'assets\Compi-icon.png'
    & $compiler /nologo /target:winexe /platform:x64 "/out:$installer" "/win32icon:$icon" "/resource:$coreInstaller,CompiSetupCore" "/resource:$logo,CompiLogo" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll $generatedSource
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo compilar la interfaz del instalador.' }
} finally {
    Remove-Item -LiteralPath $coreInstaller, $generatedSource -Force -ErrorAction SilentlyContinue
}

if (-not (Test-Path -LiteralPath $installer -PathType Leaf)) { throw 'El instalador no se generó.' }
Copy-Item -LiteralPath $installer -Destination (Join-Path $repo 'Compi-Setup.exe') -Force
Write-Output $installer
