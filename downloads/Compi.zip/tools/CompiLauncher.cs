using System;
using System.IO;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("Compi")]
[assembly: AssemblyDescription("Reexportacion de videos y fotos")]
[assembly: AssemblyCompany("Compi")]
[assembly: AssemblyProduct("Compi")]
[assembly: AssemblyVersion("__ASSEMBLY_VERSION__")]
[assembly: AssemblyFileVersion("__ASSEMBLY_VERSION__")]
[assembly: AssemblyInformationalVersion("__DISPLAY_VERSION__")]

internal static class CompiLauncher
{
    private static readonly string[] VideoExtensions = { ".mp4", ".mov", ".mkv", ".avi", ".webm", ".wmv", ".m4v", ".mpeg", ".mpg", ".3gp", ".ts" };
    private static readonly string[] PhotoExtensions = { ".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tif", ".tiff" };
    private const string VideoVerb = "Compi.ReexportVideo";
    private const string PhotoVerb = "Compi.OpenPhoto";

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SetCurrentProcessExplicitAppUserModelID(string appId);

    private static void RegisterVerb(string extension, string verb, string label, string mode, string executable)
    {
        string keyPath = "Software\\Classes\\SystemFileAssociations\\" + extension + "\\shell\\" + verb;
        using (RegistryKey key = Registry.CurrentUser.CreateSubKey(keyPath))
        {
            if (key == null) throw new InvalidOperationException("No se pudo registrar el menú para " + extension + ".");
            key.SetValue(null, label, RegistryValueKind.String);
            key.SetValue("Icon", executable, RegistryValueKind.String);
            using (RegistryKey command = key.CreateSubKey("command"))
            {
                if (command == null) throw new InvalidOperationException("No se pudo registrar el comando para " + extension + ".");
                command.SetValue(null, "\"" + executable + "\" --" + mode + " \"%1\"", RegistryValueKind.String);
            }
        }
    }

    private static void RemoveVerb(string extension, string verb)
    {
        Registry.CurrentUser.DeleteSubKeyTree("Software\\Classes\\SystemFileAssociations\\" + extension + "\\shell\\" + verb, false);
    }

    private static void RegisterContextMenu(string executable)
    {
        foreach (string extension in VideoExtensions)
            RegisterVerb(extension, VideoVerb, "Reexportar video con Compi", "video", executable);
        foreach (string extension in PhotoExtensions)
            RegisterVerb(extension, PhotoVerb, "Abrir foto con Compi", "photo", executable);
    }

    private static void RemoveContextMenu()
    {
        foreach (string extension in VideoExtensions) RemoveVerb(extension, VideoVerb);
        foreach (string extension in PhotoExtensions) RemoveVerb(extension, PhotoVerb);
    }

    private static bool WasClosedNormally(Runspace runspace)
    {
        try
        {
            return Object.Equals(runspace.SessionStateProxy.GetVariable("CompiClosedNormally"), true);
        }
        catch
        {
            return false;
        }
    }

    [STAThread]
    private static void Main(string[] args)
    {
        bool closedNormally = false;
        try
        {
            SetCurrentProcessExplicitAppUserModelID("Compi.Desktop");
            string executable = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Compi.exe");
            if (args.Length > 0 && String.Equals(args[0], "--install-context-menu", StringComparison.OrdinalIgnoreCase))
            {
                RegisterContextMenu(executable);
                MessageBox.Show("Listo. El menú de Compi quedó disponible al hacer clic derecho en videos y fotos.", "Compi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (args.Length > 0 && String.Equals(args[0], "--remove-context-menu", StringComparison.OrdinalIgnoreCase))
            {
                RemoveContextMenu();
                MessageBox.Show("Se quitaron los accesos de Compi del menú contextual.", "Compi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string launchMode = String.Empty;
            string launchPath = String.Empty;
            if (args.Length >= 2 && (String.Equals(args[0], "--video", StringComparison.OrdinalIgnoreCase) || String.Equals(args[0], "--photo", StringComparison.OrdinalIgnoreCase)))
            {
                launchMode = args[0].Substring(2).ToLowerInvariant();
                launchPath = args[1];
            }
            string script = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Compi.ps1");
            if (!File.Exists(script))
                throw new FileNotFoundException("No se encontro Compi.ps1 junto a la aplicacion.", script);

            using (Runspace runspace = RunspaceFactory.CreateRunspace())
            {
                runspace.ApartmentState = ApartmentState.STA;
                runspace.ThreadOptions = PSThreadOptions.UseCurrentThread;
                runspace.Open();
                runspace.SessionStateProxy.SetVariable("CompiRoot", AppDomain.CurrentDomain.BaseDirectory);
                runspace.SessionStateProxy.SetVariable("CompiLaunchMode", launchMode);
                runspace.SessionStateProxy.SetVariable("CompiLaunchPath", launchPath);
                using (PowerShell powershell = PowerShell.Create())
                {
                    powershell.Runspace = runspace;
                    powershell.AddScript(File.ReadAllText(script));
                    try
                    {
                        powershell.Invoke();
                    }
                    catch
                    {
                        closedNormally = WasClosedNormally(runspace);
                        if (!closedNormally) throw;
                    }
                    closedNormally = closedNormally || WasClosedNormally(runspace);
                    if (powershell.HadErrors && !closedNormally)
                    {
                        string errors = String.Join(Environment.NewLine,
                            powershell.Streams.Error.Select(error => error.ToString()).ToArray());
                        throw new InvalidOperationException(errors);
                    }
                }
            }
        }
        catch (Exception error)
        {
            if (!closedNormally)
            {
                MessageBox.Show("No se pudo abrir Compi.\n\n" + error.Message,
                    "Compi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
