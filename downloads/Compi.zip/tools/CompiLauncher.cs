using System;
using System.IO;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle("Compi")]
[assembly: AssemblyDescription("Reexportacion de videos y fotos")]
[assembly: AssemblyCompany("Compi")]
[assembly: AssemblyProduct("Compi")]
[assembly: AssemblyVersion("__ASSEMBLY_VERSION__")]
[assembly: AssemblyFileVersion("__ASSEMBLY_VERSION__")]
[assembly: AssemblyInformationalVersion("__DISPLAY_VERSION__")]

internal static class CompiLauncher
{
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SetCurrentProcessExplicitAppUserModelID(string appId);

    private static bool WasClosedNormally(Runspace runspace)
    {
        try
        {
            return Object.Equals(runspace.SessionStateProxy.GetVariable("CompiClosedNormally"), true);
        }
        catch
        {
            return false;
        }
    }

    [STAThread]
    private static void Main()
    {
        bool closedNormally = false;
        try
        {
            SetCurrentProcessExplicitAppUserModelID("Compi.Desktop");
            string script = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Compi.ps1");
            if (!File.Exists(script))
                throw new FileNotFoundException("No se encontro Compi.ps1 junto a la aplicacion.", script);

            using (Runspace runspace = RunspaceFactory.CreateRunspace())
            {
                runspace.ApartmentState = ApartmentState.STA;
                runspace.ThreadOptions = PSThreadOptions.UseCurrentThread;
                runspace.Open();
                using (PowerShell powershell = PowerShell.Create())
                {
                    powershell.Runspace = runspace;
                    powershell.AddCommand(script);
                    try
                    {
                        powershell.Invoke();
                    }
                    catch
                    {
                        closedNormally = WasClosedNormally(runspace);
                        if (!closedNormally) throw;
                    }
                    closedNormally = closedNormally || WasClosedNormally(runspace);
                    if (powershell.HadErrors && !closedNormally)
                    {
                        string errors = String.Join(Environment.NewLine,
                            powershell.Streams.Error.Select(error => error.ToString()).ToArray());
                        throw new InvalidOperationException(errors);
                    }
                }
            }
        }
        catch (Exception error)
        {
            if (!closedNormally)
            {
                MessageBox.Show("No se pudo abrir Compi.\n\n" + error.Message,
                    "Compi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
