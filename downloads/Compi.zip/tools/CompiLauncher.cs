using System;
using System.IO;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle("Compi")]
[assembly: AssemblyDescription("Video reexport for GB Films")]
[assembly: AssemblyCompany("GB Films")]
[assembly: AssemblyProduct("Compi")]
[assembly: AssemblyVersion("1.0.0.0")]

internal static class CompiLauncher
{
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SetCurrentProcessExplicitAppUserModelID(string appId);

    [STAThread]
    private static void Main()
    {
        try
        {
            SetCurrentProcessExplicitAppUserModelID("GBFilms.Compi");
            string script = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Compi.ps1");
            if (!File.Exists(script))
                throw new FileNotFoundException("No se encontro Compi.ps1 junto a la aplicacion.", script);

            using (Runspace runspace = RunspaceFactory.CreateRunspace())
            {
                runspace.ApartmentState = ApartmentState.STA;
                runspace.ThreadOptions = PSThreadOptions.UseCurrentThread;
                runspace.Open();
                using (PowerShell powershell = PowerShell.Create())
                {
                    powershell.Runspace = runspace;
                    powershell.AddCommand(script);
                    powershell.Invoke();
                    if (powershell.HadErrors)
                    {
                        string errors = String.Join(Environment.NewLine,
                            powershell.Streams.Error.Select(error => error.ToString()).ToArray());
                        throw new InvalidOperationException(errors);
                    }
                }
            }
        }
        catch (Exception error)
        {
            MessageBox.Show("No se pudo abrir Compi.\n\n" + error.Message,
                "Compi", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
