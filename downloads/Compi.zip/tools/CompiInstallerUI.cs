using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("Instalador de Compi")]
[assembly: AssemblyCompany("GB-Films")]
[assembly: AssemblyProduct("Compi")]
[assembly: AssemblyVersion("__ASSEMBLY_VERSION__")]
[assembly: AssemblyFileVersion("__ASSEMBLY_VERSION__")]

internal static class CompiInstaller
{
    private const string UninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\GBFilms.Compi";

    [STAThread]
    private static int Main(string[] args)
    {
        if (args.Length == 1 && String.Equals(args[0], "/S", StringComparison.OrdinalIgnoreCase))
        {
            try { Install(); return 0; }
            catch { return 1; }
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new InstallerWindow());
        return 0;
    }

    internal static string Install()
    {
        using (Mutex installLock = new Mutex(false, "Local\\GBFilms.Compi.Install"))
        {
            bool acquired;
            try { acquired = installLock.WaitOne(0); } catch (AbandonedMutexException) { acquired = true; }
            if (!acquired) throw new InvalidOperationException("Ya hay una instalación de Compi en curso.");
            try { return InstallCore(); } finally { installLock.ReleaseMutex(); }
        }
    }

    internal static string ExistingVersion()
    {
        using (RegistryKey key = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64).OpenSubKey(UninstallKey))
            return key == null ? null : key.GetValue("DisplayVersion") as string;
    }

    private static string InstallCore()
    {
        string directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "Compi");
        using (RegistryKey key = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64).OpenSubKey(UninstallKey))
            if (key != null && !String.IsNullOrWhiteSpace(key.GetValue("InstallLocation") as string)) directory = (string)key.GetValue("InstallLocation");
        string target = Path.GetFullPath(Path.Combine(directory, "Compi.exe"));
        foreach (Process running in Process.GetProcessesByName("Compi"))
        {
            using (running)
            {
                string runningPath;
                try { runningPath = running.MainModule.FileName; } catch { continue; }
                if (String.Equals(Path.GetFullPath(runningPath), target, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Cerrá Compi y esperá a que terminen sus exportaciones antes de reemplazar la versión instalada.");
            }
        }
        string corePath = Path.Combine(Path.GetTempPath(), "Compi-Setup-Core-" + Guid.NewGuid().ToString("N") + ".exe");
        try
        {
            using (Stream resource = Assembly.GetExecutingAssembly().GetManifestResourceStream("CompiSetupCore"))
            {
                if (resource == null) throw new InvalidOperationException("Faltan archivos de instalación.");
                using (FileStream file = new FileStream(corePath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    resource.CopyTo(file);
            }

            ProcessStartInfo start = new ProcessStartInfo(corePath, "/S");
            start.UseShellExecute = false;
            start.CreateNoWindow = true;
            using (Process process = Process.Start(start))
            {
                if (process == null) throw new InvalidOperationException("No se pudo iniciar la instalación.");
                process.WaitForExit();
                if (process.ExitCode != 0)
                    throw new InvalidOperationException("La instalación terminó con el código " + process.ExitCode + ".");
            }

            using (RegistryKey key = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64).OpenSubKey(UninstallKey))
            {
                if (key == null) throw new InvalidOperationException("Compi no aparece entre las aplicaciones instaladas.");
                string installedDirectory = key.GetValue("InstallLocation") as string;
                if (String.IsNullOrWhiteSpace(installedDirectory)) throw new InvalidOperationException("Falta la carpeta de instalación.");
                string executable = Path.Combine(installedDirectory, "Compi.exe");
                if (!File.Exists(executable)) throw new InvalidOperationException("Falta Compi.exe en la carpeta instalada.");
                using (RegistryKey command = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64)
                    .OpenSubKey(@"Software\Classes\SystemFileAssociations\.mp4\shell\Compi.ReexportVideo\command"))
                {
                    string expected = "\"" + executable + "\" --quick-video \"%1\"";
                    if (command == null || !String.Equals(command.GetValue(null) as string, expected, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidOperationException("No se pudo registrar la opción del clic derecho.");
                }
                return executable;
            }
        }
        finally
        {
            try { if (File.Exists(corePath)) File.Delete(corePath); }
            catch { }
        }
    }

    internal static Image LoadLogo()
    {
        using (Stream resource = Assembly.GetExecutingAssembly().GetManifestResourceStream("CompiLogo"))
        {
            if (resource == null) return null;
            using (Image image = Image.FromStream(resource)) return new Bitmap(image);
        }
    }
}

internal sealed class InstallerWindow : Form
{
    private static readonly Color Black = Color.FromArgb(8, 9, 10);
    private static readonly Color Surface = Color.FromArgb(20, 21, 23);
    private static readonly Color Line = Color.FromArgb(69, 72, 76);
    private static readonly Color White = Color.FromArgb(248, 248, 246);
    private static readonly Color Muted = Color.FromArgb(164, 166, 169);
    private static readonly Color Pink = Color.FromArgb(227, 8, 126);
    private static readonly Color Error = Color.FromArgb(255, 129, 129);

    private readonly Label step;
    private readonly Label headline;
    private readonly Label description;
    private readonly Label cardTitle;
    private readonly Label cardBody;
    private readonly Label status;
    private readonly Button primary;
    private readonly Button secondary;
    private readonly Button close;
    private readonly Panel progressTrack;
    private readonly Panel progressFill;
    private readonly System.Windows.Forms.Timer pulse;
    private readonly BackgroundWorker worker;
    private bool busy;
    private bool installed;
    private string installedExecutable;
    private int pulseX;

    [DllImport("user32.dll")]
    private static extern bool ReleaseCapture();

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr handle, int message, IntPtr wParam, IntPtr lParam);

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr window, int attribute, ref int value, int size);

    internal InstallerWindow()
    {
        Text = "Compi · Instalación";
        ClientSize = new Size(740, 510);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.None;
        MaximizeBox = false;
        BackColor = Black;
        ForeColor = White;
        Font = new Font("Segoe UI", 10);
        AutoScaleMode = AutoScaleMode.Dpi;
        try { Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location); } catch { }

        Panel border = new Panel { Location = new Point(0, 0), Size = new Size(740, 510), BackColor = Line };
        Controls.Add(border);
        Panel canvas = new Panel { Location = new Point(1, 1), Size = new Size(738, 508), BackColor = Black };
        border.Controls.Add(canvas);

        PictureBox logo = new PictureBox { Location = new Point(27, 18), Size = new Size(58, 58), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Black };
        logo.Image = CompiInstaller.LoadLogo();
        canvas.Controls.Add(logo);
        Label appName = MakeLabel("COMPI", 96, 19, 320, 47, new Font("Bahnschrift SemiBold Condensed", 29, FontStyle.Bold), White);
        canvas.Controls.Add(appName);
        Label version = MakeLabel("INSTALADOR  ·  V__DISPLAY_VERSION__", 100, 64, 330, 20, new Font("Bahnschrift SemiBold Condensed", 10, FontStyle.Bold), Muted);
        canvas.Controls.Add(version);
        close = new Button { Text = "×", Location = new Point(687, 18), Size = new Size(30, 30), FlatStyle = FlatStyle.Flat,
            BackColor = Black, ForeColor = Muted, Font = new Font("Segoe UI", 16), TabStop = false };
        close.FlatAppearance.BorderSize = 0;
        close.FlatAppearance.MouseOverBackColor = Surface;
        close.Click += delegate { Close(); };
        canvas.Controls.Add(close);
        canvas.Controls.Add(new Panel { Location = new Point(31, 99), Size = new Size(676, 1), BackColor = Line });

        step = MakeLabel("01  /  INSTALACIÓN", 32, 124, 470, 25,
            new Font("Bahnschrift SemiBold Condensed", 11, FontStyle.Bold), Pink);
        canvas.Controls.Add(step);
        headline = MakeLabel("COMPI EN TU EQUIPO", 31, 154, 680, 59,
            new Font("Bahnschrift SemiBold Condensed", 33, FontStyle.Bold), White);
        canvas.Controls.Add(headline);
        description = MakeLabel("Instalá la app una vez y usala también desde el clic derecho.", 34, 224, 658, 38,
            new Font("Segoe UI", 11), Muted);
        canvas.Controls.Add(description);

        Panel card = new Panel { Location = new Point(31, 281), Size = new Size(676, 111), BackColor = Surface };
        card.Paint += delegate(object sender, PaintEventArgs e)
        {
            using (Pen pen = new Pen(Line)) e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
        };
        canvas.Controls.Add(card);
        card.Controls.Add(new Panel { Location = new Point(0, 0), Size = new Size(4, 111), BackColor = Pink });
        cardTitle = MakeLabel("REEXPORTÁ SIN ABRIR COMPI", 23, 19, 610, 28,
            new Font("Bahnschrift SemiBold Condensed", 16, FontStyle.Bold), White);
        card.Controls.Add(cardTitle);
        cardBody = MakeLabel("Clic derecho en un video  →  máximo 10 MB, junto al original", 24, 56, 620, 29,
            new Font("Segoe UI", 10), Muted);
        card.Controls.Add(cardBody);

        status = MakeLabel("", 33, 398, 660, 26, new Font("Bahnschrift SemiBold Condensed", 10, FontStyle.Bold), Muted);
        canvas.Controls.Add(status);
        progressTrack = new Panel { Location = new Point(31, 422), Size = new Size(676, 4), BackColor = Line, Visible = false };
        canvas.Controls.Add(progressTrack);
        progressFill = new Panel { Location = new Point(0, 0), Size = new Size(110, 4), BackColor = Pink };
        progressTrack.Controls.Add(progressFill);
        canvas.Controls.Add(new Panel { Location = new Point(31, 441), Size = new Size(676, 1), BackColor = Line });

        primary = MakeButton("INSTALAR COMPI", 31, 456, 204, true);
        primary.Click += PrimaryClick;
        canvas.Controls.Add(primary);
        secondary = MakeButton("CANCELAR", 248, 456, 118, false);
        secondary.Click += delegate { Close(); };
        canvas.Controls.Add(secondary);

        MouseEventHandler drag = delegate(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) { ReleaseCapture(); SendMessage(Handle, 0xA1, new IntPtr(2), IntPtr.Zero); }
        };
        canvas.MouseDown += drag;
        appName.MouseDown += drag;
        version.MouseDown += drag;
        logo.MouseDown += drag;

        string existingVersion = CompiInstaller.ExistingVersion();
        if (!String.IsNullOrWhiteSpace(existingVersion))
        {
            headline.Text = "ACTUALIZÁ COMPI";
            description.Text = "Ya tenés Compi " + existingVersion + ". Se reemplazará en la misma carpeta.";
            primary.Text = "REEMPLAZAR COMPI";
            status.Text = "TUS VIDEOS Y FOTOS NO SE MODIFICAN";
        }

        pulse = new System.Windows.Forms.Timer { Interval = 18 };
        pulse.Tick += delegate
        {
            pulseX += 7;
            if (pulseX > progressTrack.Width) pulseX = -progressFill.Width;
            progressFill.Left = pulseX;
        };
        worker = new BackgroundWorker();
        worker.DoWork += delegate(object sender, DoWorkEventArgs e) { e.Result = CompiInstaller.Install(); };
        worker.RunWorkerCompleted += InstallCompleted;
        FormClosing += delegate(object sender, FormClosingEventArgs e)
        {
            if (busy)
            {
                e.Cancel = true;
                status.Text = "ESPERÁ A QUE TERMINE LA INSTALACIÓN";
            }
        };
        Shown += delegate
        {
            try
            {
                int dark = 1;
                if (DwmSetWindowAttribute(Handle, 20, ref dark, 4) != 0) DwmSetWindowAttribute(Handle, 19, ref dark, 4);
            }
            catch { }
        };
    }

    private static Label MakeLabel(string text, int x, int y, int width, int height, Font font, Color color)
    {
        return new Label { Text = text, Location = new Point(x, y), Size = new Size(width, height),
            BackColor = Color.Transparent, ForeColor = color, Font = font, AutoEllipsis = true };
    }

    private static Button MakeButton(string text, int x, int y, int width, bool main)
    {
        Button button = new Button { Text = text, Location = new Point(x, y), Size = new Size(width, 42),
            BackColor = main ? White : Black, ForeColor = main ? Black : White,
            FlatStyle = FlatStyle.Flat, Font = new Font("Bahnschrift SemiBold Condensed", 12, FontStyle.Bold),
            Cursor = Cursors.Hand, UseVisualStyleBackColor = false };
        button.FlatAppearance.BorderColor = main ? White : Line;
        button.FlatAppearance.BorderSize = 1;
        button.FlatAppearance.MouseOverBackColor = main ? Pink : Surface;
        return button;
    }

    private void PrimaryClick(object sender, EventArgs e)
    {
        if (installed)
        {
            try { Process.Start(installedExecutable); Close(); }
            catch (Exception error) { status.ForeColor = Error; status.Text = "NO SE PUDO ABRIR COMPI: " + error.Message; }
            return;
        }
        if (busy) return;
        busy = true;
        primary.Enabled = false;
        secondary.Enabled = false;
        close.Enabled = false;
        step.Text = "02  /  INSTALANDO";
        headline.Text = "PREPARANDO COMPI";
        description.Text = "Se está instalando en tu usuario de Windows.";
        status.ForeColor = Muted;
        status.Text = "COPIANDO ARCHIVOS Y ACTIVANDO EL MENÚ CONTEXTUAL...";
        progressTrack.Visible = true;
        pulseX = 0;
        pulse.Start();
        worker.RunWorkerAsync();
    }

    private void InstallCompleted(object sender, RunWorkerCompletedEventArgs e)
    {
        busy = false;
        pulse.Stop();
        progressTrack.Visible = false;
        primary.Enabled = true;
        secondary.Enabled = true;
        close.Enabled = true;
        secondary.Text = "CERRAR";
        if (e.Error != null)
        {
            step.Text = "02  /  ERROR";
            headline.Text = "NO SE PUDO INSTALAR";
            description.Text = "Comprobá que Windows permita abrir el instalador e intentá otra vez.";
            cardTitle.Text = "LA INSTALACIÓN NO SE COMPLETÓ";
            cardBody.Text = e.Error.Message;
            status.ForeColor = Error;
            status.Text = "COMPI NO ESTÁ LISTO TODAVÍA";
            primary.Text = "REINTENTAR";
            return;
        }
        installed = true;
        installedExecutable = e.Result as string;
        step.Text = "03  /  LISTO";
        headline.Text = "COMPI YA ESTÁ LISTO";
        description.Text = "Podés abrir la app desde Inicio o usar el clic derecho sobre un video.";
        cardTitle.Text = "REEXPORTÁ SIN ABRIR COMPI";
        cardBody.Text = "Clic derecho en un video  →  máximo 10 MB, junto al original";
        status.ForeColor = Pink;
        status.Text = "INSTALACIÓN COMPLETA";
        string integrationStatus = Path.Combine(Path.GetDirectoryName(installedExecutable), "ExplorerIntegration.status");
        if (!File.Exists(integrationStatus) || !File.ReadAllText(integrationStatus).StartsWith("enabled", StringComparison.Ordinal))
        {
            cardTitle.Text = "CLIC DERECHO · MOSTRAR MÁS OPCIONES";
            cardBody.Text = "El menú principal requiere el paquete de Compi firmado y registrado.";
        }
        primary.Text = "ABRIR COMPI";
    }
}
