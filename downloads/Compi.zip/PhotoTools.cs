using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public static class CompiPhoto
{
    private const int MaxDimension = 12000;
    private const long MaxPixels = 80000000;

    private static void ValidateDimensions(Size size)
    {
        if (size.Width < 1 || size.Height < 1 || size.Width > MaxDimension || size.Height > MaxDimension ||
            (long)size.Width * size.Height > MaxPixels)
            throw new InvalidDataException("La foto supera el límite seguro de 12.000 px por lado y 80 megapíxeles.");
    }

    public static Size ReadDimensions(string path)
    {
        using (Image source = Image.FromFile(path))
        {
            Size size = source.Size;
            ValidateDimensions(size);
            return size;
        }
    }

    public static Bitmap Load(string path)
    {
        using (Image source = Image.FromFile(path))
        {
            ValidateDimensions(source.Size);
            int orientation = 1;
            try
            {
                if (Array.IndexOf(source.PropertyIdList, 0x112) >= 0)
                    orientation = BitConverter.ToUInt16(source.GetPropertyItem(0x112).Value, 0);
            }
            catch (Exception) { }

            Bitmap bitmap = new Bitmap(source);
            RotateFlipType rotation = RotateFlipType.RotateNoneFlipNone;
            switch (orientation)
            {
                case 2: rotation = RotateFlipType.RotateNoneFlipX; break;
                case 3: rotation = RotateFlipType.Rotate180FlipNone; break;
                case 4: rotation = RotateFlipType.Rotate180FlipX; break;
                case 5: rotation = RotateFlipType.Rotate90FlipX; break;
                case 6: rotation = RotateFlipType.Rotate90FlipNone; break;
                case 7: rotation = RotateFlipType.Rotate270FlipX; break;
                case 8: rotation = RotateFlipType.Rotate270FlipNone; break;
            }
            bitmap.RotateFlip(rotation);
            return bitmap;
        }
    }

    public static Size Dimensions(string path)
    {
        return ReadDimensions(path);
    }
}

internal sealed class CompiPreviewPanel : Panel
{
    public CompiPreviewPanel()
    {
        DoubleBuffered = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
            ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
        TabStop = true;
    }
}

public sealed class CompiActionButton : Button
{
    public CompiActionButton()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
            ControlStyles.OptimizedDoubleBuffer, true);
    }

    protected override void OnPaint(PaintEventArgs args)
    {
        Graphics graphics = args.Graphics;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using (Brush background = new SolidBrush(BackColor))
            graphics.FillRectangle(background, ClientRectangle);
        using (Pen outline = new Pen(FlatAppearance.BorderColor))
            graphics.DrawRectangle(outline, 0, 0, Width - 1, Height - 1);

        Color ink = Enabled ? ForeColor : Color.FromArgb(105, 108, 111);
        int iconWidth = 18;
        int gap = 10;
        Size textSize = TextRenderer.MeasureText(Text, Font, new Size(Width, Height),
            TextFormatFlags.SingleLine | TextFormatFlags.NoPadding);
        int groupWidth = Math.Min(Width - 20, textSize.Width + gap + iconWidth);
        int textWidth = Math.Max(1, groupWidth - gap - iconWidth);
        int left = (Width - groupWidth) / 2;
        TextRenderer.DrawText(graphics, Text, Font, new Rectangle(left, 0, textWidth, Height), ink,
            TextFormatFlags.SingleLine | TextFormatFlags.NoPadding | TextFormatFlags.VerticalCenter |
            TextFormatFlags.HorizontalCenter | TextFormatFlags.EndEllipsis);

        int x = left + textWidth + gap;
        int y = (Height - 20) / 2;
        using (Pen line = new Pen(ink, 2))
        using (Brush arrow = new SolidBrush(ink))
        {
            graphics.DrawLine(line, x + 2, y + 2, x + 16, y + 2);
            graphics.FillPolygon(arrow, new Point[] {
                new Point(x + 7, y + 5), new Point(x + 11, y + 5),
                new Point(x + 11, y + 12), new Point(x + 15, y + 9),
                new Point(x + 17, y + 12), new Point(x + 9, y + 19),
                new Point(x + 1, y + 12), new Point(x + 3, y + 9),
                new Point(x + 7, y + 12)
            });
            graphics.DrawLine(line, x + 6, y + 20, x + 12, y + 20);
        }
    }
}

public sealed class CompiCropEditor : Form
{
    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr window, int attribute, ref int value, int size);

    private readonly string sourcePath;
    private readonly Bitmap image;
    private readonly int targetWidth;
    private readonly int targetHeight;
    private readonly Panel canvas;
    private readonly Label help;
    private Bitmap previewImage;
    private double cropX;
    private double cropY;
    private double cropWidth;
    private double cropHeight;
    private readonly double initialCropWidth;
    private readonly double initialCropHeight;
    private RectangleF imageRect;
    private RectangleF frameRect;
    private bool dragging;
    private bool panning;
    private Point lastMouse;

    public string OutputPath { get; private set; }

    public CompiCropEditor(string path, int width, int height) : this(path, width, height, "") { }

    public CompiCropEditor(string path, int width, int height, string version)
    {
        sourcePath = path;
        targetWidth = width;
        targetHeight = height;
        image = CompiPhoto.Load(path);
        double ratio = (double)width / height;
        if ((double)image.Width / image.Height > ratio)
        {
            cropHeight = image.Height;
            cropWidth = image.Height * ratio;
        }
        else
        {
            cropWidth = image.Width;
            cropHeight = image.Width / ratio;
        }
        cropX = (image.Width - cropWidth) / 2;
        cropY = (image.Height - cropHeight) / 2;
        initialCropWidth = cropWidth;
        initialCropHeight = cropHeight;

        Text = "COMPI" + (String.IsNullOrEmpty(version) ? "" : "  ·  v" + version) + "  /  REENCUADRÁ TU FOTO";
        ClientSize = new Size(880, 690);
        MinimumSize = new Size(600, 520);
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(8, 9, 10);
        ForeColor = Color.White;
        Font = new Font("Segoe UI", 10);
        KeyPreview = true;

        Label heading = new Label { Text = "03  /  REENCUADRÁ TU FOTO", Left = 24, Top = 18, Width = 520, Height = 34,
            Font = new Font("Bahnschrift SemiBold Condensed", 22, FontStyle.Bold), ForeColor = Color.White };
        Controls.Add(heading);
        help = new Label { Text = "Ruedita: zoom  ·  Arrastrá: recorte  ·  Botón central: mové la foto", Left = 25, Top = 56,
            Width = 800, Height = 28, ForeColor = Color.FromArgb(164, 166, 169) };
        Controls.Add(help);

        canvas = new CompiPreviewPanel { Left = 24, Top = 92, Width = 832, Height = 510,
            BackColor = Color.FromArgb(20, 21, 23), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom };
        canvas.Paint += PaintPreview;
        canvas.MouseDown += MouseDownPreview;
        canvas.MouseMove += MouseMovePreview;
        canvas.MouseUp += (sender, args) => { dragging = false; panning = false; canvas.Capture = false; };
        canvas.MouseWheel += MouseWheelPreview;
        canvas.MouseEnter += (sender, args) => canvas.Focus();
        canvas.Resize += (sender, args) => { if (previewImage != null) { previewImage.Dispose(); previewImage = null; } canvas.Invalidate(); };
        Controls.Add(canvas);

        Button export = new CompiActionButton { Text = "REEXPORTAR FOTO", Left = 24, Top = 620, Width = 250, Height = 46,
            BackColor = Color.White, ForeColor = Color.FromArgb(8, 9, 10), FlatStyle = FlatStyle.Flat,
            Anchor = AnchorStyles.Left | AnchorStyles.Bottom, Cursor = Cursors.Hand,
            Font = new Font("Bahnschrift SemiBold Condensed", 12, FontStyle.Bold) };
        export.FlatAppearance.BorderColor = Color.White;
        export.Click += Export;
        Controls.Add(export);

        Button cancel = new Button { Text = "CANCELAR", Left = 288, Top = 620, Width = 130, Height = 46,
            BackColor = BackColor, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
            Anchor = AnchorStyles.Left | AnchorStyles.Bottom, Cursor = Cursors.Hand,
            DialogResult = DialogResult.Cancel,
            Font = new Font("Bahnschrift SemiBold Condensed", 12, FontStyle.Bold) };
        cancel.FlatAppearance.BorderColor = Color.FromArgb(69, 72, 76);
        Controls.Add(cancel);
        CancelButton = cancel;

        Label dimensions = new Label { Text = width + " × " + height + " PX", Left = 670, Top = 631,
            Width = 185, Height = 24, TextAlign = ContentAlignment.MiddleRight,
            ForeColor = Color.FromArgb(164, 166, 169), Anchor = AnchorStyles.Right | AnchorStyles.Bottom,
            Font = new Font("Bahnschrift SemiBold Condensed", 11, FontStyle.Bold) };
        Controls.Add(dimensions);
        Resize += (sender, args) => { export.Top = cancel.Top = dimensions.Top = ClientSize.Height - 70; };
        KeyDown += (sender, args) =>
        {
            double step = (args.Control ? 1 : 10);
            if (args.KeyCode == Keys.Left) cropX -= step;
            else if (args.KeyCode == Keys.Right) cropX += step;
            else if (args.KeyCode == Keys.Up) cropY -= step;
            else if (args.KeyCode == Keys.Down) cropY += step;
            else return;
            ClampCrop();
            canvas.Invalidate();
            args.Handled = true;
        };
    }

    private void ClampCrop()
    {
        cropX = Math.Max(0, Math.Min(image.Width - cropWidth, cropX));
        cropY = Math.Max(0, Math.Min(image.Height - cropHeight, cropY));
    }

    private RectangleF CropOnScreen()
    {
        UpdateGeometry();
        return frameRect;
    }

    private void EnsurePreview()
    {
        if (previewImage != null) return;
        int availableWidth = Math.Max(1, (canvas.ClientSize.Width - 32) * 2);
        int availableHeight = Math.Max(1, (canvas.ClientSize.Height - 32) * 2);
        double scale = Math.Min((double)availableWidth / image.Width, (double)availableHeight / image.Height);
        int width = Math.Max(1, (int)Math.Round(image.Width * scale));
        int height = Math.Max(1, (int)Math.Round(image.Height * scale));
        Bitmap resized = new Bitmap(width, height, PixelFormat.Format32bppPArgb);
        try
        {
            using (Graphics graphics = Graphics.FromImage(resized))
            {
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                graphics.DrawImage(image, new Rectangle(0, 0, width, height));
            }
            previewImage = resized;
        }
        catch
        {
            resized.Dispose();
            throw;
        }
    }

    private void UpdateGeometry()
    {
        EnsurePreview();
        double baseScale = Math.Min((double)Math.Max(1, canvas.ClientSize.Width - 32) / image.Width,
            (double)Math.Max(1, canvas.ClientSize.Height - 32) / image.Height);
        frameRect = new RectangleF(
            (float)((canvas.ClientSize.Width - initialCropWidth * baseScale) / 2),
            (float)((canvas.ClientSize.Height - initialCropHeight * baseScale) / 2),
            (float)(initialCropWidth * baseScale),
            (float)(initialCropHeight * baseScale));
        double scale = frameRect.Width / cropWidth;
        imageRect = new RectangleF(
            (float)(frameRect.X - cropX * scale),
            (float)(frameRect.Y - cropY * scale),
            (float)(image.Width * scale),
            (float)(image.Height * scale));
    }

    private void PaintPreview(object sender, PaintEventArgs args)
    {
        UpdateGeometry();
        Graphics graphics = args.Graphics;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
        graphics.DrawImage(previewImage, imageRect);
        RectangleF crop = frameRect;
        using (Brush shade = new SolidBrush(Color.FromArgb(165, 0, 0, 0)))
        {
            graphics.FillRectangle(shade, 0, 0, canvas.ClientSize.Width, crop.Top);
            graphics.FillRectangle(shade, 0, crop.Bottom, canvas.ClientSize.Width, canvas.ClientSize.Height - crop.Bottom);
            graphics.FillRectangle(shade, 0, crop.Top, crop.Left, crop.Height);
            graphics.FillRectangle(shade, crop.Right, crop.Top, canvas.ClientSize.Width - crop.Right, crop.Height);
        }
        using (Pen border = new Pen(Color.White, 2))
        using (Pen grid = new Pen(Color.FromArgb(130, 255, 255, 255), 1))
        {
            graphics.DrawRectangle(border, crop.X, crop.Y, crop.Width, crop.Height);
            for (int part = 1; part <= 2; part++)
            {
                graphics.DrawLine(grid, crop.X + crop.Width * part / 3, crop.Y,
                    crop.X + crop.Width * part / 3, crop.Bottom);
                graphics.DrawLine(grid, crop.X, crop.Y + crop.Height * part / 3,
                    crop.Right, crop.Y + crop.Height * part / 3);
            }
        }
    }

    private void MouseDownPreview(object sender, MouseEventArgs args)
    {
        UpdateGeometry();
        canvas.Focus();
        if (args.Button == MouseButtons.Middle)
        {
            panning = true;
            lastMouse = args.Location;
            canvas.Capture = true;
            return;
        }
        if (args.Button != MouseButtons.Left) return;
        if (!frameRect.Contains(args.Location))
        {
            double scale = image.Width / imageRect.Width;
            cropX = (args.X - imageRect.X) * scale - cropWidth / 2;
            cropY = (args.Y - imageRect.Y) * scale - cropHeight / 2;
            ClampCrop();
            canvas.Invalidate();
        }
        dragging = true;
        lastMouse = args.Location;
        canvas.Capture = true;
    }

    private void MouseMovePreview(object sender, MouseEventArgs args)
    {
        UpdateGeometry();
        Cursor cursor = (panning || dragging || frameRect.Contains(args.Location)) ? Cursors.SizeAll : Cursors.Default;
        if (canvas.Cursor != cursor) canvas.Cursor = cursor;
        bool moveCrop = dragging && (args.Button & MouseButtons.Left) != 0;
        bool movePhoto = panning && (args.Button & MouseButtons.Middle) != 0;
        if (!moveCrop && !movePhoto) return;
        double scale = image.Width / imageRect.Width;
        double direction = movePhoto ? -1 : 1;
        cropX += (args.X - lastMouse.X) * scale * direction;
        cropY += (args.Y - lastMouse.Y) * scale * direction;
        lastMouse = args.Location;
        ClampCrop();
        canvas.Invalidate();
    }

    private void MouseWheelPreview(object sender, MouseEventArgs args)
    {
        UpdateGeometry();
        double nextWidth = Math.Max(initialCropWidth / 8.0,
            Math.Min(initialCropWidth, cropWidth * Math.Pow(0.9, args.Delta / 120.0)));
        if (Math.Abs(nextWidth - cropWidth) < 0.01) return;
        double fractionX = Math.Max(0, Math.Min(1, (args.X - frameRect.Left) / frameRect.Width));
        double fractionY = Math.Max(0, Math.Min(1, (args.Y - frameRect.Top) / frameRect.Height));
        double anchorX = cropX + fractionX * cropWidth;
        double anchorY = cropY + fractionY * cropHeight;
        double nextHeight = nextWidth * initialCropHeight / initialCropWidth;
        cropX = anchorX - fractionX * nextWidth;
        cropY = anchorY - fractionY * nextHeight;
        cropWidth = nextWidth;
        cropHeight = nextHeight;
        ClampCrop();
        canvas.Invalidate();
    }

    private void Export(object sender, EventArgs args)
    {
        try
        {
            string ext = Path.GetExtension(sourcePath).ToLowerInvariant();
            bool jpeg = ext == ".jpg" || ext == ".jpeg";
            string extension = jpeg ? ".jpg" : ".png";
            string directory = Path.GetDirectoryName(sourcePath);
            string stem = Path.GetFileNameWithoutExtension(sourcePath) + "_" + targetWidth + "x" + targetHeight;
            string output = Path.Combine(directory, stem + extension);
            for (int number = 1; File.Exists(output); number++)
                output = Path.Combine(directory, stem + (number == 1 ? "_copia" : "_copia_" + number.ToString("00")) + extension);
            string temp = Path.Combine(directory, ".compi-" + Guid.NewGuid().ToString("N") + extension);
            try
            {
                using (Bitmap result = new Bitmap(targetWidth, targetHeight, PixelFormat.Format32bppArgb))
                using (Graphics graphics = Graphics.FromImage(result))
                {
                    graphics.CompositingQuality = CompositingQuality.HighQuality;
                    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    graphics.DrawImage(image, new Rectangle(0, 0, targetWidth, targetHeight),
                        new RectangleF((float)cropX, (float)cropY, (float)cropWidth, (float)cropHeight), GraphicsUnit.Pixel);
                    if (jpeg)
                    {
                        ImageCodecInfo codec = Array.Find(ImageCodecInfo.GetImageEncoders(), item => item.MimeType == "image/jpeg");
                        using (EncoderParameters options = new EncoderParameters(1))
                        {
                            options.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 92L);
                            result.Save(temp, codec, options);
                        }
                    }
                    else result.Save(temp, ImageFormat.Png);
                }
                File.Move(temp, output);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
            OutputPath = output;
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception error)
        {
            MessageBox.Show(this, "No se pudo reexportar la foto.\n\n" + error.Message,
                "Compi", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            if (previewImage != null) previewImage.Dispose();
            image.Dispose();
        }
        base.Dispose(disposing);
    }

    protected override void OnShown(EventArgs args)
    {
        try
        {
            int dark = 1;
            if (DwmSetWindowAttribute(Handle, 20, ref dark, 4) != 0)
                DwmSetWindowAttribute(Handle, 19, ref dark, 4);
        }
        catch (Exception) { }
        base.OnShown(args);
    }
}
