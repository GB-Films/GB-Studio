﻿param([Parameter(Mandatory)][string]$JobFile)
$ErrorActionPreference = 'Stop'

$job = Get-Content -LiteralPath $JobFile -Raw -Encoding UTF8 | ConvertFrom-Json
$source = [string]$job.input
$jobDir = [string]$job.directory
$statusFile = Join-Path $jobDir 'status.json'
$cancelFile = Join-Path $jobDir 'cancel'
$script:child = $null

function Set-Status([string]$state, [string]$message, [int]$progress, [string]$output = '') {
    $tmp = Join-Path $jobDir 'status.tmp'
    @{ state = $state; message = $message; progress = $progress; output = $output } |
        ConvertTo-Json -Compress | Set-Content -LiteralPath $tmp -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $statusFile -Force
}

function Assert-NotCancelled {
    if (Test-Path -LiteralPath $cancelFile) { throw 'CANCELLED' }
}

function Quote-WindowsArgument([string]$value) {
    $quoted = '"'
    $slashes = 0
    foreach ($character in $value.ToCharArray()) {
        if ($character -eq '\') {
            $slashes++
        } elseif ($character -eq '"') {
            $quoted += ('\' * ($slashes * 2 + 1)) + '"'
            $slashes = 0
        } else {
            $quoted += ('\' * $slashes) + $character
            $slashes = 0
        }
    }
    return $quoted + ('\' * ($slashes * 2)) + '"'
}

function Get-Tools {
    $installedFfmpeg = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
    $installedFfprobe = Get-Command ffprobe.exe -ErrorAction SilentlyContinue
    if ($installedFfmpeg -and $installedFfprobe) {
        return @{ ffmpeg = $installedFfmpeg.Source; ffprobe = $installedFfprobe.Source }
    }
    $bin = Join-Path $env:LOCALAPPDATA 'ReexportarVideo\bin'
    $ffmpeg = Join-Path $bin 'ffmpeg.exe'
    $ffprobe = Join-Path $bin 'ffprobe.exe'
    if ((Test-Path -LiteralPath $ffmpeg) -and (Test-Path -LiteralPath $ffprobe)) {
        return @{ ffmpeg = $ffmpeg; ffprobe = $ffprobe }
    }
    New-Item -ItemType Directory -Path $bin -Force | Out-Null
    $url = 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.7z'
    $archive = Join-Path $jobDir 'ffmpeg.7z'
    $expanded = Join-Path $jobDir 'ffmpeg-extraido'
    Set-Status 'running' 'Descargando FFmpeg por primera vez (puede tardar unos minutos)...' 1
    Invoke-WebRequest -Uri $url -OutFile $archive -TimeoutSec 1800 -UseBasicParsing
    Assert-NotCancelled
    $expected = ((Invoke-WebRequest -Uri ($url + '.sha256') -TimeoutSec 30 -UseBasicParsing).Content -split '\s+')[0].Trim().ToLowerInvariant()
    $actual = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $expected) { throw 'La descarga de FFmpeg no pasó la verificación de integridad.' }
    Set-Status 'running' 'Preparando FFmpeg...' 3
    New-Item -ItemType Directory -Path $expanded -Force | Out-Null
    & "$env:WINDIR\System32\tar.exe" -xf $archive -C $expanded
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo extraer FFmpeg.' }
    $foundFfmpeg = Get-ChildItem -LiteralPath $expanded -Filter 'ffmpeg.exe' -File -Recurse | Select-Object -First 1
    $foundFfprobe = Get-ChildItem -LiteralPath $expanded -Filter 'ffprobe.exe' -File -Recurse | Select-Object -First 1
    if (-not $foundFfmpeg -or -not $foundFfprobe) { throw 'La descarga de FFmpeg no contiene las herramientas necesarias.' }
    Copy-Item -LiteralPath $foundFfmpeg.FullName -Destination $ffmpeg -Force
    Copy-Item -LiteralPath $foundFfprobe.FullName -Destination $ffprobe -Force
    Remove-Item -LiteralPath $archive -Force
    $resolvedJob = [IO.Path]::GetFullPath($jobDir).TrimEnd('\')
    $resolvedExpanded = [IO.Path]::GetFullPath($expanded)
    if (-not $resolvedExpanded.StartsWith($resolvedJob + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'La carpeta temporal no es válida.'
    }
    Remove-Item -LiteralPath $resolvedExpanded -Recurse -Force
    return @{ ffmpeg = $ffmpeg; ffprobe = $ffprobe }
}

function Invoke-Encode([string]$ffmpeg, [string[]]$arguments, [string]$progressPath, [int]$from, [int]$to, [double]$duration) {
    Assert-NotCancelled
    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $ffmpeg
    $psi.Arguments = (($arguments | ForEach-Object { Quote-WindowsArgument $_ }) -join ' ')
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardError = $true
    $script:child = [System.Diagnostics.Process]::Start($psi)
    $errors = $script:child.StandardError.ReadToEndAsync()
    while (-not $script:child.WaitForExit(500)) {
        if (Test-Path -LiteralPath $cancelFile) {
            $script:child.Kill()
            throw 'CANCELLED'
        }
        if (Test-Path -LiteralPath $progressPath) {
            try {
                $recent = Get-Content -LiteralPath $progressPath -Tail 18 -ErrorAction Stop
                $timeLine = $recent | Where-Object { $_ -match '^out_time_(us|ms)=' } | Select-Object -Last 1
                if ($timeLine -match '^out_time_(?:us|ms)=(\d+)') {
                    $seconds = [double]$Matches[1] / 1000000.0
                    $value = $from + [int][Math]::Floor(($to - $from) * [Math]::Min(1, $seconds / $duration))
                    Set-Status 'running' 'Reexportando video...' $value
                }
            } catch { }
        }
    }
    $script:child.WaitForExit()
    $errorText = $errors.GetAwaiter().GetResult()
    $code = $script:child.ExitCode
    $script:child.Dispose()
    $script:child = $null
    if ($code -ne 0) {
        $short = if ($errorText.Length -gt 900) { $errorText.Substring($errorText.Length - 900) } else { $errorText }
        throw "FFmpeg no pudo procesar este video. $short"
    }
}

try {
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw 'No se encontró el video original.' }
    Assert-NotCancelled
    $item = Get-Item -LiteralPath $source
    if ($item.Length -le 0) { throw 'El archivo está vacío.' }
    if ($job.mode -eq '10mb') {
        $target = [long]10000000
    } elseif ($job.mode -eq 'custom') {
        $target = [long]0
        if (-not [long]::TryParse([string]$job.target_bytes, [ref]$target) -or $target -le 0) {
            throw 'El tamaño personalizado debe ser mayor a cero.'
        }
    } else {
        throw 'El objetivo de peso no es válido.'
    }
    $baseName = [IO.Path]::GetFileNameWithoutExtension($source)
    $parent = [IO.Path]::GetDirectoryName($source)
    $suffix = if ($item.Length -le $target) { $item.Extension } else { '.mp4' }
    $output = Join-Path $parent ($baseName + '_reexportado' + $suffix)
    $number = 2
    while (Test-Path -LiteralPath $output) {
        $output = Join-Path $parent ($baseName + '_reexportado_' + $number + $suffix)
        $number++
    }
    if ($item.Length -le $target) {
        Set-Status 'running' 'El original ya cumple el límite; creando una copia idéntica...' 30
        Copy-Item -LiteralPath $source -Destination $output -ErrorAction Stop
        Set-Status 'done' ('Listo: ' + [Math]::Round((Get-Item -LiteralPath $output).Length / 1000000.0, 2) + ' MB.') 100 $output
        exit 0
    }

    $tools = Get-Tools
    Assert-NotCancelled
    Set-Status 'running' 'Analizando video...' 5
    $probeJson = & $tools.ffprobe -v error -select_streams v:0 -show_entries format=duration:stream=width,height -of json $source 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo leer el video. Comprobá que el archivo sea un video válido.' }
    $info = ($probeJson | Out-String | ConvertFrom-Json)
    if (-not $info.streams -or -not $info.format.duration) { throw 'El archivo no contiene un video con duración conocida.' }
    $duration = [double]::Parse([string]$info.format.duration, [Globalization.CultureInfo]::InvariantCulture)
    if ($duration -le 0) { throw 'La duración del video no es válida.' }
    $height = [int]$info.streams[0].height
    $totalBitrate = [double]$target * 8 * 0.95 / $duration
    $audioBitrate = if ($totalBitrate -gt 350000) { 96000 } elseif ($totalBitrate -gt 140000) { 64000 } else { 24000 }
    $videoBitrate = [long][Math]::Floor($totalBitrate - $audioBitrate)
    if ($videoBitrate -lt 12000) { throw 'El video es demasiado largo para alcanzar ese tamaño conservando el audio.' }
    $maxHeight = if ($videoBitrate -lt 150000) { 360 } elseif ($videoBitrate -lt 400000) { 480 } elseif ($videoBitrate -lt 800000) { 720 } else { 0 }
    $filter = if ($maxHeight -gt 0 -and $height -gt $maxHeight) { "fps=24,scale=-2:$maxHeight" } elseif ($videoBitrate -lt 150000) { 'fps=24' } else { $null }
    $partial = Join-Path $jobDir 'resultado.mp4'
    $log = Join-Path $jobDir 'pasadas'

    for ($attempt = 1; $attempt -le 4; $attempt++) {
        Assert-NotCancelled
        $bitrateText = [string]$videoBitrate
        $common = @('-hide_banner', '-loglevel', 'error', '-nostdin', '-y', '-i', $source,
            '-map', '0:v:0', '-c:v', 'libx264', '-preset', 'medium', '-pix_fmt', 'yuv420p',
            '-b:v', $bitrateText, '-passlogfile', $log)
        if ($filter) { $common += @('-vf', $filter) }
        $firstProgress = Join-Path $jobDir "avance1-$attempt.txt"
        $first = $common + @('-pass', '1', '-an', '-sn', '-progress', $firstProgress, '-f', 'null', 'NUL')
        Set-Status 'running' "Analizando para compresión (intento $attempt de 4)..." 7
        Invoke-Encode $tools.ffmpeg $first $firstProgress 7 45 $duration
        $secondProgress = Join-Path $jobDir "avance2-$attempt.txt"
        $second = $common + @('-pass', '2', '-map', '0:a:0?', '-c:a', 'aac', '-b:a', [string]$audioBitrate,
            '-ac', '2', '-sn', '-movflags', '+faststart', '-progress', $secondProgress, $partial)
        Set-Status 'running' "Exportando (intento $attempt de 4)..." 46
        Invoke-Encode $tools.ffmpeg $second $secondProgress 46 93 $duration
        $actual = (Get-Item -LiteralPath $partial).Length
        if ($actual -le $target) {
            Move-Item -LiteralPath $partial -Destination $output -ErrorAction Stop
            Set-Status 'done' ('Listo: ' + [Math]::Round($actual / 1000000.0, 2) + ' MB.') 100 $output
            exit 0
        }
        Remove-Item -LiteralPath $partial -Force
        $factor = [Math]::Min(0.85, 0.92 * $target / $actual)
        $videoBitrate = [long][Math]::Floor($videoBitrate * $factor)
        if ($videoBitrate -lt 12000) { break }
    }
    throw 'No se pudo alcanzar el tamaño elegido sin quitar el audio. No se creó un archivo de salida.'
} catch {
    if ($script:child -and -not $script:child.HasExited) { try { $script:child.Kill() } catch { } }
    $partial = Join-Path $jobDir 'resultado.mp4'
    if (Test-Path -LiteralPath $partial) { Remove-Item -LiteralPath $partial -Force }
    if ($_.Exception.Message -eq 'CANCELLED') {
        Set-Status 'cancelled' 'Cancelado. El video original no se modificó.' 0
    } else {
        Set-Status 'error' $_.Exception.Message 0
    }
    exit 1
}
