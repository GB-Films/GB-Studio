﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:inputPath = $null
$script:outputPath = $null
$script:worker = $null
$script:jobDir = $null
$script:mode = '10mb'

$black = [Drawing.Color]::FromArgb(8, 9, 10)
$surface = [Drawing.Color]::FromArgb(20, 21, 23)
$surfaceActive = [Drawing.Color]::FromArgb(30, 32, 35)
$line = [Drawing.Color]::FromArgb(69, 72, 76)
$white = [Drawing.Color]::FromArgb(248, 248, 246)
$muted = [Drawing.Color]::FromArgb(164, 166, 169)
$errorColor = [Drawing.Color]::FromArgb(255, 129, 129)
$fontBody = [Drawing.Font]::new('Segoe UI', 10)
$fontSmall = [Drawing.Font]::new('Segoe UI', 9)
$fontLabel = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 11, [Drawing.FontStyle]::Bold)
$fontHeading = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 31, [Drawing.FontStyle]::Bold)
$fontDrop = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 22, [Drawing.FontStyle]::Bold)

function New-Label([string]$text, [int]$x, [int]$y, [int]$width, [int]$height, $font, $color) {
    $label = [Windows.Forms.Label]::new()
    $label.Text = $text
    $label.Location = [Drawing.Point]::new($x, $y)
    $label.Size = [Drawing.Size]::new($width, $height)
    $label.Font = $font
    $label.ForeColor = $color
    $label.BackColor = [Drawing.Color]::Transparent
    return $label
}

function Style-Button($button, $background, $foreground, $border) {
    $button.BackColor = $background
    $button.ForeColor = $foreground
    $button.FlatStyle = 'Flat'
    $button.FlatAppearance.BorderColor = $border
    $button.FlatAppearance.BorderSize = 1
    $button.Cursor = [Windows.Forms.Cursors]::Hand
    $button.Font = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 12, [Drawing.FontStyle]::Bold)
}

$form = [Windows.Forms.Form]::new()
$form.Text = 'COMPI  ·  GB FILMS'
$form.ClientSize = [Drawing.Size]::new(840, 604)
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.StartPosition = 'CenterScreen'
$form.BackColor = $black
$form.ForeColor = $white
$form.Font = $fontBody
$form.AutoScaleMode = 'Dpi'
$form.AllowDrop = $true
try {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CompiDwm {
    [DllImport("dwmapi.dll")]
    public static extern int DwmSetWindowAttribute(IntPtr window, int attribute, ref int value, int size);
}
'@ -ErrorAction Stop
    $form.Add_Shown({
        $dark = 1
        $result = [CompiDwm]::DwmSetWindowAttribute($form.Handle, 20, [ref]$dark, 4)
        if ($result -ne 0) { [CompiDwm]::DwmSetWindowAttribute($form.Handle, 19, [ref]$dark, 4) | Out-Null }
    })
} catch { }

$logo = [Windows.Forms.Panel]::new()
$logo.BackColor = $black
$logo.Location = [Drawing.Point]::new(32, 21)
$logo.Size = [Drawing.Size]::new(76, 76)
$form.Controls.Add($logo)
$logoPath = Join-Path $PSScriptRoot 'assets\LogotipoGBF_blanco_v01.png'
if (Test-Path -LiteralPath $logoPath) {
    $script:brandLogo = [Drawing.Bitmap]::new($logoPath)
    $logo.BackgroundImage = $script:brandLogo
    $logo.BackgroundImageLayout = 'Stretch'
} else {
    $logoLetters = New-Label 'GB' 0 3 76 53 ([Drawing.Font]::new('Bahnschrift SemiBold Condensed', 34, [Drawing.FontStyle]::Bold)) $white
    $logoLetters.TextAlign = 'MiddleCenter'
    $logo.Controls.Add($logoLetters)
    $logoFilms = New-Label 'F I L M S' 0 54 76 17 ([Drawing.Font]::new('Bahnschrift SemiBold Condensed', 9, [Drawing.FontStyle]::Bold)) $white
    $logoFilms.TextAlign = 'MiddleCenter'
    $logo.Controls.Add($logoFilms)
}
$iconPath = Join-Path $PSScriptRoot 'assets\Compi.ico'
if (Test-Path -LiteralPath $iconPath) { $form.Icon = [Drawing.Icon]::new($iconPath) }

$eyebrow = New-Label 'GB FILMS  /  HERRAMIENTAS' 124 22 420 19 $fontLabel $muted
$form.Controls.Add($eyebrow)
$title = New-Label 'COMPI' 121 38 400 58 $fontHeading $white
$form.Controls.Add($title)
$topRight = New-Label 'REEXPORTACIÓN DE VIDEO' 626 44 185 25 $fontLabel $white
$topRight.TextAlign = 'MiddleRight'
$form.Controls.Add($topRight)
$rule = [Windows.Forms.Panel]::new()
$rule.BackColor = $line
$rule.Location = [Drawing.Point]::new(32, 116)
$rule.Size = [Drawing.Size]::new(776, 1)
$form.Controls.Add($rule)

$drop = [Windows.Forms.Panel]::new()
$drop.BackColor = $surface
$drop.Location = [Drawing.Point]::new(32, 142)
$drop.Size = [Drawing.Size]::new(776, 152)
$drop.Add_Paint({
    param($sender, $event)
    $pen = [Drawing.Pen]::new($line, 1)
    $pen.DashStyle = [Drawing.Drawing2D.DashStyle]::Dash
    $event.Graphics.DrawRectangle($pen, 0, 0, $sender.Width - 1, $sender.Height - 1)
    $pen.Dispose()
})
$form.Controls.Add($drop)

$dropTitle = New-Label 'ARRASTRÁ TU VIDEO ACÁ' 24 22 500 37 $fontDrop $white
$drop.Controls.Add($dropTitle)
$dropHint = New-Label 'O elegilo desde tu equipo para empezar.' 26 62 520 26 $fontBody $muted
$drop.Controls.Add($dropHint)
$fileName = New-Label 'NINGÚN VIDEO SELECCIONADO' 26 104 515 25 $fontLabel $white
$fileName.AutoEllipsis = $true
$drop.Controls.Add($fileName)
$fileDetails = New-Label 'MP4, MOV, MKV, AVI y otros formatos de video' 26 127 515 19 $fontSmall $muted
$drop.Controls.Add($fileDetails)

$browse = [Windows.Forms.Button]::new()
$browse.Text = 'ELEGIR VIDEO'
$browse.Location = [Drawing.Point]::new(606, 49)
$browse.Size = [Drawing.Size]::new(145, 48)
Style-Button $browse $surface $white $white
$drop.Controls.Add($browse)

$modeLabel = New-Label '01  /  OBJETIVO DE PESO' 32 315 400 21 $fontLabel $muted
$form.Controls.Add($modeLabel)

$card10 = [Windows.Forms.Panel]::new()
$card10.Location = [Drawing.Point]::new(32, 342)
$card10.Size = [Drawing.Size]::new(378, 94)
$form.Controls.Add($card10)
$cardCustom = [Windows.Forms.Panel]::new()
$cardCustom.Location = [Drawing.Point]::new(430, 342)
$cardCustom.Size = [Drawing.Size]::new(378, 94)
$form.Controls.Add($cardCustom)

$mode10Title = New-Label '●  MÁXIMO 10 MB' 20 16 338 29 $fontLabel $white
$mode10Title.Cursor = [Windows.Forms.Cursors]::Hand
$card10.Controls.Add($mode10Title)
$tenHint = New-Label 'Ideal para límites de carga y entregas.' 43 53 314 25 $fontSmall $muted
$card10.Controls.Add($tenHint)

$modeCustomTitle = New-Label '○  PERSONALIZADO' 20 16 338 29 $fontLabel $white
$modeCustomTitle.Cursor = [Windows.Forms.Cursors]::Hand
$cardCustom.Controls.Add($modeCustomTitle)
$customHint = New-Label 'HASTA' 43 55 72 24 $fontLabel $muted
$cardCustom.Controls.Add($customHint)
$customSize = [Windows.Forms.TextBox]::new()
$customSize.Text = '10'
$customSize.Location = [Drawing.Point]::new(120, 52)
$customSize.Size = [Drawing.Size]::new(92, 27)
$customSize.Font = $fontBody
$customSize.ForeColor = $white
$customSize.BackColor = $black
$customSize.BorderStyle = 'FixedSingle'
$customSize.TextAlign = 'Right'
$cardCustom.Controls.Add($customSize)
$customUnit = New-Label 'MB' 223 55 55 24 $fontLabel $white
$cardCustom.Controls.Add($customUnit)

$paintCard = {
    param($sender, $event)
    $selected = if ($sender -eq $card10) { $script:mode -eq '10mb' } else { $script:mode -eq 'custom' }
    $borderColor = if ($selected) { $white } else { $line }
    $pen = [Drawing.Pen]::new($borderColor, 1)
    $event.Graphics.DrawRectangle($pen, 0, 0, $sender.Width - 1, $sender.Height - 1)
    $pen.Dispose()
}
$card10.Add_Paint($paintCard)
$cardCustom.Add_Paint($paintCard)
$updateCards = {
    $card10.BackColor = if ($script:mode -eq '10mb') { $surfaceActive } else { $surface }
    $cardCustom.BackColor = if ($script:mode -eq 'custom') { $surfaceActive } else { $surface }
    $mode10Title.Text = if ($script:mode -eq '10mb') { '●  MÁXIMO 10 MB' } else { '○  MÁXIMO 10 MB' }
    $modeCustomTitle.Text = if ($script:mode -eq 'custom') { '●  PERSONALIZADO' } else { '○  PERSONALIZADO' }
    $card10.Invalidate()
    $cardCustom.Invalidate()
}
$choose10 = { if ($card10.Enabled) { $script:mode = '10mb'; & $updateCards } }
$chooseCustom = { if ($cardCustom.Enabled) { $script:mode = 'custom'; & $updateCards } }
$card10.Add_Click($choose10)
$mode10Title.Add_Click($choose10)
$tenHint.Add_Click($choose10)
$cardCustom.Add_Click($chooseCustom)
$modeCustomTitle.Add_Click($chooseCustom)
$customHint.Add_Click($chooseCustom)
$customUnit.Add_Click($chooseCustom)
$customSize.Add_Enter($chooseCustom)
$customSize.Add_TextChanged($chooseCustom)
& $updateCards

$go = [Windows.Forms.Button]::new()
$go.Text = 'REEXPORTAR VIDEO  →'
$go.Location = [Drawing.Point]::new(32, 464)
$go.Size = [Drawing.Size]::new(230, 52)
$go.Enabled = $false
Style-Button $go $white $black $white
$form.Controls.Add($go)

$cancel = [Windows.Forms.Button]::new()
$cancel.Text = 'CANCELAR'
$cancel.Location = [Drawing.Point]::new(274, 464)
$cancel.Size = [Drawing.Size]::new(130, 52)
$cancel.Enabled = $false
$cancel.Visible = $false
Style-Button $cancel $black $white $line
$form.Controls.Add($cancel)

$openFolder = [Windows.Forms.Button]::new()
$openFolder.Text = 'ABRIR CARPETA'
$openFolder.Location = [Drawing.Point]::new(648, 464)
$openFolder.Size = [Drawing.Size]::new(160, 52)
$openFolder.Enabled = $false
$openFolder.Visible = $false
Style-Button $openFolder $black $white $line
$form.Controls.Add($openFolder)

$progressTrack = [Windows.Forms.Panel]::new()
$progressTrack.BackColor = $line
$progressTrack.Location = [Drawing.Point]::new(32, 540)
$progressTrack.Size = [Drawing.Size]::new(776, 4)
$form.Controls.Add($progressTrack)
$progressFill = [Windows.Forms.Panel]::new()
$progressFill.BackColor = $white
$progressFill.Location = [Drawing.Point]::new(0, 0)
$progressFill.Size = [Drawing.Size]::new(0, 4)
$progressTrack.Controls.Add($progressFill)

$status = New-Label 'LISTO PARA EMPEZAR' 32 553 776 25 $fontLabel $muted
$status.AutoEllipsis = $true
$form.Controls.Add($status)
$statusTip = [Windows.Forms.ToolTip]::new()
$footer = New-Label 'COMPI  /  GB FILMS' 32 581 300 19 $fontSmall $line
$form.Controls.Add($footer)

$setStatus = {
    param([string]$message, [string]$state)
    $status.Text = $message
    $status.ForeColor = if ($state -eq 'error') { $errorColor } elseif ($state -eq 'done') { $white } else { $muted }
    $statusTip.SetToolTip($status, $message)
}

$selectFile = {
    param([string]$path)
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    $script:inputPath = (Resolve-Path -LiteralPath $path).Path
    $script:outputPath = $null
    $openFolder.Enabled = $false
    $openFolder.Visible = $false
    $item = Get-Item -LiteralPath $script:inputPath
    $fileName.Text = $item.Name.ToUpperInvariant()
    $fileDetails.Text = ('{0:N2} MB  /  El resultado se guarda junto al original' -f ($item.Length / 1000000.0))
    $go.Enabled = $true
    & $setStatus 'VIDEO CARGADO · LISTO PARA REEXPORTAR' 'idle'
}

$browse.Add_Click({
    $dialog = [Windows.Forms.OpenFileDialog]::new()
    $dialog.Title = 'Compi · Elegí un video'
    $dialog.Filter = 'Videos|*.mp4;*.mov;*.mkv;*.avi;*.webm;*.wmv;*.m4v;*.mpeg;*.mpg;*.3gp;*.ts|Todos los archivos|*.*'
    if ($dialog.ShowDialog($form) -eq 'OK') { & $selectFile $dialog.FileName }
    $dialog.Dispose()
})

$dragEnter = {
    param($sender, $event)
    if ($event.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop)) {
        $event.Effect = [Windows.Forms.DragDropEffects]::Copy
    }
}
$dragDrop = {
    param($sender, $event)
    $paths = [string[]]$event.Data.GetData([Windows.Forms.DataFormats]::FileDrop)
    if ($paths.Count -gt 0) { & $selectFile $paths[0] }
}
foreach ($control in @($form, $drop, $dropTitle, $dropHint, $fileName, $fileDetails, $card10, $cardCustom, $mode10Title, $modeCustomTitle, $tenHint, $customHint, $customUnit)) {
    $control.AllowDrop = $true
    $control.Add_DragEnter($dragEnter)
    $control.Add_DragDrop($dragDrop)
}

$timer = [Windows.Forms.Timer]::new()
$timer.Interval = 400
$timer.Add_Tick({
    if (-not $script:worker) { return }
    $statusFile = Join-Path $script:jobDir 'status.json'
    $finished = $false
    if (Test-Path -LiteralPath $statusFile) {
        try {
            $data = Get-Content -LiteralPath $statusFile -Raw -Encoding UTF8 | ConvertFrom-Json
            $progressValue = [Math]::Max(0, [Math]::Min(100, [int]$data.progress))
            $progressFill.Width = [int][Math]::Round(776 * $progressValue / 100)
            & $setStatus ([string]$data.message) ([string]$data.state)
            if ($data.state -in @('done', 'error', 'cancelled')) {
                $finished = $true
                $timer.Stop()
                $browse.Enabled = $true
                $go.Enabled = $true
                $cancel.Enabled = $false
                $cancel.Visible = $false
                $card10.Enabled = $true
                $cardCustom.Enabled = $true
                if ($data.state -eq 'done') {
                    $script:outputPath = [string]$data.output
                    $openFolder.Enabled = $true
                    $openFolder.Visible = $true
                    & $setStatus ('LISTO  /  ' + [string]$data.message + '  ·  ABRÍ LA CARPETA PARA VERLO') 'done'
                } elseif ($data.state -eq 'cancelled') {
                    & $setStatus 'CANCELADO · EL ORIGINAL NO SE MODIFICÓ' 'idle'
                }
                $script:worker = $null
            }
        } catch { }
    }
    if (-not $finished -and $script:worker -and $script:worker.HasExited) {
        $timer.Stop()
        $browse.Enabled = $true
        $go.Enabled = $true
        $cancel.Enabled = $false
        $cancel.Visible = $false
        $card10.Enabled = $true
        $cardCustom.Enabled = $true
        & $setStatus 'EL PROCESO TERMINÓ SIN INFORMAR EL RESULTADO' 'error'
        $script:worker = $null
    }
})

$go.Add_Click({
    if (-not $script:inputPath) {
        & $setStatus 'PRIMERO ELEGÍ UN VIDEO' 'error'
        return
    }
    $targetBytes = 0L
    if ($script:mode -eq 'custom') {
        $valueText = $customSize.Text.Trim().Replace(',', '.')
        $amount = [decimal]::Zero
        $valid = [decimal]::TryParse($valueText, [Globalization.NumberStyles]::AllowDecimalPoint, [Globalization.CultureInfo]::InvariantCulture, [ref]$amount)
        if (-not $valid -or $amount -le 0 -or $amount -gt ([decimal][long]::MaxValue / 1000000)) {
            & $setStatus 'INGRESÁ UN TAMAÑO VÁLIDO EN MB, POR EJEMPLO 7,5' 'error'
            $customSize.Focus() | Out-Null
            return
        }
        $targetBytes = [long][decimal]::Floor($amount * 1000000)
        if ($targetBytes -lt 1) {
            & $setStatus 'EL TAMAÑO PERSONALIZADO DEBE SER MAYOR A CERO' 'error'
            $customSize.Focus() | Out-Null
            return
        }
    }
    $script:jobDir = Join-Path ([IO.Path]::GetTempPath()) ('reexportar-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $script:jobDir -Force | Out-Null
    $jobFile = Join-Path $script:jobDir 'job.json'
    @{ input = $script:inputPath; mode = $script:mode; target_bytes = $targetBytes; directory = $script:jobDir } |
        ConvertTo-Json -Compress | Set-Content -LiteralPath $jobFile -Encoding UTF8
    $psi = [Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $workerPath = Join-Path $PSScriptRoot 'Worker.ps1'
    $psi.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $workerPath + '" -JobFile "' + $jobFile + '"'
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    try {
        $script:worker = [Diagnostics.Process]::Start($psi)
        $script:outputPath = $null
        $openFolder.Enabled = $false
        $openFolder.Visible = $false
        $browse.Enabled = $false
        $go.Enabled = $false
        $cancel.Enabled = $true
        $cancel.Visible = $true
        $card10.Enabled = $false
        $cardCustom.Enabled = $false
        $progressFill.Width = 0
        & $setStatus 'INICIANDO REEXPORTACIÓN...' 'running'
        $timer.Start()
    } catch {
        & $setStatus ('NO SE PUDO INICIAR: ' + $_.Exception.Message) 'error'
    }
})

$cancel.Add_Click({
    if ($script:worker) {
        New-Item -ItemType File -Path (Join-Path $script:jobDir 'cancel') -Force | Out-Null
        & $setStatus 'CANCELANDO...' 'running'
        $cancel.Enabled = $false
    }
})

$openFolder.Add_Click({
    if ($script:outputPath -and (Test-Path -LiteralPath $script:outputPath)) {
        Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"' + $script:outputPath + '"')
    }
})

$form.Add_FormClosing({
    if ($script:worker -and -not $script:worker.HasExited) {
        New-Item -ItemType File -Path (Join-Path $script:jobDir 'cancel') -Force | Out-Null
    }
})

[void]$form.ShowDialog()
