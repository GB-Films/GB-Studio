Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$appRoot = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($appRoot)) { $appRoot = [string]$CompiRoot }
Add-Type -Path (Join-Path $appRoot 'PhotoTools.cs') -ReferencedAssemblies 'System.Drawing', 'System.Windows.Forms'
Add-Type -Path (Join-Path $appRoot 'VideoTools.cs') -ReferencedAssemblies 'System.Drawing', 'System.Windows.Forms'
[System.Windows.Forms.Application]::EnableVisualStyles()
$appVersion = (Get-Content -LiteralPath (Join-Path $appRoot 'VERSION') -Raw -Encoding UTF8).Trim()

$script:inputPath = $null
$script:outputPath = $null
$script:worker = $null
$script:jobDir = $null
$script:section = 'video'
$script:photoPath = $null
$script:photoOutputPath = $null
$script:photoDimensions = $null
$script:photoSourceBytes = 0L
$script:photoSourcePixels = 0L
$script:updatingDimensions = $false
$script:lockedAspectWidth = $null
$script:lockedAspectHeight = $null

$black = [Drawing.Color]::FromArgb(8, 9, 10)
$surface = [Drawing.Color]::FromArgb(20, 21, 23)
$surfaceActive = [Drawing.Color]::FromArgb(30, 32, 35)
$line = [Drawing.Color]::FromArgb(69, 72, 76)
$white = [Drawing.Color]::FromArgb(248, 248, 246)
$muted = [Drawing.Color]::FromArgb(164, 166, 169)
$accentPink = [Drawing.Color]::FromArgb(227, 8, 126)
$errorColor = [Drawing.Color]::FromArgb(255, 129, 129)
$fontBody = [Drawing.Font]::new('Segoe UI', 10)
$fontSmall = [Drawing.Font]::new('Segoe UI', 9)
$fontLabel = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 11, [Drawing.FontStyle]::Bold)
$fontHeading = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 31, [Drawing.FontStyle]::Bold)
$fontDrop = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 22, [Drawing.FontStyle]::Bold)
$fontOption = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 21, [Drawing.FontStyle]::Bold)
$fontDimension = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 20, [Drawing.FontStyle]::Bold)
$script:statusShown = $false

function New-Label([string]$text, [int]$x, [int]$y, [int]$width, [int]$height, $font, $color) {
    $label = [Windows.Forms.Label]::new()
    $label.Text = $text
    $label.Location = [Drawing.Point]::new($x, $y)
    $label.Size = [Drawing.Size]::new($width, $height)
    $label.Font = $font
    $label.ForeColor = $color
    $label.BackColor = [Drawing.Color]::Transparent
    return $label
}

function Style-Button($button, $background, $foreground, $border) {
    $button.BackColor = $background
    $button.ForeColor = $foreground
    $button.FlatStyle = 'Flat'
    $button.FlatAppearance.BorderColor = $border
    $button.FlatAppearance.BorderSize = 1
    $button.TextAlign = 'MiddleCenter'
    $button.Padding = [Windows.Forms.Padding]::Empty
    $button.UseVisualStyleBackColor = $false
    $button.Cursor = [Windows.Forms.Cursors]::Hand
    $button.Font = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 12, [Drawing.FontStyle]::Bold)
}

function Open-ExportedFile([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    Start-Process -FilePath (Join-Path $env:WINDIR 'explorer.exe') -ArgumentList ('/select,"' + $path + '"')
}

$form = [Windows.Forms.Form]::new()
$form.Text = 'COMPI  ·  v' + $appVersion
$form.ClientSize = [Drawing.Size]::new(840, 644)
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.StartPosition = 'CenterScreen'
$form.BackColor = $black
$form.ForeColor = $white
$form.Font = $fontBody
$form.AutoScaleMode = 'Dpi'
$form.AllowDrop = $true
try {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CompiDwm {
    [DllImport("dwmapi.dll")]
    public static extern int DwmSetWindowAttribute(IntPtr window, int attribute, ref int value, int size);
}
'@ -ErrorAction Stop
    $form.Add_Shown({
        $dark = 1
        $result = [CompiDwm]::DwmSetWindowAttribute($form.Handle, 20, [ref]$dark, 4)
        if ($result -ne 0) { [CompiDwm]::DwmSetWindowAttribute($form.Handle, 19, [ref]$dark, 4) | Out-Null }
    })
} catch { }

$iconPath = Join-Path $appRoot 'assets\Compi.ico'
if (Test-Path -LiteralPath $iconPath) { $form.Icon = [Drawing.Icon]::new($iconPath) }
$mark = [Windows.Forms.PictureBox]::new()
$mark.BackColor = $black
$mark.Location = [Drawing.Point]::new(32, 21)
$mark.Size = [Drawing.Size]::new(76, 76)
$mark.SizeMode = 'Zoom'
$markPath = Join-Path $appRoot 'assets\Compi-icon.png'
if (Test-Path -LiteralPath $markPath) { $mark.Image = [Drawing.Bitmap]::new($markPath) }
elseif ($form.Icon) { $mark.Image = $form.Icon.ToBitmap() }
$form.Controls.Add($mark)

$title = New-Label 'COMPI' 121 26 360 57 $fontHeading $white
$form.Controls.Add($title)
$eyebrow = New-Label ('VIDEO  /  FOTO     ·     V' + $appVersion) 126 82 340 21 $fontLabel $muted
$form.Controls.Add($eyebrow)
$rule = [Windows.Forms.Panel]::new()
$rule.BackColor = $line
$rule.Location = [Drawing.Point]::new(32, 124)
$rule.Size = [Drawing.Size]::new(776, 1)
$form.Controls.Add($rule)

$videoStep1 = New-Label '01  /  ELEGÍ TU VIDEO' 32 143 400 21 $fontLabel $muted
$form.Controls.Add($videoStep1)
$drop = [Windows.Forms.Panel]::new()
$drop.BackColor = $surface
$drop.Location = [Drawing.Point]::new(32, 174)
$drop.Size = [Drawing.Size]::new(776, 152)
$drop.Add_Paint({
    param($sender, $event)
    $pen = [Drawing.Pen]::new($line, 1)
    $pen.DashStyle = [Drawing.Drawing2D.DashStyle]::Dash
    $event.Graphics.DrawRectangle($pen, 0, 0, $sender.Width - 1, $sender.Height - 1)
    $pen.Dispose()
})
$form.Controls.Add($drop)

$dropTitle = New-Label 'ARRASTRÁ TU VIDEO ACÁ' 24 22 500 37 $fontDrop $white
$drop.Controls.Add($dropTitle)
$dropHint = New-Label 'O elegilo desde tu equipo para empezar.' 26 62 520 26 $fontBody $muted
$drop.Controls.Add($dropHint)
$videoThumbFrame = [Windows.Forms.Panel]::new()
$videoThumbFrame.Location = [Drawing.Point]::new(24, 16)
$videoThumbFrame.Size = [Drawing.Size]::new(184, 120)
$videoThumbFrame.BackColor = $surfaceActive
$videoThumbFrame.Add_Paint({
    param($sender, $event)
    $pen = [Drawing.Pen]::new($line, 1)
    $event.Graphics.DrawRectangle($pen, 0, 0, $sender.Width - 1, $sender.Height - 1)
    $pen.Dispose()
})
$videoThumbFrame.Visible = $false
$drop.Controls.Add($videoThumbFrame)
$videoThumbnail = [Windows.Forms.PictureBox]::new()
$videoThumbnail.Location = [Drawing.Point]::new(1, 1)
$videoThumbnail.Size = [Drawing.Size]::new(182, 118)
$videoThumbnail.BackColor = $surfaceActive
$videoThumbnail.SizeMode = 'Zoom'
$videoThumbnail.Add_Paint({
    param($sender, $event)
    if ($sender.Image) { return }
    $event.Graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $brush = [Drawing.SolidBrush]::new($muted)
    $points = [Drawing.Point[]]@(
        [Drawing.Point]::new(78, 44),
        [Drawing.Point]::new(78, 74),
        [Drawing.Point]::new(106, 59)
    )
    $event.Graphics.FillPolygon($brush, $points)
    $brush.Dispose()
})
$videoThumbFrame.Controls.Add($videoThumbnail)
$fileName = New-Label '' 225 37 365 36 $fontOption $white
$fileName.AutoEllipsis = $true
$fileName.Visible = $false
$drop.Controls.Add($fileName)
$videoDetails = New-Label '' 227 79 355 26 $fontBody $muted
$videoDetails.Visible = $false
$drop.Controls.Add($videoDetails)

$browse = [Windows.Forms.Button]::new()
$browse.Text = 'ELEGIR VIDEO'
$browse.Location = [Drawing.Point]::new(606, 49)
$browse.Size = [Drawing.Size]::new(145, 48)
Style-Button $browse $surface $white $white
$drop.Controls.Add($browse)

$modeLabel = New-Label '02  /  ELEGÍ EL TAMAÑO' 32 339 400 21 $fontLabel $muted
$form.Controls.Add($modeLabel)

$sizeCard = [Windows.Forms.Panel]::new()
$sizeCard.Location = [Drawing.Point]::new(32, 367)
$sizeCard.Size = [Drawing.Size]::new(776, 115)
$sizeCard.BackColor = $surface
$sizeCard.Add_Paint({
    param($sender, $event)
    $pen = [Drawing.Pen]::new($line, 1)
    $event.Graphics.DrawRectangle($pen, 0, 0, $sender.Width - 1, $sender.Height - 1)
    $pen.Dispose()
})
$form.Controls.Add($sizeCard)
$sizeLabel = New-Label 'TAMAÑO FINAL DESEADO' 30 34 480 48 $fontDrop $white
$sizeCard.Controls.Add($sizeLabel)
$customSize = [Windows.Forms.TextBox]::new()
$customSize.Text = '10'
$customSize.Location = [Drawing.Point]::new(553, 34)
$customSize.Size = [Drawing.Size]::new(132, 49)
$sizeValueFont = [Drawing.Font]::new('Bahnschrift SemiBold Condensed', 27, [Drawing.FontStyle]::Bold)
$customSize.Font = $sizeValueFont
$customSize.ForeColor = $white
$customSize.BackColor = $surface
$customSize.BorderStyle = 'None'
$customSize.TextAlign = 'Right'
$customSize.MaxLength = 12
$sizeCard.Controls.Add($customSize)
$customUnit = New-Label 'MB' 699 41 57 48 $sizeValueFont $white
$sizeCard.Controls.Add($customUnit)
$sizeUnderline = [Windows.Forms.Panel]::new()
$sizeUnderline.Location = [Drawing.Point]::new(553, 86)
$sizeUnderline.Size = [Drawing.Size]::new(203, 2)
$sizeUnderline.BackColor = $line
$sizeCard.Controls.Add($sizeUnderline)
$customSize.Add_Enter({ $sizeUnderline.BackColor = $accentPink })
$customSize.Add_Leave({
    $customSize.SelectionLength = 0
    $sizeUnderline.BackColor = $line
})
$sizeCard.Add_Click({ $form.ActiveControl = $null })
$sizeLabel.Add_Click({ $form.ActiveControl = $null })
$customUnit.Add_Click({ $form.ActiveControl = $null })
$form.Add_Click({ $form.ActiveControl = $null })

$go = [CompiActionButton]::new()
$go.Text = 'REEXPORTAR VIDEO'
$go.Location = [Drawing.Point]::new(32, 518)
$go.Size = [Drawing.Size]::new(230, 52)
$go.Enabled = $false
Style-Button $go $white $black $white
$form.Controls.Add($go)

$cancel = [Windows.Forms.Button]::new()
$cancel.Text = 'CANCELAR'
$cancel.Location = [Drawing.Point]::new(274, 518)
$cancel.Size = [Drawing.Size]::new(130, 52)
$cancel.Enabled = $false
$cancel.Visible = $false
Style-Button $cancel $black $white $line
$form.Controls.Add($cancel)

$progressTrack = [Windows.Forms.Panel]::new()
$progressTrack.BackColor = $line
$progressTrack.Location = [Drawing.Point]::new(32, 582)
$progressTrack.Size = [Drawing.Size]::new(776, 7)
$progressTrack.Visible = $false
$form.Controls.Add($progressTrack)
$progressFill = [Windows.Forms.Panel]::new()
$progressFill.BackColor = $accentPink
$progressFill.Location = [Drawing.Point]::new(0, 0)
$progressFill.Size = [Drawing.Size]::new(0, 7)
$progressTrack.Controls.Add($progressFill)
$progressPulse = [Windows.Forms.Panel]::new()
$progressPulse.BackColor = $accentPink
$progressPulse.Location = [Drawing.Point]::new(0, 0)
$progressPulse.Size = [Drawing.Size]::new(90, 7)
$progressPulse.Visible = $false
$progressTrack.Controls.Add($progressPulse)

$status = New-Label '' 32 596 776 25 $fontLabel $muted
$status.AutoEllipsis = $true
$status.Visible = $false
$form.Controls.Add($status)
$openVideoFolder = [Windows.Forms.Button]::new()
$openVideoFolder.Text = 'ABRIR CARPETA'
$openVideoFolder.Location = [Drawing.Point]::new(644, 590)
$openVideoFolder.Size = [Drawing.Size]::new(164, 34)
$openVideoFolder.Visible = $false
Style-Button $openVideoFolder $surface $white $line
$openVideoFolder.Add_Click({ Open-ExportedFile $script:outputPath })
$form.Controls.Add($openVideoFolder)
$statusTip = [Windows.Forms.ToolTip]::new()

$videoControls = @($videoStep1, $drop, $modeLabel, $sizeCard, $go, $cancel, $progressTrack, $status, $openVideoFolder)

$tabVideo = [Windows.Forms.Button]::new()
$tabVideo.Text = 'VIDEO'
$tabVideo.Location = [Drawing.Point]::new(526, 48)
$tabVideo.Size = [Drawing.Size]::new(134, 42)
Style-Button $tabVideo $white $black $white
$form.Controls.Add($tabVideo)
$tabPhoto = [Windows.Forms.Button]::new()
$tabPhoto.Text = 'FOTO'
$tabPhoto.Location = [Drawing.Point]::new(674, 48)
$tabPhoto.Size = [Drawing.Size]::new(134, 42)
Style-Button $tabPhoto $surface $white $line
$form.Controls.Add($tabPhoto)

$photoPanel = [Windows.Forms.Panel]::new()
$photoPanel.Location = [Drawing.Point]::new(32, 143)
$photoPanel.Size = [Drawing.Size]::new(776, 500)
$photoPanel.BackColor = $black
$photoPanel.Visible = $false
$form.Controls.Add($photoPanel)

$photoStep1 = New-Label '01  /  ELEGÍ TU FOTO' 0 0 400 21 $fontLabel $muted
$photoPanel.Controls.Add($photoStep1)
$photoDrop = [Windows.Forms.Panel]::new()
$photoDrop.Location = [Drawing.Point]::new(0, 31)
$photoDrop.Size = [Drawing.Size]::new(776, 145)
$photoDrop.BackColor = $surface
$photoDrop.Add_Paint({
    param($sender, $event)
    $pen = [Drawing.Pen]::new($line, 1)
    $pen.DashStyle = [Drawing.Drawing2D.DashStyle]::Dash
    $event.Graphics.DrawRectangle($pen, 0, 0, $sender.Width - 1, $sender.Height - 1)
    $pen.Dispose()
})
$photoPanel.Controls.Add($photoDrop)
$photoDropTitle = New-Label 'ARRASTRÁ TU FOTO ACÁ' 24 19 500 38 $fontDrop $white
$photoDrop.Controls.Add($photoDropTitle)
$photoDropHint = New-Label 'O elegila desde tu equipo para empezar.' 26 58 520 25 $fontBody $muted
$photoDrop.Controls.Add($photoDropHint)
$photoThumbFrame = [Windows.Forms.Panel]::new()
$photoThumbFrame.Location = [Drawing.Point]::new(24, 13)
$photoThumbFrame.Size = [Drawing.Size]::new(184, 118)
$photoThumbFrame.BackColor = $surfaceActive
$photoThumbFrame.Add_Paint({
    param($sender, $event)
    $pen = [Drawing.Pen]::new($line, 1)
    $event.Graphics.DrawRectangle($pen, 0, 0, $sender.Width - 1, $sender.Height - 1)
    $pen.Dispose()
})
$photoThumbFrame.Visible = $false
$photoDrop.Controls.Add($photoThumbFrame)
$photoThumbnail = [Windows.Forms.PictureBox]::new()
$photoThumbnail.Location = [Drawing.Point]::new(1, 1)
$photoThumbnail.Size = [Drawing.Size]::new(182, 116)
$photoThumbnail.BackColor = $surfaceActive
$photoThumbnail.SizeMode = 'Zoom'
$photoThumbFrame.Controls.Add($photoThumbnail)
$photoName = New-Label '' 225 32 365 36 $fontOption $white
$photoName.AutoEllipsis = $true
$photoName.Visible = $false
$photoDrop.Controls.Add($photoName)
$photoDetails = New-Label '' 227 74 355 26 $fontBody $muted
$photoDetails.Visible = $false
$photoDrop.Controls.Add($photoDetails)
$photoBrowse = [Windows.Forms.Button]::new()
$photoBrowse.Text = 'ELEGIR FOTO'
$photoBrowse.Location = [Drawing.Point]::new(606, 47)
$photoBrowse.Size = [Drawing.Size]::new(145, 48)
Style-Button $photoBrowse $surface $white $white
$photoDrop.Controls.Add($photoBrowse)

$photoGoal = New-Label '02  /  DEFINÍ EL TAMAÑO' 0 194 400 23 $fontLabel $muted
$photoPanel.Controls.Add($photoGoal)
$widthCard = [Windows.Forms.Panel]::new()
$widthCard.Location = [Drawing.Point]::new(0, 224)
$widthCard.Size = [Drawing.Size]::new(230, 84)
$widthCard.BackColor = $surface
$photoPanel.Controls.Add($widthCard)
$widthLabel = New-Label 'ANCHO' 17 7 100 22 $fontLabel $muted
$widthCard.Controls.Add($widthLabel)
$photoWidth = [Windows.Forms.TextBox]::new()
$photoWidth.Location = [Drawing.Point]::new(17, 34)
$photoWidth.Size = [Drawing.Size]::new(151, 39)
$photoWidth.TextAlign = 'Left'
$photoWidth.Font = $fontDimension
$photoWidth.ForeColor = $white
$photoWidth.BackColor = $surface
$photoWidth.BorderStyle = 'None'
$photoWidth.MaxLength = 5
$widthCard.Controls.Add($photoWidth)
$widthUnit = New-Label 'PX' 183 44 40 28 $fontLabel $white
$widthCard.Controls.Add($widthUnit)
$times = New-Label '×' 236 244 18 35 $fontDimension $muted
$photoPanel.Controls.Add($times)
$heightCard = [Windows.Forms.Panel]::new()
$heightCard.Location = [Drawing.Point]::new(256, 224)
$heightCard.Size = [Drawing.Size]::new(230, 84)
$heightCard.BackColor = $surface
$photoPanel.Controls.Add($heightCard)
$heightLabel = New-Label 'ALTO' 17 7 100 22 $fontLabel $muted
$heightCard.Controls.Add($heightLabel)
$photoHeight = [Windows.Forms.TextBox]::new()
$photoHeight.Location = [Drawing.Point]::new(17, 34)
$photoHeight.Size = [Drawing.Size]::new(151, 39)
$photoHeight.TextAlign = 'Left'
$photoHeight.Font = $fontDimension
$photoHeight.ForeColor = $white
$photoHeight.BackColor = $surface
$photoHeight.BorderStyle = 'None'
$photoHeight.MaxLength = 5
$heightCard.Controls.Add($photoHeight)
$heightUnit = New-Label 'PX' 183 44 40 28 $fontLabel $white
$heightCard.Controls.Add($heightUnit)
$numericPhotoKeyPress = {
    param($sender, $event)
    $code = [int][char]$event.KeyChar
    if (-not [char]::IsControl($event.KeyChar) -and ($code -lt 48 -or $code -gt 57)) {
        $event.Handled = $true
    }
}
$numericPhotoTextChanged = {
    param($sender, $event)
    if ($script:normalizingPhotoInput) { return }
    $clean = [Text.RegularExpressions.Regex]::Replace($sender.Text, '[^0-9]', '')
    if ($clean -eq $sender.Text) { return }
    $caret = [Text.RegularExpressions.Regex]::Replace($sender.Text.Substring(0, $sender.SelectionStart), '[^0-9]', '').Length
    $script:normalizingPhotoInput = $true
    try {
        $sender.Text = $clean
        $sender.SelectionStart = [Math]::Min($caret, $sender.Text.Length)
    } finally {
        $script:normalizingPhotoInput = $false
    }
}
$dimensionMouseDown = {
    param($sender, $event)
    if ($event.Button -ne [Windows.Forms.MouseButtons]::Left) { return }
    $startValue = 0
    if (-not [int]::TryParse($sender.Text, [ref]$startValue)) { $startValue = 1 }
    $script:dimensionDragControl = $sender
    $script:dimensionDragStartX = $event.X
    $script:dimensionDragStartValue = $startValue
    $script:dimensionDragActive = $false
}
$dimensionMouseMove = {
    param($sender, $event)
    if ($script:dimensionDragControl -ne $sender) { return }
    if (($event.Button -band [Windows.Forms.MouseButtons]::Left) -eq 0) {
        $script:dimensionDragControl = $null
        $script:dimensionDragActive = $false
        $sender.Cursor = [Windows.Forms.Cursors]::IBeam
        return
    }
    $distance = $event.X - $script:dimensionDragStartX
    if (-not $script:dimensionDragActive -and [Math]::Abs($distance) -lt 5) { return }
    $script:dimensionDragActive = $true
    $sender.Cursor = [Windows.Forms.Cursors]::SizeWE
    $step = if (([Windows.Forms.Control]::ModifierKeys -band [Windows.Forms.Keys]::Shift) -ne 0) { 1 } else { 5 }
    $next = [int][Math]::Max(1, [Math]::Min(12000, $script:dimensionDragStartValue + $distance * $step))
    $sender.Text = [string]$next
    $sender.SelectionStart = $sender.Text.Length
    $sender.SelectionLength = 0
}
$dimensionMouseUp = {
    param($sender, $event)
    if ($script:dimensionDragControl -eq $sender) {
        $wasDragging = $script:dimensionDragActive
        $script:dimensionDragControl = $null
        $script:dimensionDragActive = $false
        $sender.Cursor = [Windows.Forms.Cursors]::IBeam
        if ($wasDragging) { $sender.SelectionLength = 0 }
    }
}
foreach ($input in @($photoWidth, $photoHeight)) {
    $input.Add_KeyPress($numericPhotoKeyPress)
    $input.Add_TextChanged($numericPhotoTextChanged)
    $input.Add_MouseDown($dimensionMouseDown)
    $input.Add_MouseMove($dimensionMouseMove)
    $input.Add_MouseUp($dimensionMouseUp)
    $statusTip.SetToolTip($input, 'Arrastrá el número para ajustar. Mantené Shift para mayor precisión.')
}
$dimensionPaint = {
    param($sender, $event)
    $border = if ($sender.ContainsFocus) { $accentPink } else { $line }
    $pen = [Drawing.Pen]::new($border, 1)
    $event.Graphics.DrawRectangle($pen, 0, 0, $sender.Width - 1, $sender.Height - 1)
    $pen.Dispose()
}
$widthCard.Add_Paint($dimensionPaint)
$heightCard.Add_Paint($dimensionPaint)
$photoWidth.Add_Enter({ $widthCard.Invalidate() })
$photoWidth.Add_Leave({ $widthCard.Invalidate() })
$photoHeight.Add_Enter({ $heightCard.Invalidate() })
$photoHeight.Add_Leave({ $heightCard.Invalidate() })
foreach ($control in @($widthCard, $widthLabel, $widthUnit)) {
    $control.Cursor = [Windows.Forms.Cursors]::IBeam
    $control.Add_Click({ $photoWidth.Focus() | Out-Null })
}
foreach ($control in @($heightCard, $heightLabel, $heightUnit)) {
    $control.Cursor = [Windows.Forms.Cursors]::IBeam
    $control.Add_Click({ $photoHeight.Focus() | Out-Null })
}
$keepAspect = [Windows.Forms.CheckBox]::new()
$keepAspect.Checked = $true
$keepAspect.Visible = $false
$keepAspect.TabStop = $false
$photoPanel.Controls.Add($keepAspect)
$aspectToggle = [Windows.Forms.Button]::new()
$aspectToggle.Text = 'MANTENER PROPORCIÓN'
$aspectToggle.Location = [Drawing.Point]::new(542, 224)
$aspectToggle.Size = [Drawing.Size]::new(234, 84)
Style-Button $aspectToggle $surfaceActive $white $white
$aspectToggle.Padding = [Windows.Forms.Padding]::new(33, 0, 0, 0)
$aspectToggle.Add_Click({ $keepAspect.Checked = -not $keepAspect.Checked })
$aspectToggle.Add_Paint({
    param($sender, $event)
    $square = [Drawing.Rectangle]::new(16, 33, 18, 18)
    if ($keepAspect.Checked) {
        $event.Graphics.FillRectangle([Drawing.Brushes]::White, $square)
        $check = [Drawing.Pen]::new($black, 2)
        $event.Graphics.DrawLines($check, [Drawing.Point[]]@(
            [Drawing.Point]::new(19, 42),
            [Drawing.Point]::new(23, 46),
            [Drawing.Point]::new(31, 37)
        ))
        $check.Dispose()
    } else {
        $outline = [Drawing.Pen]::new($muted, 1)
        $event.Graphics.DrawRectangle($outline, $square)
        $outline.Dispose()
    }
})
$photoPanel.Controls.Add($aspectToggle)
$photoEstimate = New-Label '' 0 315 520 22 $fontLabel $muted
$photoEstimate.Visible = $false
$photoPanel.Controls.Add($photoEstimate)
$photoStep3 = New-Label '03  /  REENCUADRÁ ANTES DE EXPORTAR' 0 341 500 23 $fontLabel $muted
$photoPanel.Controls.Add($photoStep3)
$photoExport = [CompiActionButton]::new()
$photoExport.Text = 'REENCUADRAR Y REEXPORTAR FOTO'
$photoExport.Location = [Drawing.Point]::new(0, 371)
$photoExport.Size = [Drawing.Size]::new(306, 52)
$photoExport.Enabled = $false
Style-Button $photoExport $white $black $white
$photoPanel.Controls.Add($photoExport)
$photoStatus = New-Label '' 0 439 776 25 $fontLabel $muted
$photoStatus.AutoEllipsis = $true
$photoStatus.Visible = $false
$photoPanel.Controls.Add($photoStatus)
$openPhotoFolder = [Windows.Forms.Button]::new()
$openPhotoFolder.Text = 'ABRIR CARPETA'
$openPhotoFolder.Location = [Drawing.Point]::new(620, 433)
$openPhotoFolder.Size = [Drawing.Size]::new(156, 34)
$openPhotoFolder.Visible = $false
Style-Button $openPhotoFolder $surface $white $line
$openPhotoFolder.Add_Click({ Open-ExportedFile $script:photoOutputPath })
$photoPanel.Controls.Add($openPhotoFolder)

$switchSection = {
    param([string]$next)
    if ($script:worker -and $next -ne 'video') { return }
    $script:section = $next
    $isVideo = $next -eq 'video'
    foreach ($control in $videoControls) { $control.Visible = $isVideo }
    $hasVideoOutput = $script:outputPath -and (Test-Path -LiteralPath $script:outputPath -PathType Leaf)
    $openVideoFolder.Visible = $isVideo -and [bool]$hasVideoOutput
    $status.Width = if ($hasVideoOutput) { 590 } else { 776 }
    $cancel.Visible = $isVideo -and ($null -ne $script:worker)
    $progressTrack.Visible = $isVideo -and ($null -ne $script:worker)
    $status.Visible = $isVideo -and $script:statusShown
    $photoPanel.Visible = -not $isVideo
    Style-Button $tabVideo $(if ($isVideo) { $white } else { $surface }) $(if ($isVideo) { $black } else { $white }) $(if ($isVideo) { $white } else { $line })
    Style-Button $tabPhoto $(if ($isVideo) { $surface } else { $white }) $(if ($isVideo) { $white } else { $black }) $(if ($isVideo) { $line } else { $white })
}
$tabVideo.Add_Click({ & $switchSection 'video' })
$tabPhoto.Add_Click({ & $switchSection 'photo' })

$setStatus = {
    param([string]$message, [string]$state)
    $status.Text = $message
    $status.ForeColor = if ($state -eq 'error') { $errorColor } elseif ($state -eq 'done') { $white } else { $muted }
    $statusTip.SetToolTip($status, $message)
    $script:statusShown = $true
    $status.Visible = $script:section -eq 'video'
    $hasOutput = $state -eq 'done' -and $script:outputPath -and (Test-Path -LiteralPath $script:outputPath -PathType Leaf)
    $status.Width = if ($hasOutput) { 590 } else { 776 }
    $openVideoFolder.Visible = ($script:section -eq 'video') -and [bool]$hasOutput
}

$script:previewFfmpeg = $null
$script:previewFfprobe = $null
$localVideoTools = Join-Path $env:LOCALAPPDATA 'ReexportarVideo\bin'
foreach ($toolName in @('ffmpeg', 'ffprobe')) {
    $installed = Get-Command ($toolName + '.exe') -ErrorAction SilentlyContinue
    $candidate = if ($installed) { $installed.Source } else { Join-Path $localVideoTools ($toolName + '.exe') }
    if (Test-Path -LiteralPath $candidate -PathType Leaf) {
        if ($toolName -eq 'ffmpeg') { $script:previewFfmpeg = $candidate }
        else { $script:previewFfprobe = $candidate }
    }
}
$videoInfoReady = [Action[CompiVideoInfo]] {
    param([CompiVideoInfo]$info)
    if ($script:inputPath -ne $info.Path -or $form.IsDisposed) {
        if ($info.Thumbnail) { $info.Thumbnail.Dispose() }
        return
    }
    $old = $videoThumbnail.Image
    $videoThumbnail.Image = $info.Thumbnail
    if ($old) { $old.Dispose() }
    $videoThumbnail.Invalidate()
    if ($info.Duration) {
        $duration = if ($info.Duration.TotalHours -ge 1) {
            $info.Duration.ToString('hh\:mm\:ss')
        } else {
            $info.Duration.ToString('mm\:ss')
        }
        $videoDetails.Text = $script:videoSizeText + '  /  ' + $duration
    }
}

$selectFile = {
    param([string]$path)
    if ($script:worker) { return }
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    $extension = [IO.Path]::GetExtension($path).ToLowerInvariant()
    if ($extension -notin @('.mp4', '.mov', '.mkv', '.avi', '.webm', '.wmv', '.m4v', '.mpeg', '.mpg', '.3gp', '.ts')) {
        [Windows.Forms.MessageBox]::Show($form, 'Este formato de video no es compatible con Compi.', 'Compi', 'OK', 'Warning') | Out-Null
        return
    }
    $script:inputPath = (Resolve-Path -LiteralPath $path).Path
    $script:outputPath = $null
    $openVideoFolder.Visible = $false
    $status.Width = 776
    $item = Get-Item -LiteralPath $script:inputPath
    $script:videoSizeText = ('{0:N2} MB' -f ($item.Length / 1000000.0))
    $fileName.Text = $item.Name
    $statusTip.SetToolTip($fileName, $item.Name)
    $fileName.Visible = $true
    $videoDetails.Text = $script:videoSizeText
    $videoDetails.Visible = $true
    $dropTitle.Visible = $false
    $dropHint.Visible = $false
    $videoThumbFrame.Visible = $true
    $old = $videoThumbnail.Image
    $videoThumbnail.Image = $null
    if ($old) { $old.Dispose() }
    $videoThumbnail.Invalidate()
    $browse.Text = 'REEMPLAZAR VIDEO'
    $go.Enabled = $true
    $script:statusShown = $false
    $status.Visible = $false
    $progressTrack.Visible = $false
    [CompiVideo]::LoadAsync($form, $script:inputPath, $script:previewFfmpeg, $script:previewFfprobe, $videoInfoReady)
}

$setPhotoStatus = {
    param([string]$message, [bool]$error = $false, [bool]$success = $false)
    $photoStatus.Text = $message
    $photoStatus.ForeColor = if ($error) { $errorColor } else { $muted }
    $photoStatus.Width = if ($success) { 570 } else { 776 }
    $photoStatus.Visible = $true
    $openPhotoFolder.Visible = $success -and $script:photoOutputPath -and (Test-Path -LiteralPath $script:photoOutputPath -PathType Leaf)
}
$updatePhotoEstimate = {
    if (-not $script:photoPath -or $script:photoSourcePixels -le 0 -or $script:photoSourceBytes -le 0) {
        $photoEstimate.Visible = $false
        return
    }
    $width = 0
    $height = 0
    if (-not [int]::TryParse($photoWidth.Text, [ref]$width) -or
        -not [int]::TryParse($photoHeight.Text, [ref]$height) -or $width -lt 1 -or $height -lt 1) {
        $photoEstimate.Text = 'PESO ESTIMADO  /  COMPLETÁ ANCHO Y ALTO'
        $photoEstimate.Visible = $true
        return
    }
    $targetPixels = [double]([long]$width * [long]$height)
    $estimatedBytes = [double]$script:photoSourceBytes * $targetPixels / [double]$script:photoSourcePixels
    $photoEstimate.Text = 'PESO ESTIMADO  /  ~{0:N2} MB' -f ($estimatedBytes / 1000000.0)
    $photoEstimate.Visible = $true
}
$statusTip.SetToolTip($photoEstimate, 'Estimación aproximada según el peso original y la resolución elegida. El resultado puede variar según el formato y el contenido de la imagen.')
$photoWidth.Add_TextChanged({ & $updatePhotoEstimate })
$photoHeight.Add_TextChanged({ & $updatePhotoEstimate })
$photoWidth.Add_TextChanged({
    if ($script:updatingDimensions -or -not $keepAspect.Checked -or -not $script:lockedAspectWidth) { return }
    $number = 0
    if ([int]::TryParse($photoWidth.Text, [ref]$number) -and $number -gt 0) {
        $script:updatingDimensions = $true
        $photoHeight.Text = [string][Math]::Max(1, [Math]::Round($number * $script:lockedAspectHeight / $script:lockedAspectWidth))
        $script:updatingDimensions = $false
    }
})
$photoHeight.Add_TextChanged({
    if ($script:updatingDimensions -or -not $keepAspect.Checked -or -not $script:lockedAspectHeight) { return }
    $number = 0
    if ([int]::TryParse($photoHeight.Text, [ref]$number) -and $number -gt 0) {
        $script:updatingDimensions = $true
        $photoWidth.Text = [string][Math]::Max(1, [Math]::Round($number * $script:lockedAspectWidth / $script:lockedAspectHeight))
        $script:updatingDimensions = $false
    }
})
$keepAspect.Add_CheckedChanged({
    $aspectToggle.BackColor = if ($keepAspect.Checked) { $surfaceActive } else { $surface }
    $aspectToggle.FlatAppearance.BorderColor = if ($keepAspect.Checked) { $white } else { $line }
    $aspectToggle.Invalidate()
    if ($keepAspect.Checked -and -not $script:updatingDimensions -and $script:photoDimensions) {
        $width = 0
        $height = 0
        if (-not [int]::TryParse($photoWidth.Text, [ref]$width) -or $width -lt 1 -or
            -not [int]::TryParse($photoHeight.Text, [ref]$height) -or $height -lt 1) {
            $keepAspect.Checked = $false
            & $setPhotoStatus 'COMPLETÁ ANCHO Y ALTO PARA MANTENER ESA PROPORCIÓN' $true
            return
        }
        $script:lockedAspectWidth = $width
        $script:lockedAspectHeight = $height
    }
})
$selectPhoto = {
    param([string]$path)
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    $extension = [IO.Path]::GetExtension($path).ToLowerInvariant()
    if ($extension -notin @('.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tif', '.tiff')) {
        [Windows.Forms.MessageBox]::Show($form, 'Este formato de foto no es compatible con Compi.', 'Compi', 'OK', 'Warning') | Out-Null
        return
    }
    $loaded = $null
    try {
        $dimensions = [CompiPhoto]::ReadDimensions($path)
        $loaded = [CompiPhoto]::Load($path)
        $scale = [Math]::Min(1.0, [Math]::Min(600.0 / $dimensions.Width, 600.0 / $dimensions.Height))
        $small = [Drawing.Bitmap]::new($loaded, [Drawing.Size]::new([int][Math]::Max(1, [Math]::Round($dimensions.Width * $scale)), [int][Math]::Max(1, [Math]::Round($dimensions.Height * $scale))))
        $old = $photoThumbnail.Image
        $photoThumbnail.Image = $small
        if ($old) { $old.Dispose() }
        $script:photoPath = (Resolve-Path -LiteralPath $path).Path
        $script:photoDimensions = $dimensions
        $script:photoOutputPath = $null
        $openPhotoFolder.Visible = $false
        $item = Get-Item -LiteralPath $script:photoPath
        $script:photoSourceBytes = [long]$item.Length
        $script:photoSourcePixels = [long]$dimensions.Width * [long]$dimensions.Height
        $script:updatingDimensions = $true
        $script:lockedAspectWidth = $dimensions.Width
        $script:lockedAspectHeight = $dimensions.Height
        $keepAspect.Checked = $true
        $photoWidth.Text = [string]$dimensions.Width
        $photoHeight.Text = [string]$dimensions.Height
        $script:updatingDimensions = $false
        $photoName.Text = $item.Name
        $statusTip.SetToolTip($photoName, $item.Name)
        $photoName.Visible = $true
        $photoDetails.Text = ('{0:N2} MB  /  {1} × {2} PX' -f ($item.Length / 1000000.0), $dimensions.Width, $dimensions.Height)
        $photoDetails.Visible = $true
        $photoDropTitle.Visible = $false
        $photoDropHint.Visible = $false
        $photoThumbFrame.Visible = $true
        $photoBrowse.Text = 'REEMPLAZAR FOTO'
        $photoExport.Enabled = $true
        $photoStatus.Visible = $false
        & $updatePhotoEstimate
    } catch {
        $message = if ($_.Exception -is [IO.InvalidDataException]) { $_.Exception.Message } else { 'No se pudo abrir esta foto. Comprobá que el archivo sea una imagen válida.' }
        [Windows.Forms.MessageBox]::Show($form, $message, 'Compi', 'OK', 'Warning') | Out-Null
    } finally {
        if ($loaded) { $loaded.Dispose() }
    }
}
$photoBrowse.Add_Click({
    $dialog = [Windows.Forms.OpenFileDialog]::new()
    $dialog.Title = 'Compi · Elegí una foto'
    $dialog.Filter = 'Fotos|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tif;*.tiff|Todos los archivos|*.*'
    if ($dialog.ShowDialog($form) -eq 'OK') { & $selectPhoto $dialog.FileName }
    $dialog.Dispose()
})
$photoExport.Add_Click({
    if (-not $script:photoPath) { & $setPhotoStatus 'PRIMERO ELEGÍ UNA FOTO' $true; return }
    $width = 0
    $height = 0
    if (-not [int]::TryParse($photoWidth.Text.Trim(), [ref]$width) -or
        -not [int]::TryParse($photoHeight.Text.Trim(), [ref]$height) -or
        $width -lt 1 -or $height -lt 1 -or $width -gt 12000 -or $height -gt 12000 -or
        ([long]$width * [long]$height) -gt 80000000) {
        & $setPhotoStatus 'INGRESÁ ANCHO Y ALTO ENTRE 1 Y 12.000 PX (MÁXIMO 80 MP)' $true
        return
    }
    try {
        $editor = [CompiCropEditor]::new($script:photoPath, $width, $height, $appVersion)
        $editor.Icon = $form.Icon
        try {
            if ($editor.ShowDialog($form) -eq [Windows.Forms.DialogResult]::OK) {
                $script:photoOutputPath = $editor.OutputPath
                $actualPhotoMB = (Get-Item -LiteralPath $editor.OutputPath).Length / 1000000.0
                & $setPhotoStatus ('LISTO  /  ' + [IO.Path]::GetFileName($editor.OutputPath) + ('  /  {0:N2} MB' -f $actualPhotoMB)) $false $true
            }
        } finally { $editor.Dispose() }
    } catch {
        & $setPhotoStatus ('NO SE PUDO PREPARAR LA FOTO: ' + $_.Exception.Message) $true
    }
})
$browse.Add_Click({
    if ($script:worker) { return }
    $dialog = [Windows.Forms.OpenFileDialog]::new()
    $dialog.Title = 'Compi · Elegí un video'
    $dialog.Filter = 'Videos|*.mp4;*.mov;*.mkv;*.avi;*.webm;*.wmv;*.m4v;*.mpeg;*.mpg;*.3gp;*.ts|Todos los archivos|*.*'
    if ($dialog.ShowDialog($form) -eq 'OK') { & $selectFile $dialog.FileName }
    $dialog.Dispose()
})

$dragEnter = {
    param($sender, $event)
    if ($event.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop)) {
        $event.Effect = [Windows.Forms.DragDropEffects]::Copy
    }
}
$dragDrop = {
    param($sender, $event)
    $paths = [string[]]$event.Data.GetData([Windows.Forms.DataFormats]::FileDrop)
    if ($paths.Count -gt 0) {
        if ($script:section -eq 'photo') { & $selectPhoto $paths[0] }
        else { & $selectFile $paths[0] }
    }
}
foreach ($control in @($form, $videoStep1, $drop, $dropTitle, $dropHint, $videoThumbFrame, $videoThumbnail, $fileName, $videoDetails, $sizeCard, $sizeLabel, $customUnit, $photoPanel, $photoStep1, $photoDrop, $photoDropTitle, $photoDropHint, $photoThumbFrame, $photoThumbnail, $photoName, $photoDetails, $photoGoal, $photoStep3, $widthCard, $widthLabel, $widthUnit, $heightCard, $heightLabel, $heightUnit, $times)) {
    $control.AllowDrop = $true
    $control.Add_DragEnter($dragEnter)
    $control.Add_DragDrop($dragDrop)
}

$restoreVideoUi = {
    $browse.Text = 'REEMPLAZAR VIDEO'
    $go.Text = 'REEXPORTAR VIDEO'
    $customSize.ReadOnly = $false
    $cancel.Enabled = $false
    $cancel.Visible = $false
    $progressPulse.Visible = $false
    $progressTrack.Visible = $false
}
$timer = [Windows.Forms.Timer]::new()
$timer.Interval = 400
$timer.Add_Tick({
    if (-not $script:worker) { return }
    if ($progressPulse.Visible) {
        $progressPulse.Left += 55
        if ($progressPulse.Left -ge $progressTrack.Width) { $progressPulse.Left = -$progressPulse.Width }
    }
    $statusFile = Join-Path $script:jobDir 'status.json'
    $finished = $false
    if (Test-Path -LiteralPath $statusFile) {
        try {
            $data = Get-Content -LiteralPath $statusFile -Raw -Encoding UTF8 | ConvertFrom-Json
            $progressValue = [Math]::Max(0, [Math]::Min(100, [int]$data.progress))
            if ($progressValue -gt 0) {
                $progressPulse.Visible = $false
                $progressFill.Width = [int][Math]::Round(776 * $progressValue / 100)
            }
            & $setStatus ([string]$data.message) ([string]$data.state)
            if ($data.state -in @('done', 'error', 'cancelled')) {
                $finished = $true
                $timer.Stop()
                & $restoreVideoUi
                if ($data.state -eq 'done') {
                    $script:outputPath = [string]$data.output
                    & $setStatus ('LISTO  /  ' + [string]$data.message + '  ·  GUARDADO JUNTO AL ORIGINAL') 'done'
                } elseif ($data.state -eq 'cancelled') {
                    & $setStatus 'CANCELADO · EL ORIGINAL NO SE MODIFICÓ' 'idle'
                }
                $script:worker = $null
            }
        } catch { }
    }
    if (-not $finished -and $script:worker -and $script:worker.HasExited) {
        $timer.Stop()
        & $restoreVideoUi
        & $setStatus 'EL PROCESO TERMINÓ SIN INFORMAR EL RESULTADO' 'error'
        $script:worker = $null
    }
})

$go.Add_Click({
    if ($script:worker) { return }
    if (-not $script:inputPath) {
        & $setStatus 'PRIMERO ELEGÍ UN VIDEO' 'error'
        return
    }
    $valueText = $customSize.Text.Trim().Replace(',', '.')
    $amount = [decimal]::Zero
    $valid = [decimal]::TryParse($valueText, [Globalization.NumberStyles]::AllowDecimalPoint, [Globalization.CultureInfo]::InvariantCulture, [ref]$amount)
    if (-not $valid -or $amount -le 0 -or $amount -gt ([decimal][long]::MaxValue / 1000000)) {
        & $setStatus 'INGRESÁ UN TAMAÑO VÁLIDO EN MB, POR EJEMPLO 7,5' 'error'
        $customSize.Focus() | Out-Null
        return
    }
    $targetBytes = [long][decimal]::Floor($amount * 1000000)
    if ($targetBytes -lt 1) {
        & $setStatus 'EL TAMAÑO DEBE SER MAYOR A CERO' 'error'
        $customSize.Focus() | Out-Null
        return
    }
    $script:jobDir = Join-Path ([IO.Path]::GetTempPath()) ('reexportar-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $script:jobDir -Force | Out-Null
    $jobFile = Join-Path $script:jobDir 'job.json'
    @{ input = $script:inputPath; mode = 'custom'; target_bytes = $targetBytes; directory = $script:jobDir } |
        ConvertTo-Json -Compress | Set-Content -LiteralPath $jobFile -Encoding UTF8
    $psi = [Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $workerPath = Join-Path $appRoot 'Worker.ps1'
    $workerSource = [IO.File]::ReadAllText($workerPath)
    $quotedJobFile = "'" + $jobFile.Replace("'", "''") + "'"
    $workerCommand = "& {`r`n" + $workerSource + "`r`n} -JobFile " + $quotedJobFile
    $encodedWorkerCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($workerCommand))
    $psi.Arguments = '-NoProfile -EncodedCommand ' + $encodedWorkerCommand
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    try {
        $script:worker = [Diagnostics.Process]::Start($psi)
        $script:outputPath = $null
        $form.ActiveControl = $null
        $browse.Text = 'PROCESANDO...'
        $go.Text = 'REEXPORTANDO VIDEO...'
        $customSize.ReadOnly = $true
        $cancel.Enabled = $true
        $cancel.Visible = $true
        $progressFill.Width = 0
        $progressPulse.Left = 0
        $progressPulse.Visible = $true
        $progressTrack.Visible = $true
        & $setStatus 'INICIANDO REEXPORTACIÓN...' 'running'
        $timer.Start()
    } catch {
        & $restoreVideoUi
        & $setStatus ('NO SE PUDO INICIAR: ' + $_.Exception.Message) 'error'
    }
})

$cancel.Add_Click({
    if ($script:worker) {
        New-Item -ItemType File -Path (Join-Path $script:jobDir 'cancel') -Force | Out-Null
        & $setStatus 'CANCELANDO...' 'running'
        $cancel.Enabled = $false
    }
})

$form.Add_FormClosing({
    $global:CompiClosedNormally = $true
    $timer.Stop()
    if ($script:worker -and -not $script:worker.HasExited) {
        New-Item -ItemType File -Path (Join-Path $script:jobDir 'cancel') -Force | Out-Null
    }
})

$form.ActiveControl = $tabVideo
$form.Add_Shown({
    $tabVideo.Focus() | Out-Null
})

[void]$form.ShowDialog()
