$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
$work = Join-Path (Split-Path $repo -Parent) 'work'
$testRoot = Join-Path $work ('quick-notice-test-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $testRoot | Out-Null
Copy-Item -LiteralPath (Join-Path $repo 'Compi.exe') -Destination (Join-Path $testRoot 'Compi.exe')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'QuickExportWorker.ps1') -Destination (Join-Path $testRoot 'Worker.ps1')
$exe = Join-Path $testRoot 'Compi.exe'
$processes = @()
foreach ($name in @('video A ñ', 'video B', 'fallo C')) {
    $source = Join-Path $testRoot ($name + '.mp4')
    [IO.File]::WriteAllText($source, 'Quick export test: ' + $name)
    $processes += Start-Process -FilePath $exe -ArgumentList ('--quick-video "' + $source + '"') -WindowStyle Hidden -PassThru
}
Start-Sleep -Milliseconds 1700
$markers = @(Get-ChildItem -LiteralPath $testRoot -Filter '*.compi-exportando')
if ($markers.Count -ne 3) { throw "Se esperaban 3 señales temporales, hay $($markers.Count)." }
if (-not ($markers | Where-Object Name -Match '\d+%')) { throw 'No se actualizó el porcentaje en los nombres.' }
$occupied = 0
foreach ($index in 0..2) {
    try { $slot = [Threading.Mutex]::OpenExisting('Local\Compi.ExportNotice.Slot.' + $index) } catch { continue }
    try { if ($slot.WaitOne(0)) { $slot.ReleaseMutex() } else { $occupied++ } } finally { $slot.Dispose() }
}
if ($occupied -lt 2) { throw 'Los avisos simultáneos no reservaron posiciones distintas.' }
$cancelMarker = $markers | Where-Object Name -Like 'video B*' | Select-Object -First 1
$cancelJob = Get-Content -LiteralPath $cancelMarker.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
[IO.File]::WriteAllText((Join-Path $cancelJob.directory 'cancel'), '')
$successMarker = $markers | Where-Object Name -Like 'video A*' | Select-Object -First 1
$viewer = Start-Process -FilePath $exe -ArgumentList ('--export-status "' + $successMarker.FullName + '"') -WindowStyle Hidden -PassThru -Wait
if ($viewer.ExitCode -ne 0) { throw 'No se pudo volver a mostrar el avance desde la señal.' }
Start-Sleep -Seconds 5
if (@(Get-ChildItem -LiteralPath $testRoot -Filter '*.compi-exportando').Count -ne 0) { throw 'Quedaron señales temporales después de terminar.' }
$success = Join-Path $testRoot 'video A ñ_reexportado.mp4'
if (-not (Test-Path -LiteralPath $success)) { throw 'No se creó la salida exitosa.' }
if ((Get-FileHash -LiteralPath $success).Hash -ne (Get-FileHash -LiteralPath (Join-Path $testRoot 'video A ñ.mp4')).Hash) { throw 'La salida no coincide.' }
if ((Test-Path -LiteralPath (Join-Path $testRoot 'video B_reexportado.mp4')) -or (Test-Path -LiteralPath (Join-Path $testRoot 'fallo C_reexportado.mp4'))) { throw 'Se creó salida para un trabajo cancelado o fallido.' }
foreach ($process in $processes) { if (-not $process.WaitForExit(35000)) { throw 'Un proceso no terminó después del aviso final.' } }
'OK: 3 exportaciones simultáneas, porcentaje, acceso al avance, éxito, cancelación, error y limpieza de señales.'
