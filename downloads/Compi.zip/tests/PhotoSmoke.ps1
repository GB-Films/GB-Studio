$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -Path (Join-Path (Split-Path $PSScriptRoot -Parent) 'PhotoTools.cs') -ReferencedAssemblies 'System.Drawing', 'System.Windows.Forms'

$folder = Join-Path $env:TEMP ('compi-photo-test-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $folder | Out-Null
$source = Join-Path $folder 'cuadrado.png'
$bitmap = [Drawing.Bitmap]::new(2000, 2000)
$graphics = [Drawing.Graphics]::FromImage($bitmap)
$graphics.Clear([Drawing.Color]::Lime)
$graphics.FillRectangle([Drawing.Brushes]::Red, 0, 0, 2000, 400)
$graphics.FillRectangle([Drawing.Brushes]::Blue, 0, 1600, 2000, 400)
$graphics.Dispose()
$bitmap.Save($source, [Drawing.Imaging.ImageFormat]::Png)
$bitmap.Dispose()

function Export-TestPhoto([int]$width, [int]$height, [bool]$moveTop = $false, [bool]$dragDown = $false, [bool]$zoomPan = $false) {
    $version = (Get-Content -LiteralPath (Join-Path (Split-Path $PSScriptRoot -Parent) 'VERSION') -Raw -Encoding UTF8).Trim()
    $editor = [CompiCropEditor]::new($source, $width, $height, $version)
    $editor.Icon = [Drawing.Icon]::new((Join-Path (Split-Path $PSScriptRoot -Parent) 'assets\Compi.ico'))
    $editor.Add_Shown({
        $previewPath = Join-Path $folder 'crop-preview.png'
        if (-not (Test-Path -LiteralPath $previewPath)) {
            $capture = [Drawing.Bitmap]::new($editor.Width, $editor.Height)
            $editor.DrawToBitmap($capture, [Drawing.Rectangle]::new(0, 0, $capture.Width, $capture.Height))
            $capture.Save($previewPath, [Drawing.Imaging.ImageFormat]::Png)
            $capture.Dispose()
        }
        if ($moveTop -or $dragDown -or $zoomPan) {
            $flags = [Reflection.BindingFlags]'Instance,NonPublic'
            $canvas = $editor.GetType().GetField('canvas', $flags).GetValue($editor)
            $canvas.Refresh()
            if (-not $canvas.Focus()) { throw 'La vista previa no acepta el foco para usar la ruedita.' }
            $downMethod = $editor.GetType().GetMethod('MouseDownPreview', $flags)
            $y = if ($moveTop) { 20 } else { 260 }
            $click = [Windows.Forms.MouseEventArgs]::new([Windows.Forms.MouseButtons]::Left, 1, [int]($canvas.Width / 2), $y, 0)
            $downMethod.Invoke($editor, @($canvas, $click)) | Out-Null
            if ($dragDown) {
                $cached = $editor.GetType().GetField('previewImage', $flags).GetValue($editor)
                $moveMethod = $editor.GetType().GetMethod('MouseMovePreview', $flags)
                for ($step = 1; $step -le 50; $step++) {
                    $motion = [Windows.Forms.MouseEventArgs]::new([Windows.Forms.MouseButtons]::Left, 1, [int]($canvas.Width / 2), 260 + 2 * $step, 0)
                    $moveMethod.Invoke($editor, @($canvas, $motion)) | Out-Null
                    $canvas.Refresh()
                }
                $stillCached = $editor.GetType().GetField('previewImage', $flags).GetValue($editor)
                if (-not [object]::ReferenceEquals($cached, $stillCached)) { throw 'Se volvió a generar la foto durante el arrastre.' }
                $capture = [Drawing.Bitmap]::new($editor.Width, $editor.Height)
                $editor.DrawToBitmap($capture, [Drawing.Rectangle]::new(0, 0, $capture.Width, $capture.Height))
                $capture.Save((Join-Path $folder 'drag-preview.png'), [Drawing.Imaging.ImageFormat]::Png)
                $capture.Dispose()
            }
            if ($zoomPan) {
                $wheelMethod = $editor.GetType().GetMethod('MouseWheelPreview', $flags)
                $wheel = [Windows.Forms.MouseEventArgs]::new([Windows.Forms.MouseButtons]::None, 0, [int]($canvas.Width / 2), [int]($canvas.Height / 2), 720)
                $wheelMethod.Invoke($editor, @($canvas, $wheel)) | Out-Null
                $cropWidth = $editor.GetType().GetField('cropWidth', $flags).GetValue($editor)
                $cropHeight = $editor.GetType().GetField('cropHeight', $flags).GetValue($editor)
                if ($cropWidth -ge 2000 -or [Math]::Abs($cropWidth / $cropHeight - $width / $height) -gt 0.001) {
                    throw 'El zoom no conservó la relación de aspecto.'
                }
                $middleDown = [Windows.Forms.MouseEventArgs]::new([Windows.Forms.MouseButtons]::Middle, 1, [int]($canvas.Width / 2), [int]($canvas.Height / 2), 0)
                $downMethod.Invoke($editor, @($canvas, $middleDown)) | Out-Null
                $middleMove = [Windows.Forms.MouseEventArgs]::new([Windows.Forms.MouseButtons]::Middle, 1, [int]($canvas.Width / 2), [int]($canvas.Height / 2) + 200, 0)
                $editor.GetType().GetMethod('MouseMovePreview', $flags).Invoke($editor, @($canvas, $middleMove)) | Out-Null
                $canvas.Refresh()
                $capture = [Drawing.Bitmap]::new($editor.Width, $editor.Height)
                $editor.DrawToBitmap($capture, [Drawing.Rectangle]::new(0, 0, $capture.Width, $capture.Height))
                $capture.Save((Join-Path $folder 'zoom-pan-preview.png'), [Drawing.Imaging.ImageFormat]::Png)
                $capture.Dispose()
            }
        }
        $button = $editor.Controls | Where-Object { $_ -is [Windows.Forms.Button] -and $_.Text -like 'REEXPORTAR FOTO*' } | Select-Object -First 1
        $button.PerformClick()
    })
    try {
        if ($editor.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { throw 'El editor no confirmó la exportación.' }
        return $editor.OutputPath
    } finally { $editor.Dispose() }
}

$first = Export-TestPhoto 1000 600
$second = Export-TestPhoto 1000 600
$moved = Export-TestPhoto 1000 600 $true
$dragged = Export-TestPhoto 1000 600 $false $true
$zoomed = Export-TestPhoto 1000 600 $false $false $true
if ($first -eq $second -or -not (Test-Path -LiteralPath $source)) { throw 'Se sobrescribió una foto.' }
foreach ($path in @($first, $second)) {
    $image = [Drawing.Bitmap]::new($path)
    try {
        if ($image.Width -ne 1000 -or $image.Height -ne 600) { throw 'La resolución final es incorrecta.' }
        if ($image.GetPixel(500, 10).ToArgb() -ne [Drawing.Color]::Lime.ToArgb()) { throw 'El recorte centrado es incorrecto.' }
    } finally { $image.Dispose() }
}
$movedImage = [Drawing.Bitmap]::new($moved)
try {
    if ($movedImage.GetPixel(500, 10).ToArgb() -ne [Drawing.Color]::Red.ToArgb()) { throw 'No se aplicó el ajuste manual del recorte.' }
} finally { $movedImage.Dispose() }
$draggedImage = [Drawing.Bitmap]::new($dragged)
try {
    if ($draggedImage.GetPixel(500, 590).ToArgb() -ne [Drawing.Color]::Blue.ToArgb()) { throw 'El arrastre no cambió el recorte como se esperaba.' }
} finally { $draggedImage.Dispose() }
$zoomedImage = [Drawing.Bitmap]::new($zoomed)
try {
    if ($zoomedImage.GetPixel(500, 10).ToArgb() -ne [Drawing.Color]::Red.ToArgb()) { throw 'El zoom y paneo no cambiaron el encuadre exportado.' }
} finally { $zoomedImage.Dispose() }

$jpegSource = Join-Path $folder 'foto con espacios.jpg'
$jpegBitmap = [Drawing.Bitmap]::new($source)
$jpegBitmap.Save($jpegSource, [Drawing.Imaging.ImageFormat]::Jpeg)
$jpegBitmap.Dispose()
$source = $jpegSource
$jpegOutput = Export-TestPhoto 1000 1000
if ([IO.Path]::GetExtension($jpegOutput) -ne '.jpg') { throw 'La foto JPG no conservó el formato de salida.' }
$jpegImage = [Drawing.Bitmap]::new($jpegOutput)
try {
    if ($jpegImage.Width -ne 1000 -or $jpegImage.Height -ne 1000) { throw 'La foto JPG tiene una resolución incorrecta.' }
} finally { $jpegImage.Dispose() }

[pscustomobject]@{ input = $source; first = $first; second = $second; moved = $moved; dragged = $dragged; zoomed = $zoomed; jpeg = $jpegOutput; preview = (Join-Path $folder 'crop-preview.png'); dragPreview = (Join-Path $folder 'drag-preview.png'); zoomPreview = (Join-Path $folder 'zoom-pan-preview.png'); width = 1000; height = 600 } | ConvertTo-Json -Compress
