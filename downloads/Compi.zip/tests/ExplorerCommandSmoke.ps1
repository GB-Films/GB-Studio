param([Parameter(Mandatory=$true)][string]$BuildDirectory)
$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
$BuildDirectory = [IO.Path]::GetFullPath($BuildDirectory)
$source = Join-Path $PSScriptRoot 'ExplorerCommandSmoke.cpp'
$test = Join-Path $BuildDirectory 'ExplorerCommandSmoke.exe'
$object = Join-Path $BuildDirectory 'ExplorerCommandSmoke.obj'
$vcvars = 'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat'
$command = '"' + $vcvars + '" >nul && cl.exe /nologo /std:c++17 /EHsc /W4 /WX /wd4191 /MT "' + $source + '" /Fe"' + $test + '" /Fo"' + $object + '" /link shell32.lib shlwapi.lib ole32.lib uuid.lib'
$start = [Diagnostics.ProcessStartInfo]::new($env:ComSpec, '/d /s /c "' + $command + '"')
$start.UseShellExecute = $false
$start.CreateNoWindow = $true
$start.RedirectStandardOutput = $true
$start.RedirectStandardError = $true
$process = [Diagnostics.Process]::Start($start)
$output = $process.StandardOutput.ReadToEndAsync()
$errors = $process.StandardError.ReadToEndAsync()
$process.WaitForExit()
Write-Host $output.Result
Write-Host $errors.Result
if ($process.ExitCode -ne 0) { throw 'Native test build failed.' }
$video = Join-Path $BuildDirectory 'test.MP4'
$other = Join-Path $BuildDirectory 'test.txt'
[IO.File]::WriteAllText($video, 'Test fixture')
[IO.File]::WriteAllText($other, 'Nonvideo')
& $test (Join-Path $BuildDirectory 'CompiExplorerCommand.dll') $video $other
if ($LASTEXITCODE -ne 0) { throw 'Native extension test failed.' }

# Validate the complete manifest with executable references present, without
# registering an unsigned package or changing Developer Mode/trusted certs.
$validation = Join-Path $BuildDirectory 'validation'
New-Item -ItemType Directory -Path $validation -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $BuildDirectory 'layout\AppxManifest.xml') -Destination (Join-Path $validation 'AppxManifest.xml') -Force
Copy-Item -LiteralPath (Join-Path $BuildDirectory 'layout\assets') -Destination $validation -Recurse -Force
Copy-Item -LiteralPath (Join-Path $repo 'Compi.exe'), (Join-Path $BuildDirectory 'CompiExplorerCommand.dll') -Destination $validation -Force
& 'C:\Program Files (x86)\Windows Kits\10\bin\10.0.22621.0\x64\makeappx.exe' pack /d $validation /p (Join-Path $BuildDirectory 'validation.msix') /o
if ($LASTEXITCODE -ne 0) { throw 'Manifest validation failed.' }
'OK: manifest validated; unsigned package not registered.'
