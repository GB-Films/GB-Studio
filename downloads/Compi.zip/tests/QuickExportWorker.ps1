# Deliberately slow worker for the quick-export UI integration test, not shipped at runtime.
param([string]$JobFile)
$job = Get-Content -LiteralPath $JobFile -Raw -Encoding UTF8 | ConvertFrom-Json
function Status([string]$state, [int]$progress, [string]$output = '') {
    $tmp = Join-Path $job.directory 'status.tmp'
    @{state=$state; progress=$progress; message='Reexportando video de prueba...'; output=$output} |
        ConvertTo-Json -Compress | Set-Content -LiteralPath $tmp -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination (Join-Path $job.directory 'status.json') -Force
}
foreach ($progress in @(10, 30, 50, 70, 85)) {
    Status 'running' $progress
    Start-Sleep -Milliseconds 900
    if (Test-Path -LiteralPath (Join-Path $job.directory 'cancel')) { Status 'cancelled' $progress; exit 0 }
    if ([IO.Path]::GetFileName($job.input).StartsWith('fallo') -and $progress -ge 30) { Status 'error' $progress; exit 1 }
}
$output = Join-Path ([IO.Path]::GetDirectoryName($job.input)) ([IO.Path]::GetFileNameWithoutExtension($job.input) + '_reexportado.mp4')
Copy-Item -LiteralPath $job.input -Destination $output
Status 'done' 100 $output
