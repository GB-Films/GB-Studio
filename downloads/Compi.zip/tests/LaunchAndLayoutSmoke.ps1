﻿param([string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') { throw 'Ejecutá esta prueba con Windows PowerShell -STA.' }
$repo = Split-Path $PSScriptRoot -Parent
if (-not $OutputDirectory) { $OutputDirectory = Join-Path (Split-Path $repo -Parent) ('work\launch-test-' + [guid]::NewGuid().ToString('N')) }
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$video = Join-Path $OutputDirectory 'video con espacio y ñ.MP4'
[IO.File]::WriteAllText($video, 'Fixture de carga: no se prueba codificación en este test.')
$assembly = [Reflection.Assembly]::LoadFrom((Join-Path $repo 'Compi.exe'))
$resolve = $assembly.GetType('CompiLauncher').GetMethod('ResolveLaunch', [Reflection.BindingFlags]'Static,NonPublic')
foreach ($arguments in @(@($video), @('--video', $video))) {
    $launch = $resolve.Invoke($null, [object[]](,([string[]]$arguments)))
    if ($launch[0] -ne 'video' -or $launch[1] -ne $video) { throw 'Falló la interpretación del archivo de Abrir con.' }
}
$photo = Join-Path $OutputDirectory 'foto.png'
Add-Type -AssemblyName System.Drawing
$image = [Drawing.Bitmap]::new(20, 10)
try { $image.Save($photo, [Drawing.Imaging.ImageFormat]::Png) } finally { $image.Dispose() }
$launch = $resolve.Invoke($null, [object[]](,([string[]]@($photo))))
if ($launch[0] -ne 'photo') { throw 'No se reconoció una foto abierta directamente.' }
$CompiRoot = $repo
$CompiLaunchMode = 'video'
$CompiLaunchPath = $video
$app = [IO.File]::ReadAllText((Join-Path $repo 'Compi.ps1')).Replace('$appRoot = $PSScriptRoot', '$appRoot = $CompiRoot')
$verification = @'
$script:layoutError = $null
$form.Add_Shown({
    try {
        if ($script:inputPath -ne $CompiLaunchPath -or $fileName.Text -ne [IO.Path]::GetFileName($CompiLaunchPath) -or -not $go.Enabled) { throw 'La app no precargó el video al mostrarse.' }
        if ($aboutButton.AccessibleName -ne 'Información sobre Compi') { throw 'Falta el botón de información.' }
        $about = & $createAbout
        try {
            if (-not ($about.Controls | Where-Object Text -eq 'Desarrollado por Gran Berta')) { throw 'El crédito no coincide.' }
            $about.Show($form)
            [Windows.Forms.Application]::DoEvents()
            $bitmap = [Drawing.Bitmap]::new($about.Width, $about.Height)
            try { $about.DrawToBitmap($bitmap, [Drawing.Rectangle]::new(0, 0, $bitmap.Width, $bitmap.Height)); $bitmap.Save((Join-Path $OutputDirectory 'acerca-de.png')) } finally { $bitmap.Dispose() }
        } finally { $about.Dispose() }
        $bitmap = [Drawing.Bitmap]::new($form.Width, $form.Height)
        try { $form.DrawToBitmap($bitmap, [Drawing.Rectangle]::new(0, 0, $bitmap.Width, $bitmap.Height)); $bitmap.Save((Join-Path $OutputDirectory 'app-video-precargado.png')) } finally { $bitmap.Dispose() }
    } catch { $script:layoutError = $_ }
    finally { $form.Close() }
})
[void]$form.ShowDialog()
if ($script:layoutError) { throw $script:layoutError }
'OK: Abrir con (video/foto), video precargado, botón de información y crédito.'
'@
$app = $app.Replace('[void]$form.ShowDialog()', $verification)
Invoke-Expression $app
