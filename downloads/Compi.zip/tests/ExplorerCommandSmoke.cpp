#include <windows.h>
#include <shobjidl.h>
#include <shlwapi.h>
#include <iostream>
#include <stdexcept>

static void Check(bool condition, const char* message) { if (!condition) throw std::runtime_error(message); }
static IShellItemArray* Selection(const wchar_t* path)
{
    IShellItem* item = nullptr;
    Check(SUCCEEDED(SHCreateItemFromParsingName(path, nullptr, IID_PPV_ARGS(&item))), "Create item");
    IShellItemArray* items = nullptr;
    HRESULT result = SHCreateShellItemArrayFromShellItem(item, IID_PPV_ARGS(&items));
    item->Release(); Check(SUCCEEDED(result), "Create selection"); return items;
}
int wmain(int count, wchar_t** args)
{
    if (count != 4) return 2;
    HRESULT initialized = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    if (FAILED(initialized)) return 3;
    HMODULE dll = LoadLibraryW(args[1]);
    if (!dll) { CoUninitialize(); return 4; }
    try
    {
        const CLSID clsid = {0x6b72dcc8, 0x0ec3, 0x4a17, {0xa8, 0x2e, 0x29, 0x1a, 0xb3, 0xf0, 0x96, 0x12}};
        auto get = reinterpret_cast<LPFNGETCLASSOBJECT>(GetProcAddress(dll, "DllGetClassObject"));
        auto unload = reinterpret_cast<LPFNCANUNLOADNOW>(GetProcAddress(dll, "DllCanUnloadNow"));
        Check(get && unload, "COM exports"); Check(unload() == S_OK, "Initial unload");
        IClassFactory* factory = nullptr;
        Check(SUCCEEDED(get(clsid, IID_PPV_ARGS(&factory))), "Factory");
        Check(unload() == S_FALSE, "Factory lifetime");
        IExplorerCommand* command = nullptr;
        Check(SUCCEEDED(factory->CreateInstance(nullptr, IID_PPV_ARGS(&command))), "Command"); factory->Release();
        PWSTR text = nullptr;
        Check(SUCCEEDED(command->GetTitle(nullptr, &text)) && wcscmp(text, L"Reexportar con Compi") == 0, "Title"); CoTaskMemFree(text);
        text = nullptr;
        Check(SUCCEEDED(command->GetIcon(nullptr, &text)) && wcsstr(text, L"Compi.exe"), "Icon"); CoTaskMemFree(text);
        EXPCMDSTATE state;
        Check(SUCCEEDED(command->GetState(nullptr, FALSE, &state)) && state == ECS_HIDDEN, "Empty selection hidden");
        IShellItemArray* video = Selection(args[2]);
        Check(SUCCEEDED(command->GetState(video, FALSE, &state)) && state == ECS_ENABLED, "Video enabled"); video->Release();
        IShellItemArray* other = Selection(args[3]);
        Check(SUCCEEDED(command->GetState(other, FALSE, &state)) && state == ECS_HIDDEN, "Nonvideo hidden"); other->Release();
        Check(command->Invoke(nullptr, nullptr) == E_INVALIDARG, "Invalid invocation rejected");
        command->Release(); Check(unload() == S_OK, "Final unload");
        std::cout << "OK: native COM activation, title, icon, video filter and lifetime.\n";
    }
    catch (const std::exception& error) { std::cerr << error.what() << '\n'; FreeLibrary(dll); CoUninitialize(); return 1; }
    FreeLibrary(dll); CoUninitialize(); return 0;
}
