# Publicar Compi como ZIP para Windows

Compi es una aplicación de escritorio portátil: se descomprime el ZIP y se abre `Compi.exe`. No tiene instalador.

## Estado de la versión 1.1.5

`Compi.exe` no tiene firma digital. Las copias de `ffmpeg.exe` y `ffprobe.exe` que Compi descarga para exportar videos tampoco están firmadas. En Windows 11 con Control Inteligente de Aplicaciones activo, estos ejecutables pueden quedar bloqueados antes de que Compi pueda mostrar un mensaje o completar una exportación. Cambiar el nombre del ZIP o volver a comprimirlo no modifica esto.

El ZIP actual sirve para desarrollo y pruebas en equipos que permiten ejecutar estos archivos. No debe presentarse como una descarga pública compatible con todos los equipos Windows.

## Requisitos para la descarga pública directa

1. Obtener un certificado de firma de código de una autoridad confiable o acceso a un servicio de firma de código aceptado por Windows.
2. Preparar una entrega que incluya las herramientas de video necesarias, con sus licencias y avisos correspondientes. La descarga automática actual de ejecutables sin firma no resuelve el bloqueo de Windows.
3. Firmar con marca de tiempo `Compi.exe`, los scripts de PowerShell y los ejecutables de video que se distribuyan. Verificar que Windows reconozca la firma de cada archivo.
4. Crear el ZIP `Compi vNÚMERO.zip` después de firmar, sin reconstruir ni modificar los archivos firmados.
5. Probar la descarga y la exportación de foto y video en una instalación de Windows 11 con Control Inteligente de Aplicaciones activo.

No se puede garantizar que una versión sin firma pase el Control Inteligente de Aplicaciones. Microsoft tampoco ofrece una excepción para permitir una sola aplicación bloqueada por este control.

Referencias: [preguntas frecuentes de Microsoft](https://support.microsoft.com/en-us/windows/security/threat-malware-protection/smart-app-control-frequently-asked-questions) y [firma de aplicaciones para Smart App Control](https://learn.microsoft.com/en-us/windows/apps/develop/smart-app-control/code-signing-for-smart-app-control).
