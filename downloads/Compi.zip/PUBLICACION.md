# Publicar Compi para Windows

La entrega principal es `Compi-Setup-vNÚMERO.exe`, creado con `tools/Build-Installer.ps1` y NSIS. Instala Compi para el usuario actual, agrega los comandos del menú contextual y permite desinstalarlo desde Windows. El ZIP creado con `tools/Package-App.ps1` sigue disponible como variante portátil; en ese caso el menú se activa por separado.

## Estado de la versión 1.3.2

`Compi-Setup-vNÚMERO.exe` y `Compi.exe` no tienen firma digital. Las copias de `ffmpeg.exe` y `ffprobe.exe` que Compi descarga para exportar videos tampoco están firmadas. En Windows 11 con Control Inteligente de Aplicaciones activo, estos ejecutables pueden quedar bloqueados antes de que Compi pueda mostrar un mensaje o completar una exportación. Empaquetarlos en un instalador no modifica esto.

El instalador actual sirve para desarrollo y pruebas en equipos que permiten ejecutar estos archivos. No debe presentarse como una descarga pública compatible con todos los equipos Windows.

## Menú principal de Windows 11

La extensión nativa `IExplorerCommand` y el paquete de identidad con ubicación externa están implementados. Para incluirlos en la entrega, ejecutá `tools/Build-Installer.ps1 -ExplorerCertificateThumbprint HUELLA` con un certificado de firma confiable y su clave privada en `Cert:\CurrentUser\My`. La identidad usa el nombre estable `GBFilms.Compi.ContextMenu`; el editor se toma del certificado. Mantener el mismo editor permite actualizar el paquete sin crear identidades duplicadas.

El script verifica las firmas antes de incluir el paquete en NSIS. El instalador registra el paquete con `Add-AppxPackage -ExternalLocation`; no instala certificados ni altera las políticas de seguridad de Windows. La desinstalación retira la identidad. Sin certificado, el instalador no incluye un paquete sin firma: el menú funciona en **Mostrar más opciones** y la pantalla final lo indica. Una casilla de aceptación no sustituye esos requisitos.

Se probaron compilación nativa y manifiesto, pero la aparición real en el menú principal requiere probar el paquete firmado y registrado en Windows 11. No dar esa integración por verificada solamente porque compila.

## Requisitos para la descarga pública directa

1. Obtener un certificado de firma de código de una autoridad confiable o acceso a un servicio de firma de código aceptado por Windows.
2. Preparar una entrega que incluya las herramientas de video necesarias, con sus licencias y avisos correspondientes. La descarga automática actual de ejecutables sin firma no resuelve el bloqueo de Windows.
3. Firmar con marca de tiempo `Compi.exe`, los scripts de PowerShell y los ejecutables de video que se distribuyan. Verificar que Windows reconozca la firma de cada archivo.
4. Crear y firmar el instalador `Compi-Setup-vNÚMERO.exe` después de firmar los archivos incluidos, sin reconstruirlos ni modificarlos.
5. Probar la descarga y la exportación de foto y video en una instalación de Windows 11 con Control Inteligente de Aplicaciones activo.

No se puede garantizar que una versión sin firma pase el Control Inteligente de Aplicaciones. Microsoft tampoco ofrece una excepción para permitir una sola aplicación bloqueada por este control.

Referencias: [preguntas frecuentes de Microsoft](https://support.microsoft.com/en-us/windows/security/threat-malware-protection/smart-app-control-frequently-asked-questions) y [firma de aplicaciones para Smart App Control](https://learn.microsoft.com/en-us/windows/apps/develop/smart-app-control/code-signing-for-smart-app-control).
